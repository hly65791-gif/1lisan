# Lisan Authentication & Ownership

Lisan v0.29 adds account authentication and per-resource ownership.

## Endpoints
- `POST /v1/auth/register` — email/password (minimum 8 characters).
- `POST /v1/auth/login` — returns a signed bearer token.
- `GET /v1/auth/me` — validates the current token.

Protected `/v1/*` endpoints require `Authorization: Bearer <token>` when `LISAN_AUTH_REQUIRED=true`. `/health` and auth endpoints remain public.

Uploads, pipeline jobs, render jobs, and artifacts store an `owner_id`. Access by another user returns `404 RESOURCE_NOT_FOUND` to avoid leaking resource existence.

Passwords use PBKDF2-HMAC-SHA256 with a per-user random salt. Tokens are HS256 signed and expire after 24 hours. Set a strong `LISAN_AUTH_SECRET` in production.

The Android client stores the access token in app private SharedPreferences and automatically adds the bearer header to `/v1/*` API calls.
