@echo off
setlocal
set "GRADLE_VERSION=8.10.2"
set "GRADLE_SHA256=31c55713e40233a8303827ceb42ca48a47267a0ad4bab9177123121e71524c26"
set "ROOT_DIR=%~dp0"
set "CACHE_DIR=%USERPROFILE%\.gradle\lisan-bootstrap\gradle-%GRADLE_VERSION%"
set "DIST_DIR=%CACHE_DIR%\gradle-%GRADLE_VERSION%"
set "ZIP=%CACHE_DIR%\gradle-%GRADLE_VERSION%-bin.zip"
if not exist "%DIST_DIR%\bin\gradle.bat" (
  if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
  if not exist "%ZIP%" powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$h=(Get-FileHash '%ZIP%' -Algorithm SHA256).Hash.ToLower(); if($h -ne '%GRADLE_SHA256%'){throw 'Gradle SHA-256 mismatch'}"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%ZIP%' -DestinationPath '%CACHE_DIR%' -Force"
)
call "%DIST_DIR%\bin\gradle.bat" --project-dir "%ROOT_DIR%" %*
endlocal
