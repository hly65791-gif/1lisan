# Lisan Gradle Cloud Bootstrap

This project uses Gradle 8.10.2 for the current Android toolchain (AGP 8.7.3 / Kotlin 2.0.21).

`gradlew` is a **cloud-build bootstrap script**, not the official Gradle Wrapper JAR. It downloads the official Gradle 8.10.2 binary distribution from `services.gradle.org`, verifies its SHA-256 checksum, caches it, and runs Gradle against this project.

Official Gradle documentation recommends the standard Wrapper (`gradlew` + `gradle/wrapper/gradle-wrapper.jar` + properties) for reproducible builds. The official 8.10.2 distribution checksum used here is:

`31c55713e40233a8303827ceb42ca48a47267a0ad4bab9177123121e71524c26`

Once a machine with Gradle is available, replace this bootstrap with a standard generated Gradle Wrapper using `gradle :wrapper --gradle-version 8.10.2 --distribution-type bin` and commit the generated Wrapper JAR.
