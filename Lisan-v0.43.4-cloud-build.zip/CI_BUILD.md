# Lisan Cloud Android Build

Lisan is prepared for cloud Android builds with Codemagic and GitHub Actions.

## Codemagic

1. Push this project to a Git repository.
2. In Codemagic, add the repository as a Native Android application.
3. Select `codemagic.yaml` from the repository root.
4. Run `lisan-android-debug` first.
5. If debug passes, run `lisan-android-release`.

The workflows bootstrap Gradle 8.10.2 when the repository does not yet contain `gradlew`, configure the Android SDK, build the APK/AAB, and expose the artifacts.

## GitHub Actions

The repository includes `.github/workflows/android-build.yml`. Push to GitHub and run the workflow manually or via a push/PR.

## Important

No signing key, password, token, or provider secret is stored in this repository. Release signing should be configured as CI secrets after the unsigned release build passes.
