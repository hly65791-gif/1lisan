# Lisan 0.25 Pipeline Jobs

The backend now exposes one asynchronous orchestration path for the full production pipeline:

`completed upload → audio extraction → STT → translation → OCR (optional) → alignment (optional) → SRT → FFmpeg render → validation`

Each job persists state under `LISAN_DATA_DIR/artifacts/pipeline-<job_id>/job.json` plus stage artifacts. The runner checks `completed_stages` before executing a stage, allowing a failed job to resume from the last persisted checkpoint.

Endpoints:
- `POST /v1/pipeline`
- `GET /v1/pipeline-jobs/{job_id}`
- `POST /v1/pipeline-jobs/{job_id}/resume`

This is durable across process memory loss because the checkpoint is stored on disk. It is not yet a distributed queue: for multi-instance production deployment, move job state and execution to Redis/Cloud Tasks/Celery or an equivalent durable worker system.
