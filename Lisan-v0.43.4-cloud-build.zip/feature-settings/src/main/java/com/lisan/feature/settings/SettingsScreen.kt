package com.lisan.feature.settings

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF061126)
private val Surface = Color(0xFF0D1B38)
private val Surface2 = Color(0xFF12244A)
private val Purple = Color(0xFF8B4DFF)
private val Cyan = Color(0xFF12C8EE)
private val TextPrimary = Color(0xFFF7F8FF)
private val TextMuted = Color(0xFF9BA9C7)

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("lisan_settings", android.content.Context.MODE_PRIVATE) }
    var backendUrl by remember { mutableStateOf(prefs.getString("backend_url", "http://10.0.2.2:8000") ?: "") }
    var notifications by remember { mutableStateOf(prefs.getBoolean("notifications_enabled", true)) }
    var darkMode by remember { mutableStateOf(prefs.getBoolean("dark_mode", true)) }
    var saved by remember { mutableStateOf(false) }
    var showBackend by remember { mutableStateOf(false) }

    fun save() {
        prefs.edit()
            .putString("backend_url", backendUrl.trim().trimEnd('/'))
            .putBoolean("notifications_enabled", notifications)
            .putBoolean("dark_mode", darkMode)
            .apply()
        saved = true
    }

    CompositionLocalProvider(androidx.compose.ui.unit.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
        Scaffold(
            containerColor = Navy,
            topBar = {
                TopAppBar(
                    title = { Text("حسابي وإعدادات لسان", fontWeight = FontWeight.ExtraBold, color = TextPrimary) },
                    navigationIcon = { TextButton(onClick = onBack) { Text("رجوع", color = Cyan) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy)
                )
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                AccountCard()

                SectionTitle("التفضيلات")
                SettingToggle("الوضع الداكن", "واجهة Lisan الليلية", Icons.Default.DarkMode, darkMode) {
                    darkMode = it; saved = false
                }
                SettingToggle("الإشعارات", "اكتمال الترجمة وتحديثات المعالجة", Icons.Default.Notifications, notifications) {
                    notifications = it; saved = false
                }
                SettingRow("لغة التطبيق", "العربية (RTL)", Icons.Default.Language) { }

                SectionTitle("التخزين والمعالجة")
                SettingRow("المعالجة السحابية", "فيديوهاتك تُعالج عبر خادم Lisan", Icons.Default.Cloud) { }
                SettingRow("التخزين", "إدارة الملفات والمشاريع المحلية", Icons.Default.Storage) { }
                SettingRow("الأمان", "حماية الاتصال وبيانات المشروع", Icons.Default.Security) { }

                SectionTitle("الدعم")
                SettingRow("مركز المساعدة", "أسئلة شائعة وحلول المشاكل", Icons.Default.Help) {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com/lisan/help")))
                }
                SettingRow("قيّم Lisan", "ساعدنا على تحسين التطبيق", Icons.Default.Star) { }
                SettingRow("عن Lisan", "الإصدار 0.40.0", Icons.Default.Info) { }

                OutlinedButton(
                    onClick = { showBackend = !showBackend },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.Settings, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (showBackend) "إخفاء إعدادات الخادم" else "إعدادات متقدمة")
                }

                if (showBackend) {
                    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("خادم المعالجة", color = TextPrimary, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = backendUrl,
                                onValueChange = { backendUrl = it; saved = false },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("Backend URL") },
                                singleLine = true
                            )
                            Text("استخدم HTTPS في بيئة الإنتاج.", color = TextMuted, fontSize = 12.sp)
                        }
                    }
                }

                Button(
                    onClick = { save() },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Purple),
                    shape = RoundedCornerShape(16.dp)
                ) { Text(if (saved) "تم حفظ الإعدادات ✓" else "حفظ الإعدادات", fontWeight = FontWeight.Bold) }

                OutlinedButton(
                    onClick = {
                        prefs.edit().remove("access_token").apply()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFF6B7A))
                ) {
                    Icon(Icons.Default.Logout, null)
                    Spacer(Modifier.width(8.dp))
                    Text("تسجيل الخروج")
                }

                Text("Lisan — ترجمة الفيديو باحتراف", color = TextMuted, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(vertical = 8.dp))
            }
        }
    }
}

@Composable
private fun AccountCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Surface)
    ) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(18.dp), color = Surface2, modifier = Modifier.size(58.dp)) {
                Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Cyan, modifier = Modifier.size(30.dp)) }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("حساب Lisan", color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text("الخطة المجانية — ترجمة شهرية غير محدودة", color = TextMuted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = TextMuted, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp, bottom = 1.dp))
}

@Composable
private fun SettingRow(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text(subtitle, color = TextMuted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun SettingToggle(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Surface), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Purple, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text(subtitle, color = TextMuted, fontSize = 12.sp)
            }
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}
