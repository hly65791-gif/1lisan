# Lisan v0.43.1 Build Report

## Inspection environment
- Java: OpenJDK 21.0.11
- System Gradle: NOT FOUND
- Android SDK: NOT FOUND
- ADB: NOT FOUND
- FFmpeg: AVAILABLE
- ffprobe: AVAILABLE
- Gradle Wrapper in archive: MISSING

## Backend validation
- Python compileall: PASS
- Pytest: 48 passed, 12 warnings
- Warnings are FastAPI `on_event` deprecation warnings; they do not fail the test run.

## Android validation
- Gradle build: BLOCKED
- Lint: BLOCKED
- APK: NOT BUILT
- AAB: NOT BUILT

## Release status
BLOCKED — Android toolchain/artifact validation is still required.

## v0.43.4 cloud bootstrap
- Gradle 8.10.2 bootstrap: added.
- Gradle distribution SHA-256 verification: configured.
- Standard `gradle-wrapper.jar`: still not generated in this environment because Gradle itself is unavailable and the official binary cannot be downloaded from this execution environment.
