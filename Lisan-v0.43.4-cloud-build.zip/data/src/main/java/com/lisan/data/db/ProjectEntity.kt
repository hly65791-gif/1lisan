package com.lisan.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val sourceUri: String,
    val sourceLanguage: String,
    val targetLanguage: String,
    val status: String,
    val progress: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val error: String?,
    val outputPath: String? = null,
    val artifactId: String? = null,
    val subtitleStyle: String = "LISAN_CLASSIC",
    val subtitleFontSize: Int = 54,
    val subtitlePosition: String = "BOTTOM",
    val subtitleShape: String = "OUTLINE",
    val subtitleOutlineWidth: Int = 4,
    val subtitleShadowDepth: Int = 1,
    val subtitleHorizontalPercent: Int = 50,
    val subtitleVerticalPercent: Int = 88,
    val comprehensiveTranslation: Boolean = false,
    val replaceOcrText: Boolean = false
)
