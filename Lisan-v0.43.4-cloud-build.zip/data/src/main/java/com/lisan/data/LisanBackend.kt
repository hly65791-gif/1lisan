package com.lisan.data

import android.content.Context
import com.lisan.domain.provider.OcrProvider
import com.lisan.domain.provider.OcrSegment
import com.lisan.domain.provider.SpeechToTextProvider
import com.lisan.domain.provider.TranscriptSegment
import com.lisan.domain.provider.TranscriptWord
import com.lisan.domain.provider.TranslatedWordTiming
import com.lisan.domain.provider.TranslationProvider
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.RandomAccessFile
import javax.inject.Inject

class BackendConfig @Inject constructor(@ApplicationContext private val context: Context) {
    private val prefs = context.getSharedPreferences("lisan_settings", Context.MODE_PRIVATE)
    fun token(): String? = prefs.getString("access_token", null)
    fun saveToken(token: String) { prefs.edit().putString("access_token", token).apply() }
    fun clearToken() { prefs.edit().remove("access_token").apply() }
    fun baseUrl(): String = context.getSharedPreferences("lisan_settings", Context.MODE_PRIVATE)
        .getString("backend_url", "http://10.0.2.2:8000")!!
        .trimEnd('/')
}

class LisanBackendClient @Inject constructor(
    private val config: BackendConfig
) {
    private val client = OkHttpClient.Builder().addInterceptor { chain ->
        val original = chain.request()
        val token = config.token()
        val request = if (!token.isNullOrBlank() && original.url.encodedPath.startsWith("/v1/") && !original.url.encodedPath.startsWith("/v1/auth/")) {
            original.newBuilder().header("Authorization", "Bearer $token").build()
        } else original
        chain.proceed(request)
    }.build()

    suspend fun login(email: String, password: String): String = withContext(Dispatchers.IO) {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("email", email).addFormDataPart("password", password).build()
        val request = Request.Builder().url("${config.baseUrl()}/v1/auth/login").post(body).build()
        val token = JSONObject(execute(request)).getString("access_token")
        config.saveToken(token); token
    }

    suspend fun register(email: String, password: String): String = withContext(Dispatchers.IO) {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("email", email).addFormDataPart("password", password).build()
        val request = Request.Builder().url("${config.baseUrl()}/v1/auth/register").post(body).build()
        val token = JSONObject(execute(request)).getString("access_token")
        config.saveToken(token); token
    }

    fun logout() { config.clearToken() }

    suspend fun transcribe(file: File, language: String): List<TranscriptSegment> = withContext(Dispatchers.IO) {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("language", language)
            .addFormDataPart("audio", file.name, file.asRequestBody("audio/mp4".toMediaType()))
            .build()
        val request = Request.Builder().url("${config.baseUrl()}/v1/transcribe").post(body).build()
        execute(request).let(::parseTranscript)
    }

    suspend fun translate(segments: List<TranscriptSegment>, source: String, target: String): List<TranscriptSegment> = withContext(Dispatchers.IO) {
        val items = JSONArray().apply { segments.forEach { put(JSONObject().apply { put("start_ms", it.startMs); put("end_ms", it.endMs); put("text", it.text) }) } }
        val json = JSONObject().apply { put("source", source); put("target", target); put("segments", items) }
        val request = Request.Builder().url("${config.baseUrl()}/v1/translate")
            .post(json.toString().toRequestBody("application/json".toMediaType())).build()
        execute(request).let(::parseTranscript)
    }

    suspend fun align(source: List<TranscriptSegment>, translated: List<TranscriptSegment>): List<List<TranslatedWordTiming>> = withContext(Dispatchers.IO) {
        val sourceJson = JSONArray().apply {
            source.forEach { seg ->
                put(JSONObject().apply {
                    put("start_ms", seg.startMs); put("end_ms", seg.endMs); put("text", seg.text)
                    put("words", JSONArray().apply { seg.words.forEach { w -> put(JSONObject().apply { put("start_ms", w.startMs); put("end_ms", w.endMs); put("text", w.text) }) } })
                })
            }
        }
        val translatedJson = JSONArray().apply { translated.forEach { put(JSONObject().apply { put("start_ms", it.startMs); put("end_ms", it.endMs); put("text", it.text) }) } }
        val body = JSONObject().apply { put("source_segments", sourceJson); put("translated_segments", translatedJson) }
            .toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder().url("${config.baseUrl()}/v1/align").post(body).build()
        val arr = JSONObject(execute(request)).getJSONArray("segments")
        List(arr.length()) { i ->
            val words = arr.getJSONArray(i)
            List(words.length()) { j ->
                val w = words.getJSONObject(j)
                TranslatedWordTiming(w.getLong("start_ms"), w.getLong("end_ms"), w.getString("text"), if (w.has("source_word_index")) w.optInt("source_word_index") else null)
            }
        }
    }

    suspend fun initUpload(file: File): UploadSession = withContext(Dispatchers.IO) {
        val json = JSONObject().apply {
            put("filename", file.name)
            put("size_bytes", file.length())
            put("content_type", "video/mp4")
        }
        val request = Request.Builder().url("${config.baseUrl()}/v1/uploads/init")
            .post(json.toString().toRequestBody("application/json".toMediaType())).build()
        val o = JSONObject(execute(request))
        UploadSession(o.getString("upload_id"), o.getLong("offset"), o.getLong("size_bytes"), o.getLong("chunk_size"))
    }

    suspend fun uploadStatus(uploadId: String): UploadSession = withContext(Dispatchers.IO) {
        val request = Request.Builder().url("${config.baseUrl()}/v1/uploads/$uploadId").get().build()
        val o = JSONObject(execute(request))
        UploadSession(uploadId, o.getLong("offset"), o.getLong("size_bytes"), 8L * 1024L * 1024L)
    }

    suspend fun uploadResumable(file: File, session: UploadSession): UploadSession = withContext(Dispatchers.IO) {
        var offset = session.offset
        while (offset < file.length()) {
            val length = minOf(session.chunkSize, file.length() - offset)
            val body = FileRangeRequestBody(file, offset, length, "video/mp4".toMediaType())
            val request = Request.Builder().url("${config.baseUrl()}/v1/uploads/${session.uploadId}")
                .header("X-Chunk-Offset", offset.toString())
                .header("X-Total-Size", file.length().toString())
                .put(body).build()
            val o = JSONObject(execute(request))
            offset = o.getLong("offset")
        }
        val complete = Request.Builder().url("${config.baseUrl()}/v1/uploads/${session.uploadId}/complete").post("".toRequestBody(null)).build()
        execute(complete)
        UploadSession(session.uploadId, offset, file.length(), session.chunkSize)
    }

    suspend fun deleteUpload(uploadId: String) = withContext(Dispatchers.IO) {
        val request = Request.Builder().url("${config.baseUrl()}/v1/uploads/$uploadId").delete().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful && response.code != 404) {
                throw IllegalStateException("BACKEND_${response.code}: ${response.body?.string().orEmpty()}")
            }
        }
    }

    suspend fun renderUploaded(uploadId: String, subtitles: File, ocrOverlays: File? = null, karaokeAlignment: File? = null, subtitleStyle: String = "LISAN_CLASSIC", fontSize: Int = 54, position: String = "BOTTOM", shape: String = "OUTLINE", outlineWidth: Int = 4, shadowDepth: Int = 1, horizontalPercent: Int = 50, verticalPercent: Int = 88): RenderResult = withContext(Dispatchers.IO) {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("upload_id", uploadId)
            .addFormDataPart("subtitles", subtitles.name, subtitles.asRequestBody("text/plain".toMediaType()))
            .apply { if (ocrOverlays != null && ocrOverlays.exists()) addFormDataPart("ocr_overlays", ocrOverlays.name, ocrOverlays.asRequestBody("application/json".toMediaType())); if (karaokeAlignment != null && karaokeAlignment.exists()) addFormDataPart("karaoke_alignment", karaokeAlignment.name, karaokeAlignment.asRequestBody("application/json".toMediaType())) }
            .addFormDataPart("style", subtitleStyle)
            .addFormDataPart("font_size", fontSize.toString())
            .addFormDataPart("position", position)
            .addFormDataPart("shape", shape)
            .addFormDataPart("outline_width", outlineWidth.toString())
            .addFormDataPart("shadow_depth", shadowDepth.toString())
            .addFormDataPart("horizontal_percent", horizontalPercent.coerceIn(8, 92).toString())
            .addFormDataPart("vertical_percent", verticalPercent.coerceIn(8, 92).toString())
            .build()
        val request = Request.Builder().url("${config.baseUrl()}/v1/render-upload").post(body).build()
        val o = JSONObject(execute(request))
        RenderResult(o.getString("status"), o.getString("artifact_id"), o.getString("filename"), o.getDouble("duration_seconds"), o.getLong("size_bytes"), o.getBoolean("has_video"), o.getBoolean("has_audio"), o.optJSONObject("validation")?.optBoolean("valid", false) == true)
    }

    suspend fun renderUploadedAsync(uploadId: String, subtitles: File, ocrOverlays: File? = null, karaokeAlignment: File? = null, subtitleStyle: String = "LISAN_CLASSIC", fontSize: Int = 54, position: String = "BOTTOM", shape: String = "OUTLINE", outlineWidth: Int = 4, shadowDepth: Int = 1, horizontalPercent: Int = 50, verticalPercent: Int = 88): RenderJobResult = withContext(Dispatchers.IO) {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("upload_id", uploadId)
            .addFormDataPart("subtitles", subtitles.name, subtitles.asRequestBody("text/plain".toMediaType()))
            .apply { if (ocrOverlays != null && ocrOverlays.exists()) addFormDataPart("ocr_overlays", ocrOverlays.name, ocrOverlays.asRequestBody("application/json".toMediaType())); if (karaokeAlignment != null && karaokeAlignment.exists()) addFormDataPart("karaoke_alignment", karaokeAlignment.name, karaokeAlignment.asRequestBody("application/json".toMediaType())) }
            .addFormDataPart("style", subtitleStyle).addFormDataPart("font_size", fontSize.toString())
            .addFormDataPart("position", position).addFormDataPart("shape", shape)
            .addFormDataPart("outline_width", outlineWidth.toString()).addFormDataPart("shadow_depth", shadowDepth.toString())
            .addFormDataPart("horizontal_percent", horizontalPercent.coerceIn(8, 92).toString()).addFormDataPart("vertical_percent", verticalPercent.coerceIn(8, 92).toString()).build()
        val request = Request.Builder().url("${config.baseUrl()}/v1/render-upload/async").post(body).build()
        val o = JSONObject(execute(request))
        RenderJobResult(o.getString("job_id"), o.getString("artifact_id"), o.getString("status"), o.optInt("progress", 0), null)
    }

    suspend fun renderJobStatus(jobId: String): RenderJobResult = withContext(Dispatchers.IO) {
        val request = Request.Builder().url("${config.baseUrl()}/v1/render-jobs/$jobId").get().build()
        val o = JSONObject(execute(request))
        val result = o.optJSONObject("result")
        RenderJobResult(jobId, o.optString("artifact_id", result?.optString("artifact_id", "") ?: ""), o.getString("status"), o.optInt("progress", 0), result)
    }

    suspend fun startPipeline(uploadId: String, sourceLanguage: String, targetLanguage: String, ocrEnabled: Boolean = true, alignmentEnabled: Boolean = false, ocrLanguage: String = "", subtitleStyle: String = "LISAN_CLASSIC", fontSize: Int = 54, position: String = "BOTTOM", shape: String = "OUTLINE", outlineWidth: Int = 4, shadowDepth: Int = 1, horizontalPercent: Int = 50, verticalPercent: Int = 88): PipelineJobResult = withContext(Dispatchers.IO) {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("upload_id", uploadId).addFormDataPart("source_language", sourceLanguage).addFormDataPart("target_language", targetLanguage)
            .addFormDataPart("ocr_enabled", ocrEnabled.toString()).addFormDataPart("alignment_enabled", alignmentEnabled.toString()).addFormDataPart("ocr_language", ocrLanguage)
            .addFormDataPart("style", subtitleStyle).addFormDataPart("font_size", fontSize.toString()).addFormDataPart("position", position).addFormDataPart("shape", shape)
            .addFormDataPart("outline_width", outlineWidth.toString()).addFormDataPart("shadow_depth", shadowDepth.toString()).addFormDataPart("horizontal_percent", horizontalPercent.coerceIn(8,92).toString()).addFormDataPart("vertical_percent", verticalPercent.coerceIn(8,92).toString()).build()
        val request = Request.Builder().url("${config.baseUrl()}/v1/pipeline").post(body).build()
        val o = JSONObject(execute(request))
        PipelineJobResult(o.getString("job_id"), o.optString("status"), o.optInt("progress"), o.optString("stage"), o.optString("artifact_id"), o.optJSONObject("result"))
    }

    suspend fun pipelineJobStatus(jobId: String): PipelineJobResult = withContext(Dispatchers.IO) {
        val request = Request.Builder().url("${config.baseUrl()}/v1/pipeline-jobs/$jobId").get().build()
        val o = JSONObject(execute(request)); PipelineJobResult(jobId, o.optString("status"), o.optInt("progress"), o.optString("stage"), o.optString("artifact_id"), o.optJSONObject("result"))
    }

    suspend fun resumePipelineJob(jobId: String): PipelineJobResult = withContext(Dispatchers.IO) {
        val request = Request.Builder().url("${config.baseUrl()}/v1/pipeline-jobs/$jobId/resume").post("".toRequestBody(null)).build()
        val o = JSONObject(execute(request)); PipelineJobResult(jobId, o.optString("status"), o.optInt("progress"), o.optString("stage"), o.optString("artifact_id"), o.optJSONObject("result"))
    }

    suspend fun downloadArtifact(artifactId: String, destination: File) = withContext(Dispatchers.IO) {
        val request = Request.Builder().url("${config.baseUrl()}/v1/artifacts/$artifactId/download").get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw IllegalStateException("BACKEND_${response.code}: ${response.body?.string().orEmpty()}")
            val body = response.body ?: throw IllegalStateException("ARTIFACT_EMPTY_RESPONSE")
            destination.parentFile?.mkdirs()
            body.byteStream().use { input -> destination.outputStream().use { output -> input.copyTo(output, 1024 * 1024) } }
        }
        require(destination.length() > 0) { "DOWNLOADED_ARTIFACT_EMPTY" }
    }

    suspend fun render(video: File, subtitles: File, ocrOverlays: File? = null, subtitleStyle: String = "LISAN_CLASSIC", fontSize: Int = 54, position: String = "BOTTOM", shape: String = "OUTLINE", outlineWidth: Int = 4, shadowDepth: Int = 1, horizontalPercent: Int = 50, verticalPercent: Int = 88): RenderResult = withContext(Dispatchers.IO) {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("video", video.name, video.asRequestBody("video/mp4".toMediaType()))
            .addFormDataPart("subtitles", subtitles.name, subtitles.asRequestBody("text/plain".toMediaType()))
            .apply { if (ocrOverlays != null && ocrOverlays.exists()) addFormDataPart("ocr_overlays", ocrOverlays.name, ocrOverlays.asRequestBody("application/json".toMediaType())) }
            .addFormDataPart("style", subtitleStyle)
            .addFormDataPart("font_size", fontSize.toString())
            .addFormDataPart("position", position)
            .addFormDataPart("shape", shape)
            .addFormDataPart("outline_width", outlineWidth.toString())
            .addFormDataPart("shadow_depth", shadowDepth.toString())
            .addFormDataPart("horizontal_percent", horizontalPercent.coerceIn(8, 92).toString())
            .addFormDataPart("vertical_percent", verticalPercent.coerceIn(8, 92).toString())
            .build()
        val request = Request.Builder().url("${config.baseUrl()}/v1/render").post(body).build()
        val raw = execute(request)
        val o = JSONObject(raw)
        RenderResult(
            status = o.getString("status"),
            artifactId = o.optString("artifact_id", ""),
            filename = o.getString("filename"),
            durationSeconds = o.getDouble("duration_seconds"),
            sizeBytes = o.getLong("size_bytes"),
            hasVideo = o.getBoolean("has_video"),
            hasAudio = o.getBoolean("has_audio"),
            validationValid = o.optJSONObject("validation")?.optBoolean("valid", false) == true
        )
    }

    suspend fun ocr(video: InputStream, fileName: String, languageHint: String?): List<OcrSegment> = withContext(Dispatchers.IO) {
        val bytes = video.use { it.readBytes() }
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("language_hint", languageHint ?: "")
            .addFormDataPart("video", fileName, bytes.toRequestBody("video/mp4".toMediaType()))
            .build()
        val request = Request.Builder().url("${config.baseUrl()}/v1/ocr").post(body).build()
        execute(request).let(::parseOcr)
    }

    private fun execute(request: Request): String {
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("BACKEND_${response.code}: $body")
            return body
        }
    }

    private fun parseTranscript(raw: String): List<TranscriptSegment> {
        val arr = JSONObject(raw).getJSONArray("segments")
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            val words = if (o.has("words")) {
                val wa = o.optJSONArray("words") ?: JSONArray()
                List(wa.length()) { wi ->
                    val w = wa.getJSONObject(wi)
                    TranscriptWord(w.getLong("start_ms"), w.getLong("end_ms"), w.getString("text"), if (w.has("confidence")) w.optDouble("confidence").toFloat() else null)
                }
            } else emptyList()
            TranscriptSegment(o.getLong("start_ms"), o.getLong("end_ms"), o.getString("text"), if (o.has("confidence")) o.optDouble("confidence").toFloat() else null, words)
        }
    }

    private fun parseOcr(raw: String): List<OcrSegment> {
        val arr = JSONObject(raw).getJSONArray("segments")
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            OcrSegment(o.getLong("start_ms"), o.getLong("end_ms"), o.getString("text"), o.optInt("x"), o.optInt("y"))
        }
    }
}

data class UploadSession(
    val uploadId: String,
    val offset: Long,
    val sizeBytes: Long,
    val chunkSize: Long
)

data class RenderJobResult(val jobId: String, val artifactId: String, val status: String, val progress: Int, val result: JSONObject?)
data class PipelineJobResult(val jobId: String, val status: String, val progress: Int, val stage: String, val artifactId: String, val result: JSONObject?)

data class RenderResult(
    val status: String,
    val artifactId: String,
    val filename: String,
    val durationSeconds: Double,
    val sizeBytes: Long,
    val hasVideo: Boolean,
    val hasAudio: Boolean,
    val validationValid: Boolean
)

class BackendSpeechToTextProvider @Inject constructor(private val api: LisanBackendClient) : SpeechToTextProvider {
    override suspend fun transcribe(audioUri: String, language: String): List<TranscriptSegment> = api.transcribe(File(audioUri), language)
}

class BackendTranslationProvider @Inject constructor(private val api: LisanBackendClient) : TranslationProvider {
    override suspend fun translate(segments: List<TranscriptSegment>, source: String, target: String): List<TranscriptSegment> = api.translate(segments, source, target)
}

class BackendOcrProvider @Inject constructor(
    private val api: LisanBackendClient,
    @ApplicationContext private val context: Context
) : OcrProvider {
    override suspend fun detect(videoUri: String, languageHint: String?): List<OcrSegment> =
        context.contentResolver.openInputStream(android.net.Uri.parse(videoUri))?.let { api.ocr(it, "source.mp4", languageHint) }
            ?: throw IllegalStateException("VIDEO_URI_NOT_READABLE")
}

private class FileRangeRequestBody(
    private val file: File,
    private val offset: Long,
    private val length: Long,
    private val mediaType: okhttp3.MediaType
) : okhttp3.RequestBody() {
    override fun contentType() = mediaType
    override fun contentLength() = length
    override fun writeTo(sink: okio.BufferedSink) {
        RandomAccessFile(file, "r").use { raf ->
            raf.seek(offset)
            val buffer = ByteArray(1024 * 1024)
            var remaining = length
            while (remaining > 0) {
                val read = raf.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                if (read < 0) break
                sink.write(buffer, 0, read)
                remaining -= read
            }
            check(remaining == 0L) { "UPLOAD_CHUNK_READ_FAILED" }
        }
    }
}
