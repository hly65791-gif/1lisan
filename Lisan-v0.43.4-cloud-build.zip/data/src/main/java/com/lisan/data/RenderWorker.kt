package com.lisan.data

import android.content.Context
import android.net.Uri
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.lisan.data.db.ProcessingJobDao
import com.lisan.data.db.ProcessingJobEntity
import com.lisan.domain.model.ProcessingStage
import com.lisan.domain.model.ProjectStatus
import com.lisan.domain.repository.ProjectRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.io.File
import java.time.Instant

@HiltWorker
class RenderWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted params: WorkerParameters,
    private val jobs: ProcessingJobDao,
    private val projects: ProjectRepository,
    private val backend: LisanBackendClient,
    private val notifications: LisanNotificationManager
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val projectId = inputData.getString("projectId") ?: return Result.failure(workDataOf("error" to "MISSING_PROJECT_ID"))
        val project = projects.get(projectId) ?: return Result.failure(workDataOf("error" to "PROJECT_NOT_FOUND"))
        val srtPath = inputData.getString("srtPath") ?: return Result.failure(workDataOf("error" to "MISSING_SRT_PATH"))
        val srt = File(srtPath)
        if (!srt.exists() || srt.length() == 0L) return Result.failure(workDataOf("error" to "SRT_NOT_FOUND"))
        val root = File(applicationContext.filesDir, "processing/$projectId").apply { mkdirs() }
        try {
            setForeground(notifications.foregroundInfo(project.name, 84, "جاري تجهيز الفيديو النهائي…"))
            projects.save(project.copy(status = ProjectStatus.PROCESSING, progress = 84, updatedAt = Instant.now(), error = null))
            val sourceFile = File(root, "source.mp4")
            if (!sourceFile.exists() || sourceFile.length() == 0L) {
                applicationContext.contentResolver.openInputStream(Uri.parse(project.sourceUri)).use { input ->
                    requireNotNull(input) { "SOURCE_VIDEO_NOT_READABLE" }
                    sourceFile.outputStream().use { output -> input.copyTo(output, 1024 * 1024) }
                }
            }
            require(sourceFile.length() > 0) { "SOURCE_VIDEO_EMPTY" }
            val previous = jobs.get(projectId)
            val session = previous?.uploadId?.let { runCatching { backend.uploadStatus(it) }.getOrNull() } ?: backend.initUpload(sourceFile)
            jobs.upsert(ProcessingJobEntity(projectId, ProcessingStage.RENDERING.name, 88, System.currentTimeMillis(), "Uploading source video", session.uploadId))
            val uploaded = backend.uploadResumable(sourceFile, session)
            val a = project.subtitleAppearance
            val ocrFile = File(root, "ocr_overlays.json").takeIf { it.exists() && it.length() > 0L }
            val karaokeEnabled = inputData.getBoolean("karaokeEnabled", false)
            val karaokeFile = File(root, "translated_word_alignment.json").takeIf { karaokeEnabled && it.exists() && it.length() > 0L }
            var renderJob = backend.renderUploadedAsync(uploaded.uploadId, srt, ocrFile, karaokeFile, project.subtitleStyle.wireName, a.fontSizeSp, a.position.name, a.shape.wireName, a.outlineWidth, a.shadowDepth, a.safeHorizontal, a.safeVertical)
            var attempts = 0
            while (renderJob.status == "queued" || renderJob.status == "running") {
                kotlinx.coroutines.delay(2000L)
                renderJob = backend.renderJobStatus(renderJob.jobId)
                attempts++
                if (attempts % 5 == 0) {
                    projects.save(project.copy(status = ProjectStatus.PROCESSING, progress = (88 + (renderJob.progress * 6 / 100)).coerceAtMost(94), updatedAt = Instant.now()))
                }
                if (attempts > 900) throw IllegalStateException("RENDER_JOB_TIMEOUT")
            }
            require(renderJob.status == "completed" && renderJob.result != null) { "RENDER_JOB_FAILED" }
            val resultJson = requireNotNull(renderJob.result)
            val render = RenderResult(
                status = resultJson.getString("status"),
                artifactId = resultJson.getString("artifact_id"),
                filename = resultJson.getString("filename"),
                durationSeconds = resultJson.getDouble("duration_seconds"),
                sizeBytes = resultJson.getLong("size_bytes"),
                hasVideo = resultJson.getBoolean("has_video"),
                hasAudio = resultJson.getBoolean("has_audio"),
                validationValid = resultJson.optJSONObject("validation")?.optBoolean("valid", false) == true
            )
            require(render.status == "validated" && render.validationValid && render.hasVideo && render.durationSeconds > 0 && render.sizeBytes > 0) { "RENDER_VALIDATION_FAILED" }
            projects.save(project.copy(status = ProjectStatus.PROCESSING, progress = 95, updatedAt = Instant.now()))
            jobs.upsert(ProcessingJobEntity(projectId, ProcessingStage.VALIDATING.name, 95, System.currentTimeMillis(), "Downloading final video"))
            val output = File(root, "translated_video.mp4")
            backend.downloadArtifact(render.artifactId, output)
            require(output.length() == render.sizeBytes) { "DOWNLOADED_ARTIFACT_SIZE_MISMATCH" }
            runCatching { backend.deleteUpload(uploaded.uploadId) }
            projects.save(project.copy(status = ProjectStatus.COMPLETED, progress = 100, updatedAt = Instant.now(), error = null, outputPath = output.absolutePath, artifactId = render.artifactId))
            jobs.upsert(ProcessingJobEntity(projectId, ProcessingStage.COMPLETED.name, 100, System.currentTimeMillis(), "Translation completed"))
            notifications.completed(project.name)
            Result.success(workDataOf("projectId" to projectId, "outputPath" to output.absolutePath, "artifactId" to render.artifactId, "progress" to 100))
        } catch (t: Throwable) {
            val message = t.message ?: t::class.java.simpleName
            if (message.contains("network", true) || message.startsWith("BACKEND_5") || message.startsWith("HTTP_5")) {
                notifications.waitingForNetwork(project.name)
                return Result.retry()
            }
            projects.save(project.copy(status = ProjectStatus.FAILED, updatedAt = Instant.now(), error = message))
            jobs.upsert(ProcessingJobEntity(projectId, ProcessingStage.FAILED.name, 0, System.currentTimeMillis(), message))
            notifications.failed(project.name, message)
            Result.failure(workDataOf("error" to message))
        }
    }
}
