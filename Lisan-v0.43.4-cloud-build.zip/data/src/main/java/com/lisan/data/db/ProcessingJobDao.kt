package com.lisan.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProcessingJobDao {
    @Query("SELECT * FROM processing_jobs WHERE projectId = :projectId")
    fun observe(projectId: String): Flow<ProcessingJobEntity?>

    @Query("SELECT * FROM processing_jobs WHERE projectId = :projectId")
    suspend fun get(projectId: String): ProcessingJobEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(job: ProcessingJobEntity)
}
