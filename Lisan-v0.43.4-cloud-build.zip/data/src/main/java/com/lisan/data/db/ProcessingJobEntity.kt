package com.lisan.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "processing_jobs")
data class ProcessingJobEntity(
    @PrimaryKey val projectId: String,
    val stage: String,
    val progress: Int,
    val updatedAt: Long,
    val error: String? = null,
    val uploadId: String? = null
)
