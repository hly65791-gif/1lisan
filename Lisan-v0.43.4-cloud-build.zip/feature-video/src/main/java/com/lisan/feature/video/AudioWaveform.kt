package com.lisan.feature.video

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.sqrt

/** Extracts a compact PCM RMS waveform without loading the whole audio file into RAM. */
object AudioWaveformExtractor {
    suspend fun extract(path: String, bars: Int = 180): List<Float> = withContext(Dispatchers.Default) {
        runCatching { decode(path, bars.coerceIn(60, 600)) }.getOrDefault(emptyList())
    }

    private fun decode(path: String, bars: Int): List<Float> {
        val extractor = MediaExtractor()
        extractor.setDataSource(path)
        var track = -1
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            if (format.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { track = i; break }
        }
        if (track < 0) { extractor.release(); return emptyList() }
        extractor.selectTrack(track)
        val format = extractor.getTrackFormat(track)
        val mime = format.getString(MediaFormat.KEY_MIME) ?: run { extractor.release(); return emptyList() }
        val decoder = MediaCodec.createDecoderByType(mime)
        decoder.configure(format, null, null, 0)
        decoder.start()
        val values = ArrayList<Float>(bars * 8)
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        try {
            while (!outputDone && values.size < bars * 40) {
                if (!inputDone) {
                    val inputIndex = decoder.dequeueInputBuffer(10_000)
                    if (inputIndex >= 0) {
                        val input = decoder.getInputBuffer(inputIndex) ?: continue
                        input.clear()
                        val size = extractor.readSampleData(input, 0)
                        if (size < 0) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            decoder.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outputIndex = decoder.dequeueOutputBuffer(info, 10_000)
                when {
                    outputIndex >= 0 -> {
                        val output = decoder.getOutputBuffer(outputIndex)
                        if (output != null && info.size > 0) {
                            output.position(info.offset.coerceAtLeast(0))
                            output.limit((info.offset + info.size).coerceAtMost(output.capacity()))
                            collectPcm16(output, values)
                        }
                        decoder.releaseOutputBuffer(outputIndex, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    }
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> Unit
                }
            }
        } finally {
            runCatching { decoder.stop() }
            decoder.release()
            extractor.release()
        }
        if (values.isEmpty()) return emptyList()
        val result = MutableList(bars) { 0f }
        for (i in result.indices) {
            val start = (i * values.size / bars).coerceIn(0, values.lastIndex)
            val end = (((i + 1) * values.size / bars).coerceAtLeast(start + 1)).coerceAtMost(values.size)
            var sum = 0f
            for (j in start until end) sum += values[j]
            result[i] = (sum / (end - start)).coerceIn(0f, 1f)
        }
        val max = result.maxOrNull()?.takeIf { it > 0f } ?: 1f
        result.map { (it / max).coerceIn(0f, 1f) }
    }

    private fun collectPcm16(buffer: ByteBuffer, values: MutableList<Float>) {
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        var sum = 0.0
        var count = 0
        var i = 0
        while (i + 1 < bytes.size) {
            val lo = bytes[i].toInt() and 0xff
            val hi = bytes[i + 1].toInt()
            val sample = (hi shl 8) or lo
            val signed = if (sample and 0x8000 != 0) sample - 0x10000 else sample
            sum += abs(signed / 32768.0)
            count++
            i += 2
            if (count >= 512) {
                values.add(sqrt(sum / count).toFloat())
                sum = 0.0
                count = 0
            }
        }
        if (count > 0) values.add(sqrt(sum / count).toFloat())
    }
}
