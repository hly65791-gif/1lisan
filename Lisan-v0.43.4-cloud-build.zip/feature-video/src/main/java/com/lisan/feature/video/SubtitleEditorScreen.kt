package com.lisan.feature.video

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.work.*
import com.lisan.data.RenderWorker
import com.lisan.data.LisanBackendClient
import com.lisan.domain.model.*
import com.lisan.domain.provider.TranscriptSegment
import com.lisan.domain.provider.TranscriptWord
import com.lisan.domain.repository.ProjectRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.Instant
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import kotlin.math.roundToInt

@HiltViewModel
class SubtitleEditorViewModel @Inject constructor(
    private val repository: ProjectRepository,
    @ApplicationContext private val context: Context,
    private val backend: LisanBackendClient
) : ViewModel() {
    var project by mutableStateOf<Project?>(null); private set
    var subtitles by mutableStateOf<List<Subtitle>>(emptyList()); private set
    var ocrOverlays by mutableStateOf<List<OcrOverlay>>(emptyList()); private set
    var appearance by mutableStateOf(SubtitleAppearance()); private set
    var selectedIndex by mutableIntStateOf(0); private set
    var selectedOcrIndex by mutableIntStateOf(-1); private set
    var error by mutableStateOf<String?>(null); private set
    var message by mutableStateOf<String?>(null); private set
    var wordTimings by mutableStateOf<List<WordTiming>>(emptyList()); private set
    var waveform by mutableStateOf<List<Float>>(emptyList()); private set
    var karaokeEnabled by mutableStateOf(false); private set
    private var history: SubtitleEditorHistory? = null

    fun load(projectId: String) {
        if (project?.id == projectId && subtitles.isNotEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            val p = repository.get(projectId)
            if (p == null) { error = "المشروع غير موجود"; return@launch }
            val root = File(context.filesDir, "processing/$projectId")
            val srt = File(root, "translated.srt")
            if (!srt.exists()) { error = "ملف الترجمة غير موجود"; return@launch }
            val parsed = parseSrt(srt.readText())
            project = p
            history = SubtitleEditorHistory(parsed)
            subtitles = history!!.current
            appearance = p.subtitleAppearance
            selectedIndex = 0
            ocrOverlays = readOcr(File(root, "ocr_overlays.json"))
            val alignedFile = File(root, "translated_word_alignment.json")
            wordTimings = if (alignedFile.exists() && alignedFile.length() > 0L) readAlignedWordTimings(alignedFile) else emptyList()
            waveform = AudioWaveformExtractor.extract(File(root, "audio.m4a").absolutePath)
        }
    }

    private fun replace(next: List<Subtitle>) {
        history?.replace(next)
        subtitles = history?.current ?: next
        selectedIndex = selectedIndex.coerceIn(0, (subtitles.lastIndex).coerceAtLeast(0))
        // Subtitle edits invalidate translated word alignment; require an explicit re-alignment.
        if (wordTimings.isNotEmpty()) {
            wordTimings = emptyList()
            karaokeEnabled = false
        }
    }

    fun undo() { history?.undo()?.let { subtitles = it } }
    fun redo() { history?.redo()?.let { subtitles = it } }
    fun canUndo() = history?.canUndo() == true
    fun canRedo() = history?.canRedo() == true
    fun select(index: Int) { selectedIndex = index.coerceIn(0, subtitles.lastIndex.coerceAtLeast(0)) }
    fun selectOcr(index: Int) { selectedOcrIndex = index.coerceIn(-1, ocrOverlays.lastIndex) }

    fun updateText(index: Int, text: String) = replace(subtitles.mapIndexed { i, s -> if (i == index) s.copy(text = text) else s })
    fun updateStartMs(index: Int, value: Long) {
        val item = subtitles.getOrNull(index) ?: return
        val start = value.coerceAtLeast(0).coerceAtMost(item.endMs - 200)
        replace(subtitles.mapIndexed { i, s -> if (i == index) s.copy(startMs = start) else s })
    }
    fun updateEndMs(index: Int, value: Long) {
        val item = subtitles.getOrNull(index) ?: return
        val end = value.coerceAtLeast(item.startMs + 200)
        replace(subtitles.mapIndexed { i, s -> if (i == index) s.copy(endMs = end) else s })
    }

    fun updateSelectedStartFromTimeline(ms: Long) = updateStartMs(selectedIndex, ms)
    fun updateSelectedEndFromTimeline(ms: Long) = updateEndMs(selectedIndex, ms)

    fun shiftSelected(deltaMs: Long) {
        val item = subtitles.getOrNull(selectedIndex) ?: return
        val duration = item.endMs - item.startMs
        val start = (item.startMs + deltaMs).coerceAtLeast(0)
        replace(subtitles.mapIndexed { i, s -> if (i == selectedIndex) s.copy(startMs = start, endMs = start + duration) else s })
    }
    fun delete(index: Int) = replace(subtitles.filterIndexed { i, _ -> i != index })
    fun add() {
        val start = subtitles.lastOrNull()?.endMs ?: 0L
        replace(subtitles + Subtitle(subtitles.size + 1, start, start + 2000, "نص جديد"))
        selectedIndex = subtitles.lastIndex
    }

    fun splitSelected() {
        val item = subtitles.getOrNull(selectedIndex) ?: return
        val words = item.text.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (item.endMs - item.startMs < 400 || words.size < 2) { message = "يحتاج السطر إلى كلمتين على الأقل ومدة كافية للتقسيم"; return }
        val midpoint = item.startMs + (item.endMs - item.startMs) / 2
        val cut = words.size / 2
        val first = item.copy(endMs = midpoint, text = words.take(cut).joinToString(" "))
        val second = item.copy(index = item.index + 1, startMs = midpoint, text = words.drop(cut).joinToString(" "))
        replace(subtitles.flatMapIndexed { i, s -> if (i == selectedIndex) listOf(first, second) else listOf(s) }.renumber())
        message = "تم تقسيم السطر"
    }

    fun mergeSelectedWithNext() {
        if (selectedIndex !in subtitles.indices || selectedIndex >= subtitles.lastIndex) { message = "اختر سطرًا له سطر تالٍ"; return }
        val a = subtitles[selectedIndex]; val b = subtitles[selectedIndex + 1]
        val merged = a.copy(endMs = maxOf(a.endMs, b.endMs), text = "${a.text.trim()} ${b.text.trim()}".trim())
        replace(subtitles.toMutableList().apply { removeAt(selectedIndex + 1); this[selectedIndex] = merged }.renumber())
        message = "تم دمج السطرين"
    }

    /** Align translated subtitle timings to the original STT timing file. */
    fun autoSync() {
        val p = project ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val file = File(context.filesDir, "processing/${p.id}/transcript.json")
            if (!file.exists()) { message = "النص الأصلي غير متوفر للمزامنة"; return@launch }
            val arr = runCatching { JSONArray(file.readText()) }.getOrNull()
            if (arr == null || arr.length() == 0) { message = "لا توجد توقيتات صوتية للمزامنة"; return@launch }
            val synced = subtitles.mapIndexed { index, item ->
                val sourceIndex = if (arr.length() == subtitles.size) index else ((index.toDouble() / subtitles.size.coerceAtLeast(1)) * arr.length()).toInt().coerceAtMost(arr.length() - 1)
                val source = arr.getJSONObject(sourceIndex)
                item.copy(startMs = source.optLong("start_ms", item.startMs), endMs = maxOf(source.optLong("end_ms", item.endMs), source.optLong("start_ms", item.startMs) + 200))
            }.renumber()
            history?.replace(synced); subtitles = history?.current ?: synced
            message = "تمت المزامنة مع توقيت الكلام الأصلي"
        }
    }

    fun alignTranslatedWords() {
        val p = project ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val file = File(context.filesDir, "processing/${p.id}/transcript.json")
            if (!file.exists()) { message = "التوقيت الأصلي غير متوفر"; return@launch }
            val source = runCatching {
                val arr = JSONArray(file.readText())
                List(arr.length()) { i ->
                    val o = arr.getJSONObject(i)
                    val wordsJson = o.optJSONArray("words") ?: JSONArray()
                    val words = List(wordsJson.length()) { j ->
                        val w = wordsJson.getJSONObject(j)
                        TranscriptWord(w.optLong("start_ms"), w.optLong("end_ms"), w.optString("text"), w.optDouble("confidence").takeIf { !it.isNaN() }?.toFloat())
                    }
                    TranscriptSegment(o.optLong("start_ms"), o.optLong("end_ms"), o.optString("text"), o.optDouble("confidence").takeIf { !it.isNaN() }?.toFloat(), words)
                }
            }.getOrElse { message = "تعذر قراءة النص الأصلي"; return@launch }
            val translated = subtitles.map { TranscriptSegment(it.startMs, it.endMs, it.text) }
            runCatching { backend.align(source, translated) }.onSuccess { aligned ->
                val flat = aligned.flatten().map { WordTiming(it.startMs, it.endMs, it.text) }
                wordTimings = flat
                File(file.parentFile, "translated_word_alignment.json").writeText(
                    JSONArray().apply { aligned.forEach { segment -> put(JSONArray().apply { segment.forEach { w -> put(JSONObject().apply { put("start_ms", w.startMs); put("end_ms", w.endMs); put("text", w.text); w.sourceWordIndex?.let { put("source_word_index", it) } }) } }) } }.toString()
                )
                message = "تمت محاذاة كلمات الترجمة فعليًا عبر مزود المحاذاة"
            }.onFailure { message = it.message ?: "فشل مزود المحاذاة" }
        }
    }

    fun setAppearance(value: SubtitleAppearance) { appearance = value }
    fun setKaraokeEnabled(value: Boolean) { karaokeEnabled = value }
    fun setPreset(value: SubtitlePosition) { appearance = appearance.withPreset(value) }
    fun dragAppearance(dx: Float, dy: Float, width: Float, height: Float) {
        if (width <= 0 || height <= 0) return
        appearance = appearance.copy(position = SubtitlePosition.CUSTOM, horizontalPercent = (appearance.safeHorizontal + dx / width * 100f).roundToInt().coerceIn(8,92), verticalPercent = (appearance.safeVertical + dy / height * 100f).roundToInt().coerceIn(8,92))
    }

    fun updateOcr(index: Int, text: String? = null, x: Int? = null, y: Int? = null, enabled: Boolean? = null, fontSize: Int? = null, outline: Int? = null, shadow: Int? = null, bold: Boolean? = null, replaceOriginal: Boolean? = null, tracking: Boolean? = null) {
        ocrOverlays = ocrOverlays.mapIndexed { i, o -> if (i == index) o.copy(text = text ?: o.text, xPercent = x ?: o.xPercent, yPercent = y ?: o.yPercent, enabled = enabled ?: o.enabled, fontSizeSp = fontSize ?: o.fontSizeSp, outlineWidth = outline ?: o.outlineWidth, shadowDepth = shadow ?: o.shadowDepth, bold = bold ?: o.bold, replaceOriginal = replaceOriginal ?: o.replaceOriginal, motionTrackingEnabled = tracking ?: o.motionTrackingEnabled) else o }
    }
    fun addOcrKeyframe(index: Int, timeMs: Long) {
        val item = ocrOverlays.getOrNull(index) ?: return
        val t = timeMs.coerceIn(item.startMs, item.endMs)
        val next = item.keyframes.filterNot { kotlin.math.abs(it.timeMs - t) < 80L } + OcrKeyframe(t, item.safeX, item.safeY, item.widthPercent, item.heightPercent)
        ocrOverlays = ocrOverlays.mapIndexed { i, o -> if (i == index) o.copy(motionTrackingEnabled = true, keyframes = next.sortedBy { it.timeMs }) else o }
    }
    fun dragOcr(index: Int, dx: Float, dy: Float, width: Float, height: Float, positionMs: Long = 0L) {
        val item = ocrOverlays.getOrNull(index) ?: return
        if (width <= 0 || height <= 0) return
        val nx = (item.safeX + dx / width * 100f).roundToInt().coerceIn(5,95)
        val ny = (item.safeY + dy / height * 100f).roundToInt().coerceIn(5,95)
        if (!item.motionTrackingEnabled) updateOcr(index, x = nx, y = ny)
        else {
            val t = positionMs.coerceIn(item.startMs, item.endMs)
            val next = item.keyframes.filterNot { kotlin.math.abs(it.timeMs - t) < 80L } + OcrKeyframe(t, nx, ny, item.widthPercent, item.heightPercent)
            ocrOverlays = ocrOverlays.mapIndexed { i, o -> if (i == index) o.copy(keyframes = next.sortedBy { it.timeMs }) else o }
        }
    }

    fun saveAndRender(workManager: WorkManager, onDone: () -> Unit) {
        val p = project ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val root = File(context.filesDir, "processing/${p.id}").apply { mkdirs() }
            val srt = File(root, "translated.srt")
            val ocr = File(root, "ocr_overlays.json")
            srt.writeText(SubtitleFormatter.toSrt(subtitles.renumber()))
            ocr.writeText(JSONArray().apply { ocrOverlays.forEach { put(JSONObject().apply { put("id", it.id); put("start_ms", it.startMs); put("end_ms", it.endMs); put("text", it.text); put("x_percent", it.safeX); put("y_percent", it.safeY); put("enabled", it.enabled); put("font_size_sp", it.fontSizeSp); put("outline_width", it.outlineWidth); put("shadow_depth", it.shadowDepth); put("bold", it.bold); put("replace_original", it.replaceOriginal); put("width_percent", it.widthPercent); put("height_percent", it.heightPercent); put("motion_tracking_enabled", it.motionTrackingEnabled); put("keyframes", JSONArray().apply { it.keyframes.forEach { k -> put(JSONObject().apply { put("time_ms", k.timeMs); put("x_percent", k.xPercent); put("y_percent", k.yPercent); put("width_percent", k.widthPercent); put("height_percent", k.heightPercent) }) } }) }) } }.toString())
            repository.save(p.copy(status = ProjectStatus.QUEUED, progress = 82, updatedAt = Instant.now(), error = null, subtitleAppearance = appearance))
            val request = OneTimeWorkRequestBuilder<RenderWorker>().setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS).setInputData(workDataOf("projectId" to p.id, "srtPath" to srt.absolutePath, "karaokeEnabled" to karaokeEnabled)).build()
            workManager.enqueueUniqueWork("lisan_render_${p.id}", ExistingWorkPolicy.REPLACE, request)
            onDone()
        }
    }

    private fun readOcr(file: File): List<OcrOverlay> = runCatching {
        if (!file.exists()) return emptyList()
        val arr = JSONArray(file.readText())
        List(arr.length()) { i -> val o = arr.getJSONObject(i); OcrOverlay(o.optInt("id", i + 1), o.optLong("start_ms"), o.optLong("end_ms", o.optLong("start_ms") + 2000), o.optString("text"), o.optInt("x_percent", 50), o.optInt("y_percent", 50), o.optBoolean("enabled", true), o.optInt("font_size_sp", 42), o.optInt("outline_width", 3), o.optInt("shadow_depth", 1), o.optBoolean("bold", true), o.optBoolean("replace_original", false), o.optInt("width_percent", 20), o.optInt("height_percent", 10), o.optBoolean("motion_tracking_enabled", false), buildList { val ks=o.optJSONArray("keyframes") ?: return@buildList; for (j in 0 until ks.length()) { val k=ks.getJSONObject(j); add(OcrKeyframe(k.optLong("time_ms"), k.optInt("x_percent", 50), k.optInt("y_percent", 50), k.optInt("width_percent", 20), k.optInt("height_percent", 10))) } }) }
    }.getOrDefault(emptyList())

    private fun readWordTimings(file: File): List<WordTiming> = runCatching {
        if (!file.exists()) return emptyList()
        val arr = JSONArray(file.readText())
        buildList {
            for (i in 0 until arr.length()) {
                val words = arr.getJSONObject(i).optJSONArray("words") ?: continue
                for (j in 0 until words.length()) {
                    val w = words.getJSONObject(j)
                    add(WordTiming(w.optLong("start_ms"), w.optLong("end_ms"), w.optString("text")))
                }
            }
        }
    }.getOrDefault(emptyList())

    private fun readAlignedWordTimings(file: File): List<WordTiming> = runCatching {
        val arr = JSONArray(file.readText())
        buildList {
            for (i in 0 until arr.length()) {
                val segment = arr.optJSONArray(i) ?: continue
                for (j in 0 until segment.length()) {
                    val w = segment.optJSONObject(j) ?: continue
                    val start = w.optLong("start_ms", -1L)
                    val end = w.optLong("end_ms", -1L)
                    val text = w.optString("text").trim()
                    if (start >= 0L && end > start && text.isNotBlank()) add(WordTiming(start, end, text))
                }
            }
        }
    }.getOrDefault(emptyList())

    private fun parseSrt(raw: String): List<Subtitle> = raw.replace("\r\n", "\n").replace("\r", "\n").split("\n\n").mapNotNull { block ->
        val lines = block.lines().filter { it.isNotBlank() }; if (lines.size < 3 || !lines[1].contains("-->")) return@mapNotNull null
        val (a,b)=lines[1].split("-->",limit=2).map { it.trim() }; val start=parseTime(a)?:return@mapNotNull null; val end=parseTime(b)?:return@mapNotNull null
        Subtitle(lines[0].toIntOrNull()?:0,start,maxOf(end,start+200),lines.drop(2).joinToString("\n"))
    }.renumber()
    private fun parseTime(value: String): Long? { val parts=value.replace('.',',').split(','); if(parts.size!=2)return null; val hms=parts[0].split(':').map{it.toLongOrNull()?:return null}; if(hms.size!=3)return null; return ((hms[0]*3600+hms[1]*60+hms[2])*1000)+(parts[1].take(3).padEnd(3,'0').toLongOrNull()?:0) }
}

private fun List<Subtitle>.renumber() = mapIndexed { i, s -> s.copy(index = i + 1) }

@Composable
fun SubtitleEditorScreen(projectId: String, onBack: () -> Unit, vm: SubtitleEditorViewModel = hiltViewModel()) {
    val context = LocalContext.current; val workManager = remember { WorkManager.getInstance(context) }; LaunchedEffect(projectId) { vm.load(projectId) }
    val p=vm.project
    val player=remember(p?.sourceUri){p?.let{ExoPlayer.Builder(context).build().apply{setMediaItem(MediaItem.fromUri(Uri.parse(it.sourceUri)));prepare();playWhenReady=false;}}}
    DisposableEffect(player){onDispose{player?.release()}}
    var positionMs by remember{mutableLongStateOf(0)}; var durationMs by remember{mutableLongStateOf(1)}
    LaunchedEffect(player){while(player!=null){positionMs=player.currentPosition.coerceAtLeast(0);durationMs=player.duration.takeIf{it>0}?:1; kotlinx.coroutines.delay(100)}}
    val activeIndex=vm.subtitles.indexOfFirst{positionMs in it.startMs..it.endMs}.takeIf{it>=0}?:vm.selectedIndex; val active=vm.subtitles.getOrNull(activeIndex)
    Scaffold(topBar={TopAppBar(title={Text("محرر الترجمة")},navigationIcon={TextButton(onClick=onBack){Text("رجوع")}},actions={TextButton(enabled=vm.canUndo(),onClick=vm::undo){Text("تراجع")};TextButton(enabled=vm.canRedo(),onClick=vm::redo){Text("إعادة")}})}){padding->
        if(p==null){Box(Modifier.fillMaxSize().padding(padding),contentAlignment=Alignment.Center){Text(vm.error?:"جاري التحميل…")};return@Scaffold}
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal=12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            item{SubtitleVideoPreview(player,active,vm.appearance,vm.ocrOverlays,vm.selectedOcrIndex,vm.karaokeEnabled,vm.wordTimings,positionMs,vm::dragAppearance,vm::dragOcr)}
            item{
                Text("Timeline احترافي",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
                Text("اسحب طرفي السطر المحدد لتعديل البداية والنهاية • استخدم التكبير لرؤية التفاصيل",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
                ProfessionalTimeline(
                    subtitles = vm.subtitles,
                    words = vm.wordTimings,
                    waveform = vm.waveform,
                    selectedIndex = vm.selectedIndex,
                    positionMs = positionMs,
                    durationMs = durationMs,
                    onSeek = { player?.seekTo(it) },
                    onSelect = { vm.select(it) },
                    onStart = vm::updateSelectedStartFromTimeline,
                    onEnd = vm::updateSelectedEndFromTimeline
                )
                Slider(value=(positionMs.toFloat()/durationMs).coerceIn(0f,1f),onValueChange={player?.seekTo((it*durationMs).toLong())})
                Text("${formatMs(positionMs)} / ${formatMs(durationMs)}",color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item{Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={player?.playWhenReady=true}){Text("تشغيل")};OutlinedButton(onClick={vm::splitSelected}){Text("تقسيم")};OutlinedButton(onClick={vm::mergeSelectedWithNext}){Text("دمج التالي")};OutlinedButton(onClick={vm::autoSync}){Text("مزامنة تلقائية")};OutlinedButton(onClick={vm::alignTranslatedWords}){Text("محاذاة الكلمات")}};Card{Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Karaoke / إبراز الكلمات",fontWeight=FontWeight.Bold);Text(if(vm.wordTimings.isEmpty())"أجرِ محاذاة الكلمات أولًا" else "إبراز الكلمة الحالية أثناء التشغيل والتصدير",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)};Switch(checked=vm.karaokeEnabled,onCheckedChange=vm::setKaraokeEnabled,enabled=vm.wordTimings.isNotEmpty())}}}}
            item{Text("شكل الترجمة",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Text("الحجم ${vm.appearance.fontSizeSp}");Slider(value=vm.appearance.fontSizeSp.toFloat(),onValueChange={vm.setAppearance(vm.appearance.copy(fontSizeSp=it.roundToInt()))},valueRange=28f..90f);SingleChoiceRow(SubtitlePosition.entries.map{it.label},SubtitlePosition.entries.indexOf(vm.appearance.position)){vm.setPreset(SubtitlePosition.entries[it])};SingleChoiceRow(SubtitleShape.entries.map{it.label},SubtitleShape.entries.indexOf(vm.appearance.shape)){vm.setAppearance(vm.appearance.copy(shape=SubtitleShape.entries[it]))};Text("الموضع: ${vm.appearance.safeHorizontal}% × ${vm.appearance.safeVertical}%")}
            item{Text("النص والتوقيت",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}
            itemsIndexed(vm.subtitles,key={_,s->s.index}){index,s->SubtitleEditCard(s,index==vm.selectedIndex,{vm.select(index);player?.seekTo(s.startMs)},{vm.updateText(index,it)},{vm.updateStartMs(index,it)},{vm.updateEndMs(index,it)},{vm.delete(index)})}
            item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick=vm::add){Text("إضافة سطر")};Text("السطر المحدد: ${vm.selectedIndex+1}",modifier=Modifier.align(Alignment.CenterVertically))}}
            item{Text("النصوص داخل الفيديو OCR",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Text("يمكن تعديل النص، إخفاؤه، وسحبه إلى موضعه قبل الحرق.",color=MaterialTheme.colorScheme.onSurfaceVariant)}
            itemsIndexed(vm.ocrOverlays,key={_,o->o.id}){index,o->OcrEditCard(o,index==vm.selectedOcrIndex,{vm.selectOcr(index)},{vm.updateOcr(index,text=it)},{vm.updateOcr(index,enabled=it)},{font->vm.updateOcr(index,fontSize=font)},{outline->vm.updateOcr(index,outline=outline)},{shadow->vm.updateOcr(index,shadow=shadow)},{bold->vm.updateOcr(index,bold=bold)},{replace->vm.updateOcr(index,replaceOriginal=replace)},{tracking->vm.updateOcr(index,tracking=tracking)},{vm.addOcrKeyframe(index,player?.currentPosition ?: o.startMs)})}
            item{Button(onClick={vm.saveAndRender(workManager,onBack)},modifier=Modifier.fillMaxWidth()){Text("حفظ + معاينة نهائية + بدء الحرق")};vm.message?.let{Text(it,color=MaterialTheme.colorScheme.primary)};vm.error?.let{Text(it,color=MaterialTheme.colorScheme.error)};Spacer(Modifier.height(24.dp))}
        }
    }
}

@Composable private fun SubtitleVideoPreview(player:ExoPlayer?,active:Subtitle?,appearance:SubtitleAppearance,ocr:List<OcrOverlay>,selectedOcr:Int,karaokeEnabled:Boolean,words:List<WordTiming>,positionMs:Long,onDrag:(Float,Float,Float,Float)->Unit,onOcrDrag:(Int,Float,Float,Float,Float,Long)->Unit){
    BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(16f/9f).clip(RoundedCornerShape(18.dp)).background(Color.Black)){
        if(player!=null)AndroidView(factory={PlayerView(it).apply{this.player=player;useController=true;resizeMode=AspectRatioFrameLayout.RESIZE_MODE_FIT}},modifier=Modifier.fillMaxSize())
        if(active!=null){val x=maxWidth*(appearance.safeHorizontal/100f);val y=maxHeight*(appearance.safeVertical/100f);val d=androidx.compose.ui.platform.LocalDensity.current;Box(Modifier.offset{IntOffset((x.toPx()-(maxWidth/2).toPx()).roundToInt(),(y.toPx()-(maxHeight/2).toPx()).roundToInt())}.pointerInput(appearance.safeHorizontal,appearance.safeVertical){detectDragGestures{c,a->c.consume();onDrag(a.x,a.y,size.width.toFloat(),size.height.toFloat())}}.background(if(appearance.shape==SubtitleShape.BOX||appearance.shape==SubtitleShape.ROUNDED_BOX)Color.Black.copy(.65f)else Color.Transparent,RoundedCornerShape(10.dp)).padding(10.dp)){Text(
                text = if (karaokeEnabled) {
                    val activeWords = words.filter { it.startMs >= active.startMs && it.endMs <= active.endMs }
                    if (activeWords.isNotEmpty()) buildAnnotatedString {
                        activeWords.forEachIndexed { index, word ->
                            val isCurrent = positionMs in word.startMs..word.endMs
                            if (isCurrent) {
                                pushStyle(SpanStyle(color = Color(0xFF66E0C2)))
                                append(word.text.trim())
                                pop()
                            } else {
                                append(word.text.trim())
                            }
                            if (index < activeWords.lastIndex) append(" ")
                        }
                    } else active.text
                } else active.text,
                color=Color.White,fontSize=appearance.fontSizeSp.sp,fontWeight=FontWeight.Bold)}}
        ocr.filter{it.enabled}.forEachIndexed{visibleIndex,item->val actual=ocr.indexOf(item);val x=maxWidth*(item.safeX/100f);val y=maxHeight*(item.safeY/100f);val d=androidx.compose.ui.platform.LocalDensity.current;Box(Modifier.offset{IntOffset((x.toPx()-(maxWidth/2).toPx()).roundToInt(),(y.toPx()-(maxHeight/2).toPx()).roundToInt())}.pointerInput(item.safeX,item.safeY){detectDragGestures{c,a->c.consume();onOcrDrag(actual,a.x,a.y,size.width.toFloat(),size.height.toFloat(),positionMs)}}.border(1.dp,if(actual==selectedOcr)Color.Cyan else Color.White.copy(.35f),RoundedCornerShape(6.dp)).background(Color.Black.copy(.55f)).padding(6.dp)){Text(item.text,color=Color.White,fontSize=15.sp)}}
    }
}

data class WordTiming(val startMs: Long, val endMs: Long, val text: String)

@Composable
private fun ProfessionalTimeline(
    subtitles: List<Subtitle>,
    words: List<WordTiming>,
    waveform: List<Float>,
    selectedIndex: Int,
    positionMs: Long,
    durationMs: Long,
    onSeek: (Long) -> Unit,
    onSelect: (Int) -> Unit,
    onStart: (Long) -> Unit,
    onEnd: (Long) -> Unit
) {
    var zoom by remember { mutableFloatStateOf(1f) }
    val scrollState = rememberScrollState()
    val selected = subtitles.getOrNull(selectedIndex)

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Zoom", fontSize = 12.sp)
            Slider(value = zoom, onValueChange = { zoom = it }, valueRange = 1f..6f, modifier = Modifier.weight(1f))
            Text("${"%.1f".format(zoom)}×", fontSize = 12.sp)
        }
        Text(
            if (zoom > 1f) "مرر أفقيًا لرؤية التفاصيل • المؤشر يتحرك تلقائيًا مع التشغيل" else "اسحب طرفي السطر المحدد • اضغط على أي نقطة للانتقال إليها",
            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        BoxWithConstraints(Modifier.fillMaxWidth().height(170.dp)) {
            val canvasWidth = maxWidth * zoom
            val viewportPx = with(androidx.compose.ui.platform.LocalDensity.current) { maxWidth.toPx() }
            LaunchedEffect(positionMs, zoom, durationMs, viewportPx, scrollState.maxValue) {
                if (durationMs <= 0L || scrollState.maxValue <= 0) return@LaunchedEffect
                val contentWidthPx = viewportPx + scrollState.maxValue
                val playX = positionMs.toFloat() / durationMs * contentWidthPx
                val target = (playX - viewportPx * 0.35f).coerceIn(0f, scrollState.maxValue.toFloat()).roundToInt()
                scrollState.animateScrollTo(target)
            }
            Box(Modifier.fillMaxSize().horizontalScroll(scrollState)) {
                Canvas(
                    Modifier
                        .width(canvasWidth)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF071A32))
                        .pointerInput(durationMs, zoom, selectedIndex, subtitles) {
                            detectTapGestures { offset ->
                                val width = size.width.toFloat().coerceAtLeast(1f)
                                val ms = (offset.x / width * durationMs).toLong().coerceIn(0L, durationMs)
                                val index = subtitles.indexOfFirst { ms in it.startMs..it.endMs }
                                if (index >= 0) onSelect(index) else onSeek(ms)
                            }
                        }
                        .pointerInput(durationMs, zoom, selectedIndex, selected?.startMs, selected?.endMs) {
                            detectDragGestures(
                                onDrag = { change, _ ->
                                    change.consume()
                                    val s = selected ?: return@detectDragGestures
                                    val width = size.width.toFloat().coerceAtLeast(1f)
                                    val ms = (change.position.x / width * durationMs).toLong().coerceIn(0L, durationMs)
                                    val startX = s.startMs.toFloat() / durationMs * width
                                    val endX = s.endMs.toFloat() / durationMs * width
                                    when {
                                        kotlin.math.abs(change.position.x - startX) < 32f -> onStart(ms.coerceAtMost(s.endMs - 200L))
                                        kotlin.math.abs(change.position.x - endX) < 32f -> onEnd(ms.coerceAtLeast(s.startMs + 200L))
                                    }
                                }
                            )
                        }
                ) {
                    val width = size.width.coerceAtLeast(1f)
                    val baseY = size.height * .63f
                    val bars = waveform.ifEmpty { List(180) { 0.08f + 0.08f * kotlin.math.abs(kotlin.math.sin(it * .63f)) } }
                    bars.forEachIndexed { i, amplitude ->
                        val x = i.toFloat() / bars.size * width
                        val h = 6f + 46f * amplitude.coerceIn(0f, 1f)
                        drawRoundRect(Color(0xFF4AA3FF).copy(alpha = .60f), androidx.compose.ui.geometry.Offset(x, baseY-h), androidx.compose.ui.geometry.Size((width / bars.size).coerceAtLeast(2f), h*2), 2f)
                    }
                    words.forEach { word ->
                        val x = word.startMs.toFloat() / durationMs.coerceAtLeast(1L) * width
                        drawLine(Color(0xFF66E0C2).copy(alpha = .65f), androidx.compose.ui.geometry.Offset(x, baseY-50f), androidx.compose.ui.geometry.Offset(x, baseY+50f), strokeWidth = 1.5f)
                    }
                    subtitles.forEachIndexed { index, s ->
                        val x1 = s.startMs.toFloat() / durationMs.coerceAtLeast(1L) * width
                        val x2 = s.endMs.toFloat() / durationMs.coerceAtLeast(1L) * width
                        val top = 18f + (index % 2) * 38f
                        val selectedColor = if (index == selectedIndex) Color(0xFF8E4DFF) else Color(0xFF315A83)
                        drawRoundRect(selectedColor, androidx.compose.ui.geometry.Offset(x1, top), androidx.compose.ui.geometry.Size((x2-x1).coerceAtLeast(8f), 24f), 6f)
                        if (index == selectedIndex) {
                            drawLine(Color.White, androidx.compose.ui.geometry.Offset(x1, top-5), androidx.compose.ui.geometry.Offset(x1, top+29), strokeWidth = 5f)
                            drawLine(Color.White, androidx.compose.ui.geometry.Offset(x2, top-5), androidx.compose.ui.geometry.Offset(x2, top+29), strokeWidth = 5f)
                        }
                    }
                    val playX = positionMs.toFloat() / durationMs.coerceAtLeast(1L) * width
                    drawLine(Color(0xFFFFB347), androidx.compose.ui.geometry.Offset(playX, 0f), androidx.compose.ui.geometry.Offset(playX, size.height), strokeWidth = 3f)
                }
            }
        }
    }
}

@Composable private fun SubtitleEditCard(subtitle:Subtitle,selected:Boolean,onSelect:()->Unit,onText:(String)->Unit,onStart:(Long)->Unit,onEnd:(Long)->Unit,onDelete:()->Unit){Card(colors=CardDefaults.cardColors(containerColor=if(selected)MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface)){Column(Modifier.fillMaxWidth().padding(12.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("#${subtitle.index}",fontWeight=FontWeight.Bold);TextButton(onClick=onSelect){Text(if(selected)"محدد"else"تحديد")};TextButton(onClick=onDelete){Text("حذف")}};OutlinedTextField(value=subtitle.text,onValueChange=onText,label={Text("النص")},modifier=Modifier.fillMaxWidth());Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(value=subtitle.startMs.toString(),onValueChange={it.toLongOrNull()?.let(onStart)},label={Text("البداية ms")},modifier=Modifier.weight(1f));OutlinedTextField(value=subtitle.endMs.toString(),onValueChange={it.toLongOrNull()?.let(onEnd)},label={Text("النهاية ms")},modifier=Modifier.weight(1f))}}}}

@Composable private fun OcrEditCard(item:OcrOverlay,selected:Boolean,onSelect:()->Unit,onText:(String)->Unit,onEnabled:(Boolean)->Unit,onFontSize:(Int)->Unit,onOutline:(Int)->Unit,onShadow:(Int)->Unit,onBold:(Boolean)->Unit,onReplace:(Boolean)->Unit,onTracking:(Boolean)->Unit,onAddKeyframe:()->Unit){Card(colors=CardDefaults.cardColors(containerColor=if(selected)MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface)){Column(Modifier.fillMaxWidth().padding(10.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Row(verticalAlignment=Alignment.CenterVertically){Switch(checked=item.enabled,onCheckedChange=onEnabled);TextButton(onClick=onSelect){Text(if(selected)"محدد"else"تحديد")};Text("${item.safeX}% × ${item.safeY}%")};OutlinedTextField(value=item.text,onValueChange=onText,label={Text("نص OCR")},modifier=Modifier.fillMaxWidth());Text("حجم الخط: ${item.fontSizeSp}",fontSize=12.sp);Slider(value=item.fontSizeSp.toFloat(),onValueChange={onFontSize(it.roundToInt())},valueRange=20f..80f);Text("الحدود: ${item.outlineWidth}",fontSize=12.sp);Slider(value=item.outlineWidth.toFloat(),onValueChange={onOutline(it.roundToInt())},valueRange=0f..8f,steps=7);Text("الظل: ${item.shadowDepth}",fontSize=12.sp);Slider(value=item.shadowDepth.toFloat(),onValueChange={onShadow(it.roundToInt())},valueRange=0f..6f,steps=5);Row(verticalAlignment=Alignment.CenterVertically){Text("عريض");Switch(checked=item.bold,onCheckedChange=onBold)};Row(verticalAlignment=Alignment.CenterVertically){Text("استبدال النص الأصلي");Switch(checked=item.replaceOriginal,onCheckedChange=onReplace)};Row(verticalAlignment=Alignment.CenterVertically){Text("تتبع حركة النص");Switch(checked=item.motionTrackingEnabled,onCheckedChange=onTracking);if(item.motionTrackingEnabled)OutlinedButton(onClick=onAddKeyframe){Text("إضافة نقطة")}};if(item.motionTrackingEnabled)Text("نقاط التتبع: ${item.keyframes.size} • حرّك النص في المعاينة ثم أضف نقطة عند كل تغيير واضح",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant);Text("${formatMs(item.startMs)}–${formatMs(item.endMs)}",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
private fun formatMs(ms:Long):String{val total=(ms.coerceAtLeast(0)/1000);return "%02d:%02d".format(total/60,total%60)}
