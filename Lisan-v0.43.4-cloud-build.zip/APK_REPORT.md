# APK Report

Status: BLOCKED

No APK is claimed as generated or verified.

Reason: Gradle/Android build execution is unavailable in the current environment and the project does not contain a complete Gradle Wrapper.
