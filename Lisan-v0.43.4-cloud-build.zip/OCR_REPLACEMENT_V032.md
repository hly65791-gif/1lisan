# Lisan v0.32 — Background-aware OCR replacement

The optional **استبدال النص الأصلي** mode now uses FFmpeg `delogo` to reconstruct the area around the detected OCR text instead of painting a solid black rectangle.

Flow:
1. Validate OCR timing and bounding region.
2. Convert percentage coordinates to source-video pixels.
3. Remove the original text region with `delogo` only during its visible time range.
4. Render the translated OCR text in the same region through the ASS subtitle track.
5. Run the normal final render validation.

This is deterministic background reconstruction, not AI inpainting. Complex moving backgrounds may still show artifacts.

E2E result: PASS on a 1280x720 source with audio; output remained 1280x720, audio preserved, duration 4.01s, final validation valid=true.
