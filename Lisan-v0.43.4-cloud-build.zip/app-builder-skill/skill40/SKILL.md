---
name: app-builder
version: 3.3
description: Professional AI App Builder engineering skill for Android and full-stack applications, with Gradle Build Manager, project inspection, implementation, testing, validation, release gates, and recovery workflows.
---

# App Builder Skill v3.3

## Mission

Build, modify, repair, test, validate, and release production-quality applications through a disciplined engineering workflow.

Primary workflow:

INSPECT → UNDERSTAND → PLAN → SNAPSHOT → IMPLEMENT → BUILD → TEST → VALIDATE → RELEASE GATE

Never claim a feature, build, test, APK, or release is complete unless the corresponding evidence exists.

---

# 1. Core Rules

1. Inspect an existing project before changing it.
2. Preserve working code unless a change is required.
3. Never replace a real implementation with a mock and call it complete.
4. Never put API keys, private credentials, signing secrets, or service-account files inside the APK/source repository.
5. Keep architecture and documentation synchronized with implementation.
6. Every meaningful change must have a validation step.
7. A successful Gradle command alone does not prove the app is production-ready.
8. Never claim APK generation unless the APK artifact actually exists and was verified.
9. Distinguish:
   - IMPLEMENTED
   - PARTIAL
   - MOCK
   - MISSING
   - BROKEN
   - UNKNOWN
10. If the environment cannot build the project, report the blocker instead of inventing a result.

---

# 2. Project Doctor

When asked to inspect, audit, diagnose, or continue an existing project:

## Inspect
Check:
- repository structure
- Gradle files
- Gradle Wrapper
- JDK
- Android SDK
- AGP
- Kotlin
- Compose
- dependencies
- modules
- manifests
- navigation
- architecture
- database
- workers
- networking
- authentication
- permissions
- tests
- resources
- build variants
- signing configuration
- CI/CD if present

## Report

Create/update:

- `PROJECT_STATE.md`
- `TODO.md`
- `CHANGELOG.md`
- `ARCHITECTURE.md`
- `BUILD_REPORT.md`
- `APK_REPORT.md`
- `HEALTH_REPORT.md`

Never hide blockers.

---

# 3. Gradle Manager v1

Gradle is a first-class subsystem of this skill.

## 3.1 Environment Discovery

Before building, detect:

```text
OS
JDK version
JAVA_HOME
Gradle version
Gradle Wrapper version
Android SDK
ANDROID_HOME / ANDROID_SDK_ROOT
Build Tools
Platform SDK
NDK if required
ADB if available
```

Prefer the project's Gradle Wrapper over a system Gradle installation.

Priority:

1. `./gradlew`
2. `gradlew.bat` on Windows
3. project-configured Gradle tooling
4. system `gradle` only when wrapper is unavailable

Never silently substitute incompatible versions.

---

## 3.2 Wrapper Verification

Check for:

```text
gradlew
gradlew.bat
gradle/wrapper/gradle-wrapper.jar
gradle/wrapper/gradle-wrapper.properties
```

If the wrapper is incomplete, report:

```text
GRADLE_WRAPPER_MISSING
```

or:

```text
GRADLE_WRAPPER_INCOMPLETE
```

Do not claim a successful project build.

If a compatible Gradle installation is available, the skill may generate a wrapper using the project's intended Gradle version.

Do not arbitrarily upgrade Gradle just to make a build pass.

---

## 3.3 Version Compatibility Matrix

Inspect and reconcile:

```text
Gradle
Android Gradle Plugin
Kotlin
JDK
compileSdk
targetSdk
minSdk
Compose compiler/plugin
AndroidX versions
```

Before changing versions:

1. identify the current versions
2. identify the failing compatibility constraint
3. select the smallest safe change
4. document the change
5. rebuild
6. run tests

Never perform random version upgrades.

---

## 3.4 Gradle Toolchain Provisioning

The skill includes a deterministic Gradle provisioning layer for Android projects.

Default compatibility target for Lisan/modern Android projects:

- Gradle: **8.10.2**
- Android Gradle Plugin: **8.7.x**
- Kotlin: **2.0.x**

Do not force these versions on unrelated projects. First inspect the project and select the smallest compatible version.

The provisioning layer must:

1. Detect an existing `gradlew` / `gradlew.bat`.
2. Detect `gradle/wrapper/gradle-wrapper.jar` and `gradle-wrapper.properties`.
3. Detect a system Gradle executable with `gradle --version`.
4. If missing, run the bundled bootstrap script to obtain the official Gradle Wrapper JAR and Gradle distribution.
5. Verify downloaded binaries with SHA-256 before use.
6. Never fabricate a JAR, executable, checksum, or successful build result.
7. Prefer the project Wrapper after provisioning.
8. Record the exact Gradle version, Java version, AGP version, and validation result in the build report.

Bootstrap scripts:

```text
tools/gradle/bootstrap-gradle.sh
tools/gradle/bootstrap-gradle.ps1
tools/gradle/README.md
```

The scripts download only from the official Gradle distribution host and verify the Wrapper JAR checksum published by Gradle. The full Gradle binary distribution is also checksum-verified using the official `.sha256` file.

### Required status values

```text
GRADLE_SYSTEM_FOUND
GRADLE_WRAPPER_FOUND
GRADLE_WRAPPER_MISSING
GRADLE_WRAPPER_INCOMPLETE
GRADLE_BOOTSTRAPPED
GRADLE_BOOTSTRAP_BLOCKED
GRADLE_VERSION_INCOMPATIBLE
GRADLE_CHECKSUM_FAILED
```

A bootstrap failure must remain `BLOCKED`; it must not be converted into `PASS`.

# 4. Gradle Build Commands

Use the wrapper.

Linux/macOS:

```bash
./gradlew tasks
./gradlew clean
./gradlew test
./gradlew lint
./gradlew assembleDebug
./gradlew assembleRelease
./gradlew bundleRelease
```

Windows:

```bat
gradlew.bat tasks
gradlew.bat clean
gradlew.bat test
gradlew.bat lint
gradlew.bat assembleDebug
gradlew.bat assembleRelease
gradlew.bat bundleRelease
```

For Android projects, determine the actual module names before invoking tasks.

Examples:

```bash
./gradlew :app:assembleDebug
./gradlew :app:assembleRelease
./gradlew :app:testDebugUnitTest
./gradlew :app:lint
```

Never assume the module is named `app`.

---

# 5. Gradle Build Doctor

Before a release build run:

```text
1. Wrapper check
2. JDK check
3. Android SDK check
4. AGP/Gradle compatibility check
5. Kotlin compatibility check
6. Dependency resolution check
7. Repository check
8. Build variant check
9. Signing configuration check
10. Disk/storage sanity check when possible
```

Return a structured result:

```text
BUILD DOCTOR
Environment: PASS/FAIL
Wrapper: PASS/FAIL
JDK: PASS/FAIL
Android SDK: PASS/FAIL
Gradle/AGP: PASS/FAIL
Kotlin: PASS/FAIL
Dependencies: PASS/FAIL
Signing: PASS/FAIL
Build readiness: READY/BLOCKED
```

---

# 6. Gradle Error Recovery

When Gradle fails:

## Step 1 — Capture
Record:
- command
- task
- first meaningful error
- root exception
- affected module
- affected dependency/plugin

## Step 2 — Classify

Possible classes:

```text
WRAPPER
JDK
AGP
KOTLIN
DEPENDENCY
REPOSITORY
MANIFEST
RESOURCE
COMPILE
TEST
LINT
PACKAGING
SIGNING
D8/R8
NETWORK
CACHE
SDK
NDK
```

## Step 3 — Fix Root Cause

Do not blindly:
- delete all code
- downgrade everything
- upgrade everything
- disable tests
- disable lint
- disable R8
- add random dependencies

## Step 4 — Rebuild

Run the smallest useful validation first, then the complete relevant build.

## Step 5 — Regression Check

Verify that the fix did not break another module or variant.

---

# 7. Dependency Management

For every dependency:

- identify why it exists
- use a compatible version
- avoid duplicate libraries
- avoid unnecessary dependencies
- verify transitive conflicts
- keep versions centralized where practical

When a dependency fails:

```text
dependency → repository → version → compatibility → transitive conflict
```

Check all five before changing architecture.

---

# 8. Gradle Cache Recovery

Only when evidence points to a cache problem:

1. retry the failing task
2. use `--refresh-dependencies` when appropriate
3. inspect dependency resolution
4. clear only the relevant cache if possible
5. rebuild

Do not routinely delete the entire Gradle cache.

---

# 9. Build Verification

A build is:

### BUILD SUCCESS
only when:
- Gradle command exits successfully
- intended variant was built
- artifact exists
- artifact path is known

For Android APK:

Verify:
- file exists
- non-zero size
- expected application ID/package
- expected version name/code
- expected variant
- APK can be inspected
- signing state is appropriate

For AAB:

Verify:
- file exists
- expected application ID
- expected version
- bundle task succeeded

---

# 10. Release Gate

`Release Gate` is mandatory for release requests.

Minimum checks:

```text
[ ] Project Doctor
[ ] Gradle Wrapper
[ ] JDK
[ ] Android SDK
[ ] Dependencies
[ ] Compilation
[ ] Unit tests
[ ] Instrumentation tests when available
[ ] Lint
[ ] Manifest validation
[ ] Permissions review
[ ] Secret scan
[ ] Version validation
[ ] Signing validation
[ ] APK/AAB artifact validation
[ ] Critical user-flow validation
[ ] Regression check
[ ] Release report
```

If a critical check cannot run, status must be:

```text
BLOCKED
```

not PASS.

---

# 11. APK Validation

When asked for an APK:

1. run Build Doctor
2. build the requested variant
3. locate the generated APK
4. verify artifact metadata
5. inspect manifest
6. verify application ID
7. verify version
8. inspect permissions
9. verify signing state
10. install to a real/emulated device when available
11. launch
12. run smoke test
13. record result in `APK_REPORT.md`

Never say "APK ready" without an actual verified artifact.

---

# 12. Android Engineering Mode

Preferred Android stack when appropriate:

```text
Kotlin
Jetpack Compose
Hilt
Room
WorkManager
Media3
Coroutines
Flow
Clean Architecture
MVVM
```

Do not force these technologies if the existing project intentionally uses another compatible architecture.

---

# 13. Lisan Builder Mode

When the project is Lisan:

Treat the video-processing pipeline as a state machine:

```text
QUEUED
UPLOADING
PREPARING
EXTRACTING_AUDIO
TRANSCRIBING
TRANSLATING
OCR_PROCESSING
GENERATING_SUBTITLES
RENDERING
VALIDATING
COMPLETED
```

Failure/recovery states:

```text
FAILED
PAUSED
CANCELLED
```

Pipeline:

```text
Select Video
→ Validate
→ Upload
→ Extract Audio
→ STT
→ Transcript
→ Translation
→ OCR
→ Subtitle Generation
→ SRT/VTT
→ Subtitle Styling
→ FFmpeg Rendering
→ Quality Validation
→ Export
```

Never label a stub provider as a production provider.

---

# 14. Lisan Processing Rules

For large videos:

- stream/chunk where practical
- avoid loading the entire video into RAM
- persist job state
- support resume
- respect network availability
- report progress
- preserve intermediate artifacts when useful
- clean temporary files safely

Expected job metadata:

```text
jobId
projectId
stage
progress
createdAt
updatedAt
errorCode
errorMessage
retryCount
inputUri
outputUri
```

---

# 15. AI Provider Architecture

Use interfaces such as:

```kotlin
interface SpeechToTextProvider
interface TranslationProvider
interface OcrProvider
```

Providers must be replaceable.

Credentials belong on secure backend infrastructure or approved secure storage, never hardcoded into APK source.

---

# 16. Testing Strategy

At minimum, test:

### Unit
- domain logic
- subtitle generation
- SRT/VTT formatting
- validators
- state transitions

### Integration
- Room
- repositories
- WorkManager
- provider adapters

### Android/UI
- critical navigation
- video selection
- project creation
- processing state
- export flow

### Release
- debug build
- release build
- APK/AAB validation

---

# 17. Documentation Guardian

After meaningful changes update relevant documents.

At minimum:

```text
PROJECT_STATE.md
TODO.md
CHANGELOG.md
ARCHITECTURE.md
BUILD_REPORT.md
APK_REPORT.md
```

Do not leave documentation claiming features that are only mocked.

---

# 18. Beginner Mode

If the user is a beginner:

Explain:

1. what is wrong
2. why it matters
3. what will be changed
4. what command/tool is used
5. how to verify the result

Do not hide technical details, but present them progressively.

---

# 19. Command Intent Mapping

When the user says:

### "افحص المشروع"
Run Project Doctor.

### "افحص Lisan بالكامل"
Run Project Doctor + Lisan-specific pipeline audit.

### "أكمل Lisan"
Read project state and continue from the highest-priority incomplete step.

### "أضف ميزة X"
Inspect → impact analysis → plan → implement → test → validate → update docs.

### "أصلح الخطأ"
Reproduce → diagnose → fix root cause → test → regression check → document.

### "ابنِ المشروع"
Run Build Doctor → Gradle build → verify artifact → report.

### "جهز APK"
Run full Release Gate.

### "أضف Gradle"
Inspect existing Gradle setup first; never overwrite a valid wrapper blindly.

### "حدث التطبيق"
Update version → changelog → build → tests → validation → release report.

---

# 20. Output Format

For important operations use:

```text
STATUS: PASS | PARTIAL | BLOCKED | FAIL

CHANGED:
- ...

VERIFIED:
- ...

BLOCKERS:
- ...

NEXT:
- ...
```

For builds:

```text
BUILD:
Variant: ...
Task: ...
Result: PASS/FAIL
Artifact: ...
Tests: ...
Lint: ...
Release Gate: PASS/BLOCKED
```

---

# 21. Absolute Prohibitions

Never:

- claim tests passed without running them
- claim APK exists without verifying the file
- claim Gradle build succeeded without a successful Gradle execution
- hide missing Gradle Wrapper
- hardcode API secrets
- call mocks production-ready
- delete working project structure without reason
- randomly upgrade dependency versions
- disable safety checks merely to make a build pass
- suppress errors instead of fixing root causes
- fabricate logs, APK paths, test results, or deployment results

## v3.5 Autonomous Build System

When the user asks to build an app, the skill must operate as an engineering system, not only a code generator.

### Build orchestration

Run this sequence whenever tools permit:

`INSPECT → SNAPSHOT → TOOLCHAIN DOCTOR → PLAN → IMPLEMENT → FORMAT → UNIT TEST → BUILD → LINT → PACKAGE → ARTIFACT VERIFY → RELEASE GATE`

If a step is blocked, record the exact blocker and continue only with steps that do not create false confidence.

### Toolchain Doctor

For Android projects check:
- JDK version and JAVA_HOME
- Android SDK location and required platforms/build-tools
- Gradle Wrapper scripts and JAR
- Gradle distribution URL and checksum policy
- AGP/Kotlin/KSP/Gradle compatibility
- connected ADB devices when runtime tests are requested
- disk space and writable build/cache directories

For backend projects check:
- Python version
- virtual environment/container availability
- dependency lock/requirements
- Docker availability
- required system binaries such as ffmpeg/tesseract
- environment variables without exposing secret values

### Dependency Doctor

Before adding or upgrading a dependency:
1. identify the reason;
2. check compatibility with the existing toolchain;
3. avoid duplicate libraries;
4. record the change in CHANGELOG/project state;
5. run the smallest relevant build/test validation.

### Code Quality Gate

Check for:
- unresolved imports/references
- dead code introduced by the change
- unsafe TODO placeholders in production paths
- hard-coded secrets
- cleartext network use in production
- unbounded memory reads for large files
- missing timeouts/retries for network calls
- missing cancellation handling for workers
- database schema changes without migrations
- user-visible strings bypassing localization

### Test strategy

Prefer tests in this order:
1. pure domain/unit tests;
2. repository/data tests;
3. API/backend tests;
4. Compose/UI tests;
5. integration tests;
6. device smoke tests.

Do not report a test as passed unless it actually ran.

### Artifact verification

For APK/AAB verify:
- file exists
- non-zero size
- expected package/application id
- version name/code
- debug/release type as requested
- signing state as requested
- zip/archive integrity
- no obvious embedded secrets

For video output verify:
- file exists and is non-zero
- ffprobe can read it
- duration is positive
- expected video/audio streams exist
- output codec/container is expected
- subtitle burn-in/render command completed

### Release Gate

A release is READY only if all mandatory checks for the requested target pass. Otherwise use one of:
`READY`, `PARTIAL`, `BLOCKED`, `FAIL`.

Never convert `BLOCKED` into `READY` by assumption.

### Large-file policy

For video/audio/document applications:
- prefer streaming file IO;
- avoid `readBytes()`/whole-file RAM loading;
- use resumable/chunked upload for large remote transfers;
- persist job checkpoints;
- support cancellation and retry;
- clean temporary files after success/failure;
- make processing idempotent where practical.

### Production backend policy

Long-running media processing must use a job-oriented API. Keep request/response endpoints short and make processing status queryable. Render/export should be a distinct stage with explicit validation.

### Automatic documentation

After substantial changes update:
- PROJECT_STATE.md
- TODO.md
- CHANGELOG.md
- BUILD_REPORT.md when build/toolchain status changes
- API.md when an API contract changes

### Lisan build profile

For Lisan, preserve the selected architecture and enforce this production pipeline:
`select → validate → upload → extract audio → STT → transcript → translation → OCR → subtitle generation → render → validate → export`.

Do not mark a project COMPLETED before the rendered video exists and passes validation.


## v3.6 Production Media Delivery System
The builder now treats large video delivery as a first-class production concern:

`INSPECT → SNAPSHOT → TOOLCHAIN DOCTOR → PLAN → IMPLEMENT → FORMAT → UNIT TEST → BUILD → LINT → PACKAGE → ARTIFACT VERIFY → RELEASE GATE`

For video-processing apps, the implementation must additionally verify:
- resumable/chunked upload with server-side offset validation;
- persistent object/artifact storage instead of temporary render-only files;
- artifact IDs and metadata;
- streamed artifact download to device storage;
- local file-size validation before marking a job `COMPLETED`;
- Room/database migration when output artifact state is persisted;
- no success state while an output binary is still only remote.

A render response is not considered complete until the binary artifact is persisted, downloadable, downloaded to the client, and locally validated.


## v3.7 Reference-Driven Media Rendering Gate
When a user provides a visual reference for subtitles or video rendering, translate the reference into explicit, testable media requirements before implementation. For the Lisan reference style the default target is:
- bold white Arabic text;
- strong black outline;
- subtle black shadow;
- bottom-center alignment;
- no opaque subtitle box;
- preserve the source video geometry and existing black bars;
- use a Unicode Arabic-capable font and libass shaping/RTL layout.

A media render is not considered visually verified merely because FFmpeg exits successfully. The builder must run a smoke render, inspect or otherwise validate the resulting subtitle track/style, and record the result.


## v3.8 Subtitle Studio + Media Delivery Integrity
For media apps, the builder now verifies the user-selected subtitle preset is persisted from project creation through render.
- Lisan Classic remains the default reference-matched preset.
- Render APIs must accept an explicit style preset and return it in artifact metadata.
- Room migrations must preserve the selected style for existing projects.
- Transcript artifacts must be valid JSON, not line-oriented pseudo-JSON.
- Temporary resumable uploads are deleted only after the rendered artifact has been downloaded and locally validated.
- Failed downloads retain the upload checkpoint so a WorkManager retry can resume safely.
- Smoke tests should include an actual Arabic FFmpeg/libass render and ffprobe validation.


## v3.11 — Professional Subtitle Timeline Gate

When a subtitle editor exists, the workflow MUST support precise timeline editing before render:

`PREVIEW → TIMELINE SELECT → SEEK → ADJUST START/END → SHIFT SEGMENT → UNDO/REDO → SAFE-AREA POSITION → SAVE → RENDER`

Required controls:
- Timeline view showing every subtitle segment with proportional duration.
- Global video seek and selected-segment seek.
- Precise start/end controls with a minimum 200 ms segment duration.
- Segment shifting without changing duration.
- Undo/redo based on immutable subtitle-list snapshots.
- Safe-area guides and draggable subtitle placement using normalized 8–92% coordinates.
- Persist custom horizontal/vertical subtitle position through an explicit Room migration.
- Render API MUST receive the approved normalized coordinates and map them to the ASS 1920×1080 canvas.
- Preset positions MUST reset coordinates to TOP/CENTER/BOTTOM safe defaults.
- Preview gestures MUST not block normal Media3 player controls except when the subtitle overlay itself is being dragged.
- Backend tests MUST cover custom coordinate clamping and ASS position tags.
- Do not claim Android compile/APK success without an actual Gradle build and artifact verification.
