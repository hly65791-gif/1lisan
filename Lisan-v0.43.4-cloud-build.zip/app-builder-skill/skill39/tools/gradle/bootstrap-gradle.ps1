param([string]$ProjectPath='.', [string]$GradleVersion='8.10.2')
$ErrorActionPreference='Stop'
$root=(Resolve-Path $ProjectPath).Path
$hostUrl='https://services.gradle.org/distributions'
$wrapperDir=Join-Path $root 'gradle/wrapper'
$toolsDir=Join-Path $root '.app-builder/gradle'
New-Item -ItemType Directory -Force $wrapperDir,$toolsDir | Out-Null
$tmp=Join-Path ([IO.Path]::GetTempPath()) ('gradle-bootstrap-'+[guid]::NewGuid())
New-Item -ItemType Directory -Force $tmp | Out-Null
try {
  $jar=Join-Path $tmp 'gradle-wrapper.jar'
  $jarSum=Join-Path $tmp 'gradle-wrapper.jar.sha256'
  $zip=Join-Path $tmp "gradle-$GradleVersion-bin.zip"
  $zipSum=Join-Path $tmp "gradle-$GradleVersion-bin.zip.sha256"
  Invoke-WebRequest "$hostUrl/gradle-$GradleVersion-wrapper.jar" -OutFile $jar
  Invoke-WebRequest "$hostUrl/gradle-$GradleVersion-wrapper.jar.sha256" -OutFile $jarSum
  $expected=(Get-Content $jarSum -Raw).Trim().Split()[0]
  $jarActual=(Get-FileHash $jar -Algorithm SHA256).Hash.ToLower()
  if($expected -ne $jarActual){throw 'GRADLE_CHECKSUM_FAILED: wrapper JAR'}
  Copy-Item $jar (Join-Path $wrapperDir 'gradle-wrapper.jar') -Force
  @"
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip
networkTimeout=10000
retries=2
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
"@ | Set-Content (Join-Path $wrapperDir 'gradle-wrapper.properties')
  Invoke-WebRequest "$hostUrl/gradle-$GradleVersion-bin.zip" -OutFile $zip
  Invoke-WebRequest "$hostUrl/gradle-$GradleVersion-bin.zip.sha256" -OutFile $zipSum
  $expected=(Get-Content $zipSum -Raw).Trim().Split()[0]
  $zipActual=(Get-FileHash $zip -Algorithm SHA256).Hash.ToLower()
  if($expected -ne $zipActual){throw 'GRADLE_CHECKSUM_FAILED: Gradle distribution'}
  Expand-Archive $zip -DestinationPath $toolsDir -Force
  Write-Output "GRADLE_BOOTSTRAPPED"
  Write-Output "Gradle: $GradleVersion"
  Write-Output "Wrapper JAR SHA-256: $jarActual"
  Write-Output "Distribution SHA-256: $zipActual"
} finally { Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue }
