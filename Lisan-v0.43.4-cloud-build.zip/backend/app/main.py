import os
import subprocess
from pathlib import Path
from tempfile import NamedTemporaryFile, TemporaryDirectory
import shutil
import json
import uuid
import threading
import time
import base64
import hashlib
import hmac
from contextlib import contextmanager, asynccontextmanager
from concurrent.futures import ThreadPoolExecutor
from fastapi import FastAPI, File, Form, HTTPException, UploadFile, Header, Request
from fastapi.responses import FileResponse
from fastapi.responses import StreamingResponse
import httpx
import pytesseract
from pydantic import BaseModel
try:
    from . import storage
except ImportError:
    import importlib.util as _storage_importlib
    _storage_spec = _storage_importlib.spec_from_file_location("lisan_storage", Path(__file__).with_name("storage.py"))
    storage = _storage_importlib.module_from_spec(_storage_spec)
    _storage_spec.loader.exec_module(storage)
try:
    from . import cleanup as retention_cleanup
except ImportError:
    import importlib.util as _cleanup_importlib
    _cleanup_spec = _cleanup_importlib.spec_from_file_location("lisan_cleanup", Path(__file__).with_name("cleanup.py"))
    retention_cleanup = _cleanup_importlib.module_from_spec(_cleanup_spec)
    _cleanup_spec.loader.exec_module(retention_cleanup)

AUTH_REQUIRED = os.getenv("LISAN_AUTH_REQUIRED", "true").strip().lower() not in ("0", "false", "no", "off")
AUTH_SECRET = os.getenv("LISAN_AUTH_SECRET", "change-me-in-production").encode("utf-8")
AUTH_DB = DATA_ROOT / "users.json" if "DATA_ROOT" in globals() else Path(os.getenv("LISAN_DATA_DIR", "/tmp/lisan-data")) / "users.json"
AUTH_LOCK = threading.RLock() if "threading" in globals() else None

def _b64e(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).decode().rstrip("=")

def _b64d(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))

def _password_hash(password: str, salt: bytes | None = None) -> str:
    salt = salt or os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 210_000)
    return f"pbkdf2$210000${_b64e(salt)}${_b64e(digest)}"

def _password_ok(password: str, encoded: str) -> bool:
    try:
        _, rounds, salt, expected = encoded.split("$", 3)
        digest = hashlib.pbkdf2_hmac("sha256", password.encode(), _b64d(salt), int(rounds))
        return hmac.compare_digest(_b64e(digest), expected)
    except Exception:
        return False

def _load_users() -> dict:
    AUTH_DB.parent.mkdir(parents=True, exist_ok=True)
    if not AUTH_DB.exists(): return {}
    try: return json.loads(AUTH_DB.read_text(encoding="utf-8"))
    except Exception: return {}

def _save_users(users: dict) -> None:
    tmp = AUTH_DB.with_suffix(".tmp")
    tmp.write_text(json.dumps(users, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(AUTH_DB)

def _make_token(user_id: str, email: str, expires: int = 86400) -> str:
    header = _b64e(json.dumps({"alg":"HS256","typ":"JWT"}, separators=(",",":")).encode())
    payload = _b64e(json.dumps({"sub":user_id,"email":email,"exp":int(time.time())+expires}, separators=(",",":")).encode())
    signing = f"{header}.{payload}".encode()
    sig = _b64e(hmac.new(AUTH_SECRET, signing, hashlib.sha256).digest())
    return f"{header}.{payload}.{sig}"

def _decode_token(token: str) -> dict:
    try:
        header, payload, sig = token.split(".", 2)
        expected = _b64e(hmac.new(AUTH_SECRET, f"{header}.{payload}".encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(sig, expected): raise ValueError("BAD_SIGNATURE")
        data = json.loads(_b64d(payload))
        if int(data.get("exp", 0)) < int(time.time()): raise ValueError("TOKEN_EXPIRED")
        return data
    except Exception as exc:
        raise HTTPException(401, f"INVALID_TOKEN:{exc}")

def _auth_user(request: Request) -> dict | None:
    if not AUTH_REQUIRED: return {"sub":"dev","email":"dev@local"}
    value = request.headers.get("Authorization", "")
    if not value.startswith("Bearer "): raise HTTPException(401, "AUTH_REQUIRED")
    return _decode_token(value[7:].strip())

@asynccontextmanager
async def _lifespan(_app):
    if JOB_QUEUE_BACKEND == "redis":
        _start_redis_workers()
    yield


app = FastAPI(title="Lisan Backend", version="0.43.1", lifespan=_lifespan)

# Job execution supports a local fallback and an optional Redis Streams backend.
JOB_WORKERS = max(1, int(os.getenv("LISAN_JOB_WORKERS", "2")))
JOB_QUEUE_BACKEND = os.getenv("LISAN_QUEUE_BACKEND", "inprocess").strip().lower()
JOB_EXECUTOR = ThreadPoolExecutor(max_workers=JOB_WORKERS, thread_name_prefix="lisan-render")
JOB_LOCK = threading.Lock()
RENDER_JOBS: dict[str, dict] = {}
PIPELINE_JOBS: dict[str, dict] = {}
REDIS_STREAM = os.getenv("LISAN_REDIS_STREAM", "lisan:jobs")
REDIS_GROUP = os.getenv("LISAN_REDIS_GROUP", "lisan-workers")
REDIS_URL = os.getenv("LISAN_REDIS_URL", "redis://localhost:6379/0")
_REDIS = None
_REDIS_THREADS_STARTED = False

if JOB_QUEUE_BACKEND == "redis":
    try:
        import redis as _redis_module
        _REDIS = _redis_module.Redis.from_url(REDIS_URL, decode_responses=True)
    except Exception:
        _REDIS = None

# Large-file safety: keep payloads on disk and bound expensive OCR/STT work.
MAX_INPUT_BYTES = int(os.getenv("LISAN_MAX_INPUT_BYTES", str(8 * 1024 * 1024 * 1024)))
OCR_FPS = float(os.getenv("LISAN_OCR_FPS", "0.5"))
OCR_MAX_FRAMES = int(os.getenv("LISAN_OCR_MAX_FRAMES", "6000"))
OCR_AUTO_TRACK = os.getenv("LISAN_OCR_AUTO_TRACK", "true").strip().lower() not in ("0", "false", "no", "off")
OCR_TRACK_INTERVAL_MS = max(100, int(os.getenv("LISAN_OCR_TRACK_INTERVAL_MS", "500")))
OCR_TRACK_MAX_POINTS = max(2, int(os.getenv("LISAN_OCR_TRACK_MAX_POINTS", "24")))
OCR_TRACK_REDETECT_INTERVAL = max(1, int(os.getenv("LISAN_OCR_TRACK_REDETECT_INTERVAL", "2")))
OCR_TRACK_MIN_CONFIDENCE = float(os.getenv("LISAN_OCR_TRACK_MIN_CONFIDENCE", "0.35"))
TRANSLATION_BATCH_SIZE = int(os.getenv("LISAN_TRANSLATION_BATCH_SIZE", "32"))
COPY_CHUNK_BYTES = 1024 * 1024
# Account quotas (configurable; defaults are intentionally conservative for the free tier).
QUOTA_MONTHLY_MINUTES = max(0, int(os.getenv("LISAN_QUOTA_MONTHLY_MINUTES", "0")))  # 0 = unlimited
QUOTA_STORAGE_BYTES = max(1, int(os.getenv("LISAN_QUOTA_STORAGE_BYTES", str(5 * 1024 * 1024 * 1024))))
QUOTA_MAX_VIDEO_SECONDS = max(60, int(os.getenv("LISAN_QUOTA_MAX_VIDEO_SECONDS", str(4 * 60 * 60))))
QUOTA_MAX_CONCURRENT_JOBS = max(1, int(os.getenv("LISAN_QUOTA_MAX_CONCURRENT_JOBS", "1")))

def _month_key() -> str:
    return time.strftime("%Y-%m", time.gmtime())

def _usage_record(user: dict) -> dict:
    month = _month_key()
    usage = user.setdefault("usage", {})
    if usage.get("month") != month:
        usage.update({"month": month, "translation_seconds": 0, "reserved_seconds": 0})
    usage.setdefault("translation_seconds", 0)
    usage.setdefault("reserved_seconds", 0)
    usage.setdefault("storage_reserved_bytes", 0)
    return usage

def _user_by_id(user_id: str) -> tuple[str, dict] | None:
    users = _load_users()
    for email, user in users.items():
        if user.get("user_id") == user_id:
            return email, user
    return None

def _reserve_translation(user_id: str, seconds: float) -> None:
    with AUTH_LOCK:
        found = _user_by_id(user_id)
        if not found: raise HTTPException(401, "USER_NOT_FOUND")
        email, user = found; usage = _usage_record(user); users = _load_users()
        active =sum(1 for j in PIPELINE_JOBS.values() if j.get("owner_id") == user_id and j.get("status") in {"queued", "running"})
        if active >= QUOTA_MAX_CONCURRENT_JOBS: raise HTTPException(429, "CONCURRENT_JOB_LIMIT_REACHED")
        if seconds > QUOTA_MAX_VIDEO_SECONDS: raise HTTPException(413, "VIDEO_DURATION_LIMIT_EXCEEDED")
        if QUOTA_MONTHLY_MINUTES > 0:
            remaining = QUOTA_MONTHLY_MINUTES * 60 - int(usage["translation_seconds"]) - int(usage["reserved_seconds"])
            if seconds > remaining: raise HTTPException(402, "MONTHLY_TRANSLATION_QUOTA_EXCEEDED")
        usage["reserved_seconds"] = int(usage["reserved_seconds"]) + int(seconds)
        user["usage"] = usage; users[email] = user; _save_users(users)

def _finalize_translation(user_id: str, seconds: float, success: bool) -> None:
    with AUTH_LOCK:
        found = _user_by_id(user_id)
        if not found: return
        email, user = found; usage = _usage_record(user)
        usage["reserved_seconds"] = max(0, int(usage.get("reserved_seconds", 0)) - int(seconds))
        if success: usage["translation_seconds"] = int(usage.get("translation_seconds", 0)) + int(seconds)
        user["usage"] = usage; users = _load_users(); users[email] = user; _save_users(users)

def _account_usage(user_id: str) -> dict:
    found = _user_by_id(user_id)
    if not found: raise HTTPException(401, "USER_NOT_FOUND")
    _, user = found; usage = _usage_record(user); _save_users(_load_users() | {found[0]: user})
    storage_bytes = 0
    for meta in UPLOAD_ROOT.glob("*/meta.json"):
        try:
            data=json.loads(meta.read_text(encoding="utf-8"))
            if data.get("owner_id") == user_id:
                storage_bytes += int(data.get("size_bytes", 0))
        except Exception: pass
    for d in ARTIFACT_ROOT.iterdir() if ARTIFACT_ROOT.exists() else []:
        if d.is_dir():
            try:
                meta=json.loads((d/"meta.json").read_text(encoding="utf-8")) if (d/"meta.json").exists() else {}
                if meta.get("owner_id") == user_id:
                    storage_bytes += sum(f.stat().st_size for f in d.rglob("*") if f.is_file())
            except Exception: pass
    return {"plan":"free","month":usage["month"],"translation_minutes_used":round(usage["translation_seconds"]/60,2),"translation_minutes_reserved":round(usage["reserved_seconds"]/60,2),"translation_minutes_limit": QUOTA_MONTHLY_MINUTES,"translation_minutes_unlimited": QUOTA_MONTHLY_MINUTES == 0,"storage_bytes":storage_bytes,"storage_gb_used":round(storage_bytes/1024**3,3),"storage_bytes_limit":QUOTA_STORAGE_BYTES,"max_video_seconds":QUOTA_MAX_VIDEO_SECONDS,"max_concurrent_jobs":QUOTA_MAX_CONCURRENT_JOBS}


DATA_ROOT = Path(os.getenv("LISAN_DATA_DIR", "/tmp/lisan-data"))
AUTH_LOCK = threading.RLock()
UPLOAD_ROOT = DATA_ROOT / "uploads"
ARTIFACT_ROOT = DATA_ROOT / "artifacts"
UPLOAD_ROOT.mkdir(parents=True, exist_ok=True)
ARTIFACT_ROOT.mkdir(parents=True, exist_ok=True)

CLEANUP_INTERVAL_SECONDS = max(0, int(os.getenv("LISAN_CLEANUP_INTERVAL_SECONDS", "21600")))

def _cleanup_loop():
    while CLEANUP_INTERVAL_SECONDS > 0:
        time.sleep(CLEANUP_INTERVAL_SECONDS)
        try:
            retention_cleanup.cleanup(DATA_ROOT, UPLOAD_ROOT, ARTIFACT_ROOT, RENDER_JOBS, PIPELINE_JOBS, storage=storage, dry_run=False)
        except Exception:
            pass

if CLEANUP_INTERVAL_SECONDS > 0:
    threading.Thread(target=_cleanup_loop, name="lisan-retention", daemon=True).start()

class Segment(BaseModel):
    start_ms: int
    end_ms: int
    text: str
    confidence: float | None = None

class TranslateRequest(BaseModel):
    source: str
    target: str
    segments: list[Segment]

class UploadInitRequest(BaseModel):
    filename: str
    size_bytes: int
    content_type: str = "video/mp4"

def _owner_for_upload(upload_id: str) -> str:
    meta_file = UPLOAD_ROOT / upload_id / "meta.json"
    if not meta_file.exists(): raise HTTPException(404, "UPLOAD_NOT_FOUND")
    return str(json.loads(meta_file.read_text(encoding="utf-8")).get("owner_id", ""))

def _require_owner(request: Request, owner_id: str) -> None:
    user = getattr(request.state, "user", None) or _auth_user(request)
    if owner_id != user.get("sub"): raise HTTPException(404, "RESOURCE_NOT_FOUND")


@app.post("/v1/auth/register")
def register(email: str = Form(...), password: str = Form(...)):
    email = email.strip().lower()
    if len(email) < 5 or "@" not in email or len(password) < 8:
        raise HTTPException(400, "INVALID_CREDENTIALS")
    users = _load_users()
    if email in users: raise HTTPException(409, "EMAIL_ALREADY_REGISTERED")
    user_id = uuid.uuid4().hex
    users[email] = {"user_id": user_id, "email": email, "password_hash": _password_hash(password), "created_at": int(time.time()), "usage": {"month": _month_key(), "translation_seconds": 0, "reserved_seconds": 0, "storage_reserved_bytes": 0}}
    _save_users(users)
    return {"user_id": user_id, "email": email, "access_token": _make_token(user_id, email)}

@app.post("/v1/auth/login")
def login(email: str = Form(...), password: str = Form(...)):
    email = email.strip().lower(); user = _load_users().get(email)
    if not user or not _password_ok(password, user.get("password_hash", "")):
        raise HTTPException(401, "INVALID_EMAIL_OR_PASSWORD")
    return {"user_id": user["user_id"], "email": email, "access_token": _make_token(user["user_id"], email)}

@app.get("/v1/auth/me")
def me(request: Request):
    user = _auth_user(request)
    return {"user_id": user["sub"], "email": user.get("email")}

@app.get("/v1/account/usage")
def account_usage(request: Request):
    return _account_usage(request.state.user["sub"])

@app.middleware("http")
async def authentication_middleware(request: Request, call_next):
    public = request.url.path in {"/health", "/docs", "/openapi.json", "/redoc"} or request.url.path.startswith("/v1/auth/")
    if AUTH_REQUIRED and not public:
        try:
            user = _auth_user(request)
            request.state.user = user
        except HTTPException as exc:
            from fastapi.responses import JSONResponse
            return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})
    else:
        request.state.user = {"sub":"dev","email":"dev@local"}
    return await call_next(request)

@app.get("/health")
def health():
    return {"status": "ok", "service": "lisan-backend", "version": "0.43.1", "auth_required": AUTH_REQUIRED, "job_workers": JOB_WORKERS, "queue_backend": JOB_QUEUE_BACKEND if _REDIS is not None else "inprocess", "storage_backend": storage.BACKEND, "storage_ready": storage.enabled(), "limits": {"max_input_bytes": MAX_INPUT_BYTES, "ocr_max_frames": OCR_MAX_FRAMES, "monthly_translation_minutes": QUOTA_MONTHLY_MINUTES,"monthly_translation_unlimited": QUOTA_MONTHLY_MINUTES == 0, "storage_bytes": QUOTA_STORAGE_BYTES, "max_video_seconds": QUOTA_MAX_VIDEO_SECONDS, "max_concurrent_jobs": QUOTA_MAX_CONCURRENT_JOBS}}

def _stream_to_file(upload: UploadFile, destination: Path, max_bytes: int = MAX_INPUT_BYTES) -> int:
    total = 0
    with destination.open("wb") as out:
        while True:
            chunk = upload.file.read(COPY_CHUNK_BYTES)
            if not chunk:
                break
            total += len(chunk)
            if total > max_bytes:
                raise HTTPException(413, "INPUT_FILE_TOO_LARGE")
            out.write(chunk)
    return total

def _probe_duration_seconds(path: Path) -> float:
    result = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(path)], capture_output=True, text=True, check=True)
    try:
        return float(result.stdout.strip())
    except ValueError:
        raise HTTPException(422, "INVALID_MEDIA_DURATION")

@app.post("/v1/transcribe")
async def transcribe(language: str = Form(...), audio: UploadFile = File(...)):
    provider = os.getenv("LISAN_STT_PROVIDER", "")
    if provider != "faster_whisper":
        raise HTTPException(501, "STT_PROVIDER_NOT_CONFIGURED")
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        raise HTTPException(501, "INSTALL_FASTER_WHISPER")
    suffix = Path(audio.filename or "audio.m4a").suffix or ".m4a"
    with NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        path = Path(tmp.name)
        _stream_to_file(audio, path)
    try:
        model_name = os.getenv("LISAN_WHISPER_MODEL", "small")
        model = WhisperModel(model_name, device=os.getenv("LISAN_WHISPER_DEVICE", "cpu"), compute_type=os.getenv("LISAN_WHISPER_COMPUTE", "int8"))
        segments, _ = model.transcribe(
            path,
            language=None if language in ("auto", "") else language,
            word_timestamps=True,
            vad_filter=True,
        )
        result = []
        for s in segments:
            words = []
            for w in (getattr(s, "words", None) or []):
                if not getattr(w, "word", "").strip():
                    continue
                words.append({
                    "start_ms": int((w.start or 0) * 1000),
                    "end_ms": int((w.end or w.start or 0) * 1000),
                    "text": w.word.strip(),
                    "confidence": getattr(w, "probability", None),
                })
            result.append({
                "start_ms": int(s.start * 1000),
                "end_ms": int(s.end * 1000),
                "text": s.text.strip(),
                "confidence": None,
                "words": words,
            })
        return {"segments": result}
    finally:
        try: os.unlink(path)
        except OSError: pass


class AlignRequest(BaseModel):
    source_segments: list[dict]
    translated_segments: list[dict]

@app.post("/v1/align")
async def align(request: AlignRequest):
    url = os.getenv("LISAN_ALIGNMENT_URL", "").strip()
    if not url:
        raise HTTPException(501, "ALIGNMENT_PROVIDER_NOT_CONFIGURED")
    payload = {"source_segments": request.source_segments, "translated_segments": request.translated_segments}
    async with httpx.AsyncClient(timeout=180) as client:
        response = await client.post(url, json=payload)
    if response.status_code >= 400:
        raise HTTPException(502, f"ALIGNMENT_PROVIDER_HTTP_{response.status_code}")
    data = response.json()
    segments = data.get("segments")
    if not isinstance(segments, list) or len(segments) != len(request.translated_segments):
        raise HTTPException(502, "ALIGNMENT_PROVIDER_INVALID_RESPONSE")
    validated = []
    tolerance_ms = 250
    for index, segment in enumerate(segments):
        if not isinstance(segment, list):
            raise HTTPException(502, "ALIGNMENT_PROVIDER_INVALID_SEGMENT")
        translated = request.translated_segments[index]
        try:
            seg_start = int(translated["start_ms"]); seg_end = int(translated["end_ms"])
        except (KeyError, TypeError, ValueError):
            raise HTTPException(502, "ALIGNMENT_INPUT_INVALID_SEGMENT")
        if seg_end <= seg_start:
            raise HTTPException(502, "ALIGNMENT_INPUT_INVALID_TIMING")
        out = []
        previous_end = seg_start
        for word in segment:
            try:
                start = int(word["start_ms"]); end = int(word["end_ms"]); text = str(word["text"]).strip()
            except (KeyError, TypeError, ValueError):
                raise HTTPException(502, "ALIGNMENT_PROVIDER_INVALID_WORD")
            if not text or start < 0 or end <= start:
                raise HTTPException(502, "ALIGNMENT_PROVIDER_INVALID_TIMING")
            if start < previous_end:
                raise HTTPException(502, "ALIGNMENT_PROVIDER_WORDS_NOT_ORDERED")
            if start < seg_start - tolerance_ms or end > seg_end + tolerance_ms:
                raise HTTPException(502, "ALIGNMENT_PROVIDER_OUTSIDE_SEGMENT")
            item = {"start_ms": start, "end_ms": end, "text": text}
            if "source_word_index" in word:
                try: item["source_word_index"] = int(word["source_word_index"])
                except (TypeError, ValueError): raise HTTPException(502, "ALIGNMENT_PROVIDER_INVALID_SOURCE_INDEX")
            out.append(item)
            previous_end = end
        if not out:
            raise HTTPException(502, "ALIGNMENT_PROVIDER_EMPTY_SEGMENT")
        validated.append(out)
    return {"segments": validated}

@app.post("/v1/translate")
async def translate(request: TranslateRequest):
    url = os.getenv("LISAN_TRANSLATION_URL", "").strip()
    if not url:
        raise HTTPException(501, "TRANSLATION_PROVIDER_NOT_CONFIGURED")
    result = []
    async with httpx.AsyncClient(timeout=120) as client:
        for segment in request.segments:
            response = await client.post(url, json={"q": segment.text, "source": request.source, "target": request.target, "format": "text"})
            if response.status_code >= 400:
                raise HTTPException(502, f"TRANSLATION_PROVIDER_HTTP_{response.status_code}")
            data = response.json()
            text = data.get("translatedText") or data.get("translation")
            if not text:
                raise HTTPException(502, "TRANSLATION_PROVIDER_INVALID_RESPONSE")
            result.append({"start_ms": segment.start_ms, "end_ms": segment.end_ms, "text": text})
    return {"segments": result}

@app.post("/v1/ocr/auto-track")
async def ocr_auto_track(request: Request, video: UploadFile = File(...), overlay: str = Form(...)):
    """Automatically track one OCR region through a video using visual matching."""
    _auth_user(request)
    try:
        item = json.loads(overlay)
    except Exception:
        raise HTTPException(400, "INVALID_OCR_OVERLAY_JSON")
    validated = _validate_ocr_overlays([item])[0]
    with NamedTemporaryFile(delete=False, suffix=Path(video.filename or "video.mp4").suffix or ".mp4") as tmp:
        video_path = Path(tmp.name)
        _stream_to_file(video, video_path)
    try:
        tracked = _auto_track_ocr_overlay(video_path, validated)
        return tracked
    finally:
        video_path.unlink(missing_ok=True)

@app.post("/v1/ocr")
async def ocr(language_hint: str = Form(""), video: UploadFile = File(...)):
    with NamedTemporaryFile(delete=False, suffix=Path(video.filename or "video.mp4").suffix or ".mp4") as tmp:
        video_path = Path(tmp.name)
        _stream_to_file(video, video_path)
    try:
        with TemporaryDirectory() as frames:
            duration = _probe_duration_seconds(video_path)
            fps = OCR_FPS
            if duration > 0 and OCR_MAX_FRAMES > 0:
                fps = min(fps, OCR_MAX_FRAMES / duration)
            fps = max(fps, 0.001)
            pattern = str(Path(frames) / "frame_%06d.png")
            subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", str(video_path), "-vf", f"fps={fps:.6f}", "-frames:v", str(OCR_MAX_FRAMES), pattern], check=True)
            result = []
            for index, frame in enumerate(sorted(Path(frames).glob("frame_*.png"))):
                start_ms = index * 2000
                end_ms = start_ms + 2000
                data = pytesseract.image_to_data(str(frame), lang=language_hint or "eng", output_type=pytesseract.Output.DICT)
                from PIL import Image
                width, height = Image.open(frame).size
                tokens = []
                for i, raw in enumerate(data.get("text", [])):
                    text = str(raw).strip()
                    try:
                        confidence = float(data.get("conf", ["-1"])[i])
                    except (ValueError, TypeError, IndexError):
                        confidence = -1
                    if not text or confidence < 20:
                        continue
                    left = int(data.get("left", [0])[i])
                    top = int(data.get("top", [0])[i])
                    box_w = max(1, int(data.get("width", [1])[i]))
                    box_h = max(1, int(data.get("height", [1])[i]))
                    tokens.append((text, round((left + box_w / 2) / max(1, width) * 100), round((top + box_h / 2) / max(1, height) * 100)))
                if tokens:
                    merged_text = " ".join(item[0] for item in tokens).strip()
                    result.append({"start_ms": start_ms, "end_ms": end_ms, "text": merged_text, "x": round(sum(item[1] for item in tokens) / len(tokens)), "y": round(sum(item[2] for item in tokens) / len(tokens))})
            return {"segments": result, "sampling": {"fps": fps, "max_frames": OCR_MAX_FRAMES, "frames_processed": len(list(Path(frames).glob("frame_*.png")))}}
    except FileNotFoundError as exc:
        raise HTTPException(501, f"OCR_TOOL_MISSING: {exc}")
    except subprocess.CalledProcessError as exc:
        raise HTTPException(502, f"OCR_FRAME_EXTRACTION_FAILED: {exc}")
    finally:
        try: os.unlink(video_path)
        except OSError: pass

@app.post("/v1/uploads/init")
def init_upload(request: UploadInitRequest, http_request: Request):
    if request.size_bytes <= 0:
        raise HTTPException(400, "INVALID_UPLOAD_SIZE")
    if request.size_bytes > MAX_INPUT_BYTES:
        raise HTTPException(413, "UPLOAD_SIZE_LIMIT_EXCEEDED")
    usage = _account_usage(http_request.state.user["sub"])
    if usage["storage_bytes"] + request.size_bytes > QUOTA_STORAGE_BYTES:
        raise HTTPException(413, "STORAGE_QUOTA_EXCEEDED")
    upload_id = uuid.uuid4().hex
    directory = UPLOAD_ROOT / upload_id
    directory.mkdir(parents=True, exist_ok=False)
    (directory / "meta.json").write_text(json.dumps({**request.model_dump(), "owner_id": http_request.state.user["sub"]}), encoding="utf-8")
    (directory / "data.part").touch()
    return {"upload_id": upload_id, "offset": 0, "size_bytes": request.size_bytes, "chunk_size": int(os.getenv("LISAN_UPLOAD_CHUNK_SIZE", str(8 * 1024 * 1024)))}

@app.get("/v1/uploads/{upload_id}")
def upload_status(upload_id: str, request: Request):
    directory = UPLOAD_ROOT / upload_id
    meta_file = directory / "meta.json"
    data_file = directory / "data.part"
    if not meta_file.exists() or not data_file.exists():
        raise HTTPException(404, "UPLOAD_NOT_FOUND")
    meta = json.loads(meta_file.read_text(encoding="utf-8"))
    _require_owner(request, str(meta.get("owner_id", "")))
    return {"upload_id": upload_id, "offset": data_file.stat().st_size, "size_bytes": meta["size_bytes"], "completed": (directory / "complete.json").exists()}

@app.put("/v1/uploads/{upload_id}")
async def upload_chunk(upload_id: str, request: Request, x_chunk_offset: int = Header(...), x_total_size: int = Header(...), chunk: UploadFile = File(...)):
    directory = UPLOAD_ROOT / upload_id
    meta_file = directory / "meta.json"
    data_file = directory / "data.part"
    if not meta_file.exists() or not data_file.exists():
        raise HTTPException(404, "UPLOAD_NOT_FOUND")
    meta = json.loads(meta_file.read_text(encoding="utf-8"))
    _require_owner(request, str(meta.get("owner_id", "")))
    expected = int(meta["size_bytes"])
    if expected <= 0 or expected > MAX_INPUT_BYTES:
        raise HTTPException(413, "UPLOAD_SIZE_LIMIT_EXCEEDED")
    if x_total_size != expected or x_chunk_offset < 0:
        raise HTTPException(409, "UPLOAD_SIZE_MISMATCH")
    current = data_file.stat().st_size
    if x_chunk_offset != current:
        raise HTTPException(409, f"UPLOAD_OFFSET_MISMATCH:{current}")
    with data_file.open("ab") as out:
        shutil.copyfileobj(chunk.file, out, length=1024 * 1024)
    new_offset = data_file.stat().st_size
    if new_offset > expected:
        data_file.truncate(current)
        raise HTTPException(413, "UPLOAD_TOO_LARGE")
    return {"upload_id": upload_id, "offset": new_offset, "size_bytes": expected, "complete": new_offset == expected}

@app.post("/v1/uploads/{upload_id}/complete")
def complete_upload(upload_id: str, request: Request):
    directory = UPLOAD_ROOT / upload_id
    meta_file = directory / "meta.json"
    data_file = directory / "data.part"
    if not meta_file.exists() or not data_file.exists():
        raise HTTPException(404, "UPLOAD_NOT_FOUND")
    meta = json.loads(meta_file.read_text(encoding="utf-8"))
    _require_owner(request, str(meta.get("owner_id", "")))
    if data_file.stat().st_size != int(meta["size_bytes"]):
        raise HTTPException(409, "UPLOAD_INCOMPLETE")
    storage_info = {"backend": "local", "key": f"uploads/{upload_id}/data.part"}
    if storage.BACKEND != "local":
        if not storage.enabled():
            raise HTTPException(503, "OBJECT_STORAGE_NOT_CONFIGURED")
        try:
            storage_info = storage.put_file(data_file, storage.key("uploads", upload_id, "source" + (Path(meta.get("filename", "video.mp4")).suffix or ".mp4")))
        except Exception as exc:
            raise HTTPException(502, f"OBJECT_STORAGE_UPLOAD_FAILED:{exc}")
    (directory / "complete.json").write_text(json.dumps({"completed": True, "storage": storage_info}), encoding="utf-8")
    return {"upload_id": upload_id, "status": "completed", "size_bytes": data_file.stat().st_size, "storage": storage_info}

@app.delete("/v1/uploads/{upload_id}")
def delete_upload(upload_id: str, request: Request):
    directory = UPLOAD_ROOT / upload_id
    _require_owner(request, _owner_for_upload(upload_id))
    if not directory.exists():
        raise HTTPException(404, "UPLOAD_NOT_FOUND")
    shutil.rmtree(directory, ignore_errors=True)
    return {"upload_id": upload_id, "status": "deleted"}

def _upload_file(upload_id: str) -> Path:
    directory = UPLOAD_ROOT / upload_id
    data_file = directory / "data.part"
    complete = directory / "complete.json"
    if not complete.exists():
        raise HTTPException(409, "UPLOAD_NOT_COMPLETED")
    if data_file.exists() and data_file.stat().st_size > 0:
        return data_file
    try:
        state = json.loads(complete.read_text(encoding="utf-8"))
        info = state.get("storage", {})
        object_key = info.get("key")
        if object_key and storage.BACKEND != "local":
            storage.download_file(object_key, data_file)
            return data_file
    except Exception as exc:
        raise HTTPException(502, f"OBJECT_STORAGE_DOWNLOAD_FAILED:{exc}")
    raise HTTPException(409, "UPLOAD_SOURCE_UNAVAILABLE")

def _persist_artifact_object(artifact_dir: Path, output: Path) -> dict | None:
    """Persist the final binary to configured object storage."""
    if storage.BACKEND == "local":
        return None
    if not storage.enabled():
        raise RuntimeError("OBJECT_STORAGE_NOT_CONFIGURED")
    return storage.put_file(output, storage.key("artifacts", artifact_dir.name, output.name))


def _ass_escape(text: str) -> str:
    """Escape text for an ASS dialogue line without changing visible punctuation."""
    return (
        text.replace("\\", r"\\")
        .replace("{", r"\\{")
        .replace("}", r"\\}")
        .replace("\n", r"\N")
        .replace("\r", "")
    )


def _ass_timestamp(ms: int) -> str:
    safe = max(0, int(ms))
    hours, rem = divmod(safe, 3_600_000)
    minutes, rem = divmod(rem, 60_000)
    seconds, millis = divmod(rem, 1_000)
    # ASS uses centiseconds.
    return f"{hours}:{minutes:02d}:{seconds:02d}.{millis // 10:02d}"


def _ocr_motion_points(item: dict) -> list[dict]:
    start = int(item.get("start_ms", 0)); end = int(item.get("end_ms", start + 200))
    points = []
    for raw in item.get("keyframes", []) or []:
        if not isinstance(raw, dict):
            continue
        try:
            t = int(raw.get("time_ms", start))
            x = float(raw.get("x_percent", item.get("x_percent", 50)))
            y = float(raw.get("y_percent", item.get("y_percent", 50)))
            w = float(raw.get("width_percent", item.get("width_percent", 20)))
            h = float(raw.get("height_percent", item.get("height_percent", 10)))
        except (TypeError, ValueError):
            continue
        if start <= t <= end:
            points.append({"time_ms": t, "x": max(2.0, min(98.0, x)), "y": max(2.0, min(98.0, y)), "w": max(2.0, min(80.0, w)), "h": max(2.0, min(50.0, h))})
    points.append({"time_ms": start, "x": float(item.get("x_percent", 50)), "y": float(item.get("y_percent", 50)), "w": float(item.get("width_percent", 20)), "h": float(item.get("height_percent", 10))})
    points.append({"time_ms": end, "x": float(item.get("x_percent", 50)), "y": float(item.get("y_percent", 50)), "w": float(item.get("width_percent", 20)), "h": float(item.get("height_percent", 10))})
    dedup = {}
    for point in points:
        dedup[point["time_ms"]] = point
    return [dedup[t] for t in sorted(dedup)]


def _ocr_motion_segments(item: dict) -> list[tuple[int, int, dict]]:
    points = _ocr_motion_points(item)
    if not bool(item.get("motion_tracking_enabled", False)) or len(points) < 2:
        return [(int(item.get("start_ms", 0)), int(item.get("end_ms", 200)), points[0])]
    segments = []
    for a, b in zip(points, points[1:]):
        if b["time_ms"] <= a["time_ms"]:
            continue
        segments.append((a["time_ms"], b["time_ms"], a))
    return segments


def _build_ocr_ass(ocr_overlays: list[dict]) -> str:
    lines = []
    for item in ocr_overlays:
        if item.get("enabled", True) is False:
            continue
        text = str(item.get("text", "")).strip()
        if not text:
            continue
        font_size = max(20, min(int(item.get("font_size_sp", 42)), 80))
        outline = max(0, min(int(item.get("outline_width", 3)), 8))
        shadow = max(0, min(int(item.get("shadow_depth", 1)), 6))
        bold = 1 if item.get("bold", True) else 0
        for start_ms, end_ms, point in _ocr_motion_segments(item):
            px = round(1920 * point["x"] / 100)
            py = round(1080 * point["y"] / 100)
            override = f"{{\\pos({px},{py})\\fs{font_size}\\bord{outline}\\shad{shadow}\\b{bold}}}"
            lines.append(f"Dialogue: 1,{_ass_timestamp(start_ms)},{_ass_timestamp(end_ms)},LisanOCR,,0,0,0,,{override}{_ass_escape(text)}\n")
    return "".join(lines)


def _build_lisan_classic_ass(segments: list[dict], style_name: str = "LISAN_CLASSIC", font_size: int = 54, position: str = "BOTTOM", shape: str = "OUTLINE", outline_width: int = 4, shadow_depth: int = 1, horizontal_percent: int = 50, vertical_percent: int = 88, ocr_overlays: list[dict] | None = None) -> str:
    """Create a configurable Lisan subtitle track for libass."""
    font_size = max(24, min(int(font_size), 110))
    outline_width = max(0, min(int(outline_width), 12))
    shadow_depth = max(0, min(int(shadow_depth), 8))
    position_name = str(position).upper()
    if position_name == "TOP": horizontal_percent, vertical_percent = 50, 14
    elif position_name == "CENTER": horizontal_percent, vertical_percent = 50, 50
    elif position_name == "BOTTOM": horizontal_percent, vertical_percent = 50, 88
    horizontal_percent = max(8, min(int(horizontal_percent), 92))
    vertical_percent = max(8, min(int(vertical_percent), 92))
    pos_x = round(1920 * horizontal_percent / 100)
    pos_y = round(1080 * vertical_percent / 100)
    alignment = 5
    shape = str(shape).upper()
    if shape == "BOX":
        border_style, outline, shadow, back = 3, 0, 0, "&H90000000"
    elif shape == "ROUNDED_BOX":
        # ASS/libass does not have a native rounded rectangle. Use a soft semi-opaque box.
        border_style, outline, shadow, back = 3, 0, 0, "&HA0000000"
    elif shape == "SHADOW":
        border_style, outline, shadow, back = 1, 2, max(1, shadow_depth), "&H80000000"
    else:
        border_style, outline, shadow, back = 1, outline_width, shadow_depth, "&H80000000"
    preset_size = {"LISAN_CLASSIC": font_size, "CLEAN": max(24, font_size - 4), "LARGE": min(110, font_size + 8)}.get(style_name, font_size)
    header = f"""[Script Info]\nScriptType: v4.00+\nPlayResX: 1920\nPlayResY: 1080\nWrapStyle: 2\nScaledBorderAndShadow: yes\nYCbCr Matrix: TV.709\n\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\nStyle: LisanClassic,Noto Sans Arabic,{preset_size},&H00FFFFFF,&H00FFFFFF,&H00000000,&H{back[2:] if back.startswith('&H') else '80000000'},1,0,0,0,100,100,0,0,{border_style},{outline},{shadow},{alignment},70,70,55,1\nStyle: LisanOCR,Noto Sans Arabic,42,&H00FFFFFF,&H00FFFFFF,&H00000000,&H90000000,1,0,0,0,100,100,0,0,1,3,1,5,40,40,40,1\n\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"""
    lines = [header]
    for segment in segments:
        text = str(segment.get("text", "")).strip()
        if not text:
            continue
        start_ms = int(segment.get("start_ms", 0))
        end_ms = max(start_ms + 200, int(segment.get("end_ms", start_ms + 200)))
        lines.append(f"Dialogue: 0,{_ass_timestamp(start_ms)},{_ass_timestamp(end_ms)},LisanClassic,,0,0,0,,{{\\pos({pos_x},{pos_y})}}{_ass_escape(text)}\n")
    if ocr_overlays:
        lines.append(_build_ocr_ass(ocr_overlays))
    return "".join(lines)


def _build_karaoke_ass(segments: list[dict], style_name: str = "LISAN_CLASSIC", font_size: int = 54, position: str = "BOTTOM", shape: str = "OUTLINE", outline_width: int = 4, shadow_depth: int = 1, horizontal_percent: int = 50, vertical_percent: int = 88, ocr_overlays: list[dict] | None = None) -> str:
    """Build ASS with per-word karaoke timing from validated translated-word alignment."""
    # Reuse the normal style header by generating an empty track, then replace events.
    base = _build_lisan_classic_ass([], style_name, font_size, position, shape, outline_width, shadow_depth, horizontal_percent, vertical_percent, ocr_overlays=None)
    lines = [base.split("[Events]\n", 1)[0] + "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"]
    for segment in segments:
        words = segment if isinstance(segment, list) else []
        if not words:
            continue
        start_ms = min(int(w.get("start_ms", 0)) for w in words)
        end_ms = max(int(w.get("end_ms", start_ms + 200)) for w in words)
        if end_ms <= start_ms:
            continue
        pos_x = round(1920 * max(8, min(int(horizontal_percent), 92)) / 100)
        pos_y = round(1080 * max(8, min(int(vertical_percent), 92)) / 100)
        text_parts = []
        for w in words:
            text = str(w.get("text", "")).strip()
            if not text:
                continue
            duration_cs = max(1, round((int(w.get("end_ms", 0)) - int(w.get("start_ms", 0))) / 10))
            text_parts.append(f"{{\\k{duration_cs}}}{_ass_escape(text)}")
        if text_parts:
            lines.append(f"Dialogue: 0,{_ass_timestamp(start_ms)},{_ass_timestamp(end_ms)},LisanClassic,,0,0,0,,{{\\pos({pos_x},{pos_y})}}" + " ".join(text_parts) + "\n")
    if ocr_overlays:
        lines.append(_build_ocr_ass(ocr_overlays))
    return "".join(lines)


def _write_subtitle_track_as_ass(source_subtitles: Path, destination: Path, style_name: str = "LISAN_CLASSIC", font_size: int = 54, position: str = "BOTTOM", shape: str = "OUTLINE", outline_width: int = 4, shadow_depth: int = 1, horizontal_percent: int = 50, vertical_percent: int = 88, ocr_overlays: list[dict] | None = None, karaoke_alignment: list[dict] | None = None) -> None:
    """Convert the app's SRT to a styled ASS track for deterministic burn-in."""
    # The app-generated SRT is UTF-8. A tiny parser is used here so we do not need
    # another subtitle dependency in the backend image.
    raw = source_subtitles.read_text(encoding="utf-8-sig")
    blocks = []
    for block in raw.replace("\r\n", "\n").replace("\r", "\n").split("\n\n"):
        lines = [line.strip() for line in block.split("\n") if line.strip()]
        if len(lines) < 3 or "-->" not in lines[1]:
            continue
        timing = lines[1]
        left, right = [x.strip() for x in timing.split("-->", 1)]
        def parse_srt_time(value: str) -> int:
            hms, millis = value.replace(".", ",").split(",", 1)
            h, m, s = [int(x) for x in hms.split(":")]
            return ((h * 3600 + m * 60 + s) * 1000) + int(millis[:3].ljust(3, "0"))
        blocks.append({"start_ms": parse_srt_time(left), "end_ms": parse_srt_time(right), "text": "\n".join(lines[2:])})
    track = _build_karaoke_ass(karaoke_alignment, style_name, font_size, position, shape, outline_width, shadow_depth, horizontal_percent, vertical_percent, ocr_overlays) if karaoke_alignment else _build_lisan_classic_ass(blocks, style_name, font_size, position, shape, outline_width, shadow_depth, horizontal_percent, vertical_percent, ocr_overlays)
    destination.write_text(track, encoding="utf-8")


def _probe_media(path: Path) -> dict:
    probe = subprocess.run([
        "ffprobe", "-v", "error",
        "-show_entries", "format=duration,size:stream=index,codec_type,width,height",
        "-show_streams", "-of", "json", str(path)
    ], check=True, capture_output=True, text=True)
    return json.loads(probe.stdout or "{}")


def _media_summary(metadata: dict) -> dict:
    fmt = metadata.get("format", {}) or {}
    streams = metadata.get("streams", []) or []
    video = next((x for x in streams if x.get("codec_type") == "video"), None)
    return {
        "duration_seconds": float(fmt.get("duration") or 0),
        "size_bytes": int(fmt.get("size") or 0),
        "has_video": video is not None,
        "has_audio": any(x.get("codec_type") == "audio" for x in streams),
        "width": int((video or {}).get("width") or 0),
        "height": int((video or {}).get("height") or 0),
    }


def _validate_render_output(source_metadata: dict, output_metadata: dict, output: Path) -> dict:
    source = _media_summary(source_metadata)
    output_info = _media_summary(output_metadata)
    checks = {}
    checks["file_exists"] = output.exists()
    checks["file_non_empty"] = output.exists() and output.stat().st_size > 0
    checks["duration_positive"] = output_info["duration_seconds"] > 0
    checks["video_stream"] = output_info["has_video"]
    checks["dimensions_match"] = (
        source["width"] > 0 and source["height"] > 0 and
        output_info["width"] == source["width"] and output_info["height"] == source["height"]
    )
    checks["audio_preserved"] = (not source["has_audio"]) or output_info["has_audio"]
    source_duration = source["duration_seconds"]
    output_duration = output_info["duration_seconds"]
    tolerance = max(0.75, source_duration * 0.02) if source_duration > 0 else 0.75
    checks["duration_matches_source"] = source_duration > 0 and abs(output_duration - source_duration) <= tolerance
    checks["finite_metadata"] = all(
        isinstance(v, (int, float)) and v == v and abs(float(v)) != float("inf")
        for v in (output_duration, float(output_info["size_bytes"]), float(output_info["width"]), float(output_info["height"]))
    )
    valid = all(checks.values())
    return {
        "valid": valid,
        "checks": checks,
        "source": source,
        "output": output_info,
        "duration_tolerance_seconds": tolerance,
    }


def _validate_ocr_overlays(overlays: list[dict]) -> list[dict]:
    validated = []
    for item in overlays:
        if not isinstance(item, dict):
            raise HTTPException(400, "INVALID_OCR_OVERLAY")
        try:
            start = int(item.get("start_ms", 0)); end = int(item.get("end_ms", 0))
            text = str(item.get("text", "")).strip()
            x = float(item.get("x_percent", 50)); y = float(item.get("y_percent", 50))
        except (TypeError, ValueError):
            raise HTTPException(400, "INVALID_OCR_OVERLAY_FIELDS")
        if not text or start < 0 or end <= start or not (0 <= x <= 100) or not (0 <= y <= 100):
            raise HTTPException(400, "INVALID_OCR_OVERLAY_TIMING_OR_POSITION")
        normalized = dict(item)
        width = float(item.get("width_percent", 20)); height = float(item.get("height_percent", 10)); replace_original = bool(item.get("replace_original", False)); tracking = bool(item.get("motion_tracking_enabled", False))
        if not (2 <= width <= 80 and 2 <= height <= 50):
            raise HTTPException(400, "INVALID_OCR_REPLACEMENT_SIZE")
        raw_keyframes = item.get("keyframes", []) or []
        if not isinstance(raw_keyframes, list) or len(raw_keyframes) > 120:
            raise HTTPException(400, "INVALID_OCR_KEYFRAMES")
        keyframes = []
        for k in raw_keyframes:
            if not isinstance(k, dict):
                raise HTTPException(400, "INVALID_OCR_KEYFRAME")
            try:
                kt = int(k.get("time_ms", start)); kx = float(k.get("x_percent", x)); ky = float(k.get("y_percent", y)); kw = float(k.get("width_percent", width)); kh = float(k.get("height_percent", height))
            except (TypeError, ValueError):
                raise HTTPException(400, "INVALID_OCR_KEYFRAME")
            if not (start <= kt <= end and 0 <= kx <= 100 and 0 <= ky <= 100 and 2 <= kw <= 80 and 2 <= kh <= 50):
                raise HTTPException(400, "INVALID_OCR_KEYFRAME")
            keyframes.append({"time_ms": kt, "x_percent": kx, "y_percent": ky, "width_percent": kw, "height_percent": kh})
        normalized.update({"start_ms": start, "end_ms": end, "text": text, "x_percent": x, "y_percent": y, "width_percent": width, "height_percent": height, "replace_original": replace_original, "motion_tracking_enabled": tracking, "keyframes": sorted(keyframes, key=lambda z: z["time_ms"])})
        validated.append(normalized)
    return validated


def _build_ocr_replacement_filter(ocr_overlays: list[dict] | None, video_width: int = 1920, video_height: int = 1080) -> str:
    filters = []
    vw = max(1, int(video_width)); vh = max(1, int(video_height))
    for item in ocr_overlays or []:
        if item.get("enabled", True) is False or not item.get("replace_original", False):
            continue
        for start_ms, end_ms, point in _ocr_motion_segments(item):
            x = point["x"]; y = point["y"]; w = point["w"]; h = point["h"]
            xx = max(0, round(vw * max(0.0, (x-w/2)/100)))
            yy = max(0, round(vh * max(0.0, (y-h/2)/100)))
            ww = max(2, round(vw * w / 100)); hh = max(2, round(vh * h / 100))
            start = max(0.0, start_ms / 1000.0); end = max(start + 0.2, end_ms / 1000.0)
            filters.append(f"delogo=x={xx}:y={yy}:w={ww}:h={hh}:show=0:enable='between(t,{start:.3f},{end:.3f})'")
    return ",".join(filters)


def _render(source: Path, srt: Path, output: Path, style_name: str = "LISAN_CLASSIC", font_size: int = 54, position: str = "BOTTOM", shape: str = "OUTLINE", outline_width: int = 4, shadow_depth: int = 1, horizontal_percent: int = 50, vertical_percent: int = 88, ocr_overlays: list[dict] | None = None, karaoke_alignment: list[dict] | None = None) -> dict:
    if source.stat().st_size == 0 or srt.stat().st_size == 0:
        raise HTTPException(400, "EMPTY_RENDER_INPUT")
    ass = output.with_suffix(".ass")
    try:
        source_metadata = _probe_media(source)
        source_summary = _media_summary(source_metadata)
        _write_subtitle_track_as_ass(srt, ass, style_name, font_size, position, shape, outline_width, shadow_depth, horizontal_percent, vertical_percent, ocr_overlays, karaoke_alignment)
        if ass.stat().st_size == 0:
            raise HTTPException(400, "EMPTY_SUBTITLE_TRACK")
        # The subtitle filter preserves the original video geometry. Black bars that
        # are already part of the source therefore remain untouched, while captions
        # are rendered at the bottom-center in the Lisan Classic style.
        mask = _build_ocr_replacement_filter(ocr_overlays, source_summary["width"], source_summary["height"])
        vf = ((mask + ",") if mask else "") + f"subtitles={ass}:charenc=UTF-8"
        subprocess.run([
            "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
            "-i", str(source), "-vf", vf,
            "-c:v", "libx264", "-preset", os.getenv("LISAN_RENDER_PRESET", "veryfast"),
            "-crf", os.getenv("LISAN_RENDER_CRF", "20"),
            "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
            "-movflags", "+faststart", str(output)
        ], check=True)
        output_metadata = _probe_media(output)
        validation = _validate_render_output(source_metadata, output_metadata, output)
        if not validation["valid"]:
            raise HTTPException(502, json.dumps({"error": "RENDER_VALIDATION_FAILED", "validation": validation}, ensure_ascii=False))
        output_info = validation["output"]
        return {
            "duration_seconds": output_info["duration_seconds"],
            "size_bytes": output_info["size_bytes"],
            "has_video": output_info["has_video"],
            "has_audio": output_info["has_audio"],
            "width": output_info["width"],
            "height": output_info["height"],
            "validation": validation,
            "subtitle_style": style_name,
            "subtitle_font": "Noto Sans Arabic",
            "subtitle_position": position.lower(),
            "subtitle_font_size": font_size,
            "subtitle_shape": shape,
            "subtitle_outline_width": outline_width,
            "subtitle_shadow_depth": shadow_depth,
            "subtitle_horizontal_percent": horizontal_percent,
            "subtitle_vertical_percent": vertical_percent,
            "ocr_overlay_count": len(ocr_overlays or []),
            "ocr_replacement_count": sum(1 for item in (ocr_overlays or []) if item.get("replace_original", False)),
            "karaoke_enabled": bool(karaoke_alignment),
        }
    except FileNotFoundError as exc:
        raise HTTPException(501, f"FFMPEG_OR_FFPROBE_MISSING: {exc}")
    except subprocess.CalledProcessError as exc:
        raise HTTPException(502, f"FFMPEG_RENDER_FAILED: {exc}")
    finally:
        try:
            ass.unlink()
        except OSError:
            pass



def _redis_queue_init() -> None:
    if _REDIS is None:
        return
    try:
        _REDIS.xgroup_create(REDIS_STREAM, REDIS_GROUP, id="0", mkstream=True)
    except Exception as exc:
        if "BUSYGROUP" not in str(exc):
            raise


def _enqueue_distributed(kind: str, payload: dict) -> bool:
    if _REDIS is None:
        return False
    _redis_queue_init()
    _REDIS.xadd(REDIS_STREAM, {"kind": kind, "payload": json.dumps(payload, ensure_ascii=False)})
    return True

def _dispatch_job(kind: str, payload: dict) -> None:
    if kind == "pipeline":
        _run_pipeline_job(**payload)
    elif kind == "render":
        _run_render_job(**payload)
    else:
        raise RuntimeError(f"UNKNOWN_JOB_KIND:{kind}")

def _redis_worker_loop(worker_index: int) -> None:
    consumer = f"{os.getenv('HOSTNAME','lisan')}-{worker_index}-{uuid.uuid4().hex[:8]}"
    try:
        _redis_queue_init()
        while True:
            messages = _REDIS.xreadgroup(REDIS_GROUP, consumer, {REDIS_STREAM: ">"}, count=1, block=5000)
            if not messages:
                continue
            for _, entries in messages:
                for message_id, fields in entries:
                    try:
                        payload = json.loads(fields["payload"])
                        _dispatch_job(fields["kind"], payload)
                        _REDIS.xack(REDIS_STREAM, REDIS_GROUP, message_id)
                    except Exception as exc:
                        # Job functions persist their own failed state. Ack prevents a hot retry loop.
                        try:
                            _REDIS.xack(REDIS_STREAM, REDIS_GROUP, message_id)
                        except Exception:
                            pass
    except Exception:
        # Do not crash API startup because Redis is unavailable.
        return

def _start_redis_workers() -> None:
    global _REDIS_THREADS_STARTED
    if _REDIS is None or _REDIS_THREADS_STARTED:
        return
    try:
        _redis_queue_init()
        _REDIS.ping()
    except Exception:
        return
    _REDIS_THREADS_STARTED = True
    for index in range(JOB_WORKERS):
        threading.Thread(target=_redis_worker_loop, args=(index,), daemon=True, name=f"lisan-redis-worker-{index}").start()

def _enqueue_job(kind: str, payload: dict, local_callable, *local_args) -> None:
    if JOB_QUEUE_BACKEND == "redis" and _REDIS is not None:
        _start_redis_workers()
        if _REDIS_THREADS_STARTED:
            _enqueue_distributed(kind, payload)
            return
    JOB_EXECUTOR.submit(local_callable, *local_args)


def _pipeline_state_path(job_id: str) -> Path:
    directory = ARTIFACT_ROOT / f"pipeline-{job_id}"
    directory.mkdir(parents=True, exist_ok=True)
    return directory / "job.json"


def _save_pipeline_job(job_id: str, **values) -> dict:
    with JOB_LOCK:
        current = PIPELINE_JOBS.setdefault(job_id, {"job_id": job_id})
        current.update(values)
        state = dict(current)
    _pipeline_state_path(job_id).write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    return state


def _load_pipeline_job(job_id: str) -> dict | None:
    with JOB_LOCK:
        if job_id in PIPELINE_JOBS:
            return dict(PIPELINE_JOBS[job_id])
    path = _pipeline_state_path(job_id)
    if not path.exists():
        return None
    try:
        state = json.loads(path.read_text(encoding="utf-8"))
        with JOB_LOCK:
            PIPELINE_JOBS[job_id] = state
        return dict(state)
    except Exception:
        return None


def _extract_audio(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(source),
        "-vn", "-c:a", "aac", "-b:a", "128k", str(destination)
    ], check=True)
    if not destination.exists() or destination.stat().st_size == 0:
        raise RuntimeError("AUDIO_EXTRACTION_EMPTY")


def _run_stt_file(audio_path: Path, language: str) -> list[dict]:
    provider = os.getenv("LISAN_STT_PROVIDER", "")
    if provider != "faster_whisper":
        raise RuntimeError("STT_PROVIDER_NOT_CONFIGURED")
    try:
        from faster_whisper import WhisperModel
    except ImportError as exc:
        raise RuntimeError("INSTALL_FASTER_WHISPER") from exc
    model = WhisperModel(
        os.getenv("LISAN_WHISPER_MODEL", "small"),
        device=os.getenv("LISAN_WHISPER_DEVICE", "cpu"),
        compute_type=os.getenv("LISAN_WHISPER_COMPUTE", "int8"),
    )
    segments, _ = model.transcribe(
        audio_path,
        language=None if language in ("auto", "") else language,
        word_timestamps=True,
        vad_filter=True,
    )
    result = []
    for s in segments:
        words = []
        for w in (getattr(s, "words", None) or []):
            text = getattr(w, "word", "").strip()
            if not text:
                continue
            words.append({"start_ms": int((w.start or 0) * 1000), "end_ms": int((w.end or w.start or 0) * 1000), "text": text, "confidence": getattr(w, "probability", None)})
        result.append({"start_ms": int(s.start * 1000), "end_ms": int(s.end * 1000), "text": s.text.strip(), "confidence": None, "words": words})
    return result


async def _translate_segments_internal(segments: list[dict], source: str, target: str) -> list[dict]:
    url = os.getenv("LISAN_TRANSLATION_URL", "").strip()
    if not url:
        raise RuntimeError("TRANSLATION_PROVIDER_NOT_CONFIGURED")
    result = []
    batch_size = max(1, TRANSLATION_BATCH_SIZE)
    async with httpx.AsyncClient(timeout=120) as client:
        for start in range(0, len(segments), batch_size):
            batch = segments[start:start + batch_size]
            for segment in batch:
                response = await client.post(url, json={"q": segment["text"], "source": source, "target": target, "format": "text"})
                if response.status_code >= 400:
                    raise RuntimeError(f"TRANSLATION_PROVIDER_HTTP_{response.status_code}")
                data = response.json()
                text = data.get("translatedText") or data.get("translation")
                if not text:
                    raise RuntimeError("TRANSLATION_PROVIDER_INVALID_RESPONSE")
                result.append({"start_ms": segment["start_ms"], "end_ms": segment["end_ms"], "text": text})
    return result


def _write_srt(segments: list[dict], destination: Path) -> None:
    def ts(ms: int) -> str:
        ms=max(0,int(ms)); h, rem=divmod(ms,3600000); m, rem=divmod(rem,60000); sec, milli=divmod(rem,1000)
        return f"{h:02d}:{m:02d}:{sec:02d},{milli:03d}"
    lines=[]
    for i, seg in enumerate(segments, 1):
        start=int(seg["start_ms"]); end=max(start+200,int(seg["end_ms"])); text=str(seg["text"]).strip()
        if not text: continue
        lines += [str(i), f"{ts(start)} --> {ts(end)}", text, ""]
    destination.write_text("\n".join(lines), encoding="utf-8")
    if destination.stat().st_size == 0:
        raise RuntimeError("EMPTY_SRT")


def _auto_track_ocr_overlay(source: Path, item: dict, interval_ms: int = OCR_TRACK_INTERVAL_MS, max_points: int = OCR_TRACK_MAX_POINTS) -> dict:
    """Track an OCR region with local matching plus automatic re-detection.

    The tracker first follows the previous template. When confidence drops, it
    expands the search and tries ORB feature matching against the initial crop.
    If both methods fail, the last reliable point is retained and no bogus jump
    is emitted. This is still visual tracking, not semantic OCR re-recognition.
    """
    try:
        import cv2
        import numpy as np
    except Exception:
        return item
    cap = cv2.VideoCapture(str(source))
    if not cap.isOpened(): return item
    try:
        fps=float(cap.get(cv2.CAP_PROP_FPS) or 0); width=int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0); height=int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
        if width<=0 or height<=0 or fps<=0: return item
        start_ms=int(item.get("start_ms",0)); end_ms=int(item.get("end_ms",start_ms+1000))
        x=float(item.get("x_percent",50)); y=float(item.get("y_percent",50)); wp=float(item.get("width_percent",20)); hp=float(item.get("height_percent",10))
        def box(cx,cy,w_pct,h_pct):
            bw=max(8,int(width*w_pct/100)); bh=max(8,int(height*h_pct/100)); bx=max(0,min(width-bw,int(width*cx/100-bw/2))); by=max(0,min(height-bh,int(height*cy/100-bh/2))); return bx,by,bw,bh
        cap.set(cv2.CAP_PROP_POS_MSEC,start_ms); ok,frame=cap.read()
        if not ok: return item
        bx,by,bw,bh=box(x,y,wp,hp); gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY); template=gray[by:by+bh,bx:bx+bw]
        if template.size==0: return item
        orb=cv2.ORB_create(nfeatures=300)
        kp0,des0=orb.detectAndCompute(template,None)
        matcher=cv2.BFMatcher(cv2.NORM_HAMMING,crossCheck=True)
        points=[{"time_ms":start_ms,"x_percent":round((bx+bw/2)/width*100,3),"y_percent":round((by+bh/2)/height*100,3),"width_percent":round(bw/width*100,3),"height_percent":round(bh/height*100,3),"confidence":1.0}]
        last_x,last_y=bx,by; last_score=1.0; step=0; used_redetect=False; t=start_ms+interval_ms
        while t<end_ms and len(points)<max_points:
            cap.set(cv2.CAP_PROP_POS_MSEC,t); ok,frame=cap.read()
            if not ok: break
            gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY); pad_x=max(bw*2,int(width*.08)); pad_y=max(bh*2,int(height*.08)); sx=max(0,last_x-pad_x); sy=max(0,last_y-pad_y); ex=min(width,last_x+bw+pad_x); ey=min(height,last_y+bh+pad_y); search=gray[sy:ey,sx:ex]
            found=None; method="template"
            if search.shape[0]>=template.shape[0] and search.shape[1]>=template.shape[1]:
                result=cv2.matchTemplate(search,template,cv2.TM_CCOEFF_NORMED); _,score,_,loc=cv2.minMaxLoc(result)
                if float(score)>=OCR_TRACK_MIN_CONFIDENCE: found=(sx+int(loc[0]),sy+int(loc[1]),float(score))
            step+=1
            if found is None and step % OCR_TRACK_REDETECT_INTERVAL == 0 and des0 is not None and len(kp0)>=4:
                # Re-detect in a wider frame. Homography is intentionally avoided:
                # OCR boxes need a stable axis-aligned region for FFmpeg rendering.
                kp,des=orb.detectAndCompute(gray,None)
                if des is not None and len(kp)>=4:
                    matches=matcher.match(des0,des); matches=sorted(matches,key=lambda m:m.distance)[:30]
                    good=[m for m in matches if m.distance<55]
                    if len(good)>=4:
                        xs=[kp[m.trainIdx].pt[0] for m in good]; ys=[kp[m.trainIdx].pt[1] for m in good]
                        cx=float(np.median(xs)); cy=float(np.median(ys)); nx=int(max(0,min(width-bw,cx-bw/2))); ny=int(max(0,min(height-bh,cy-bh/2)))
                        conf=min(0.99,max(0.36,len(good)/12)); found=(nx,ny,conf); method="orb_redetect"; used_redetect=True
            if found is not None:
                nx,ny,score=found; last_x,last_y=nx,ny; last_score=score
                points.append({"time_ms":t,"x_percent":round((nx+bw/2)/width*100,3),"y_percent":round((ny+bh/2)/height*100,3),"width_percent":round(bw/width*100,3),"height_percent":round(bh/height*100,3),"confidence":round(score,3),"method":method})
                # Update template only on reliable matches to adapt to scale/lighting.
                crop=gray[ny:ny+bh,nx:nx+bw]
                if crop.shape==template.shape and score>=0.60: template=crop.copy()
            else:
                # Explicitly preserve last reliable location; never manufacture a jump.
                last_score=max(0.0,last_score*.95)
            t+=interval_ms
        out=dict(item); out["motion_tracking_enabled"]=len(points)>=2; out["tracking_method"]="opencv_template_matching_with_orb_redetection" if used_redetect else "opencv_template_matching"; out["keyframes"]=points; out["tracking_confidence"] = round(sum(float(p.get("confidence",0)) for p in points)/len(points),3) if points else 0.0; return out
    finally: cap.release()


def _auto_track_ocr_overlays(source: Path, overlays: list[dict]) -> list[dict]:
    if not OCR_AUTO_TRACK:
        return overlays
    tracked = []
    for item in overlays:
        try:
            tracked.append(_auto_track_ocr_overlay(source, item))
        except Exception:
            tracked.append(item)
    return tracked

def _run_ocr_file(source: Path, language_hint: str) -> list[dict]:
    with TemporaryDirectory() as frames:
        duration = _probe_duration_seconds(source)
        fps = OCR_FPS
        if duration > 0 and OCR_MAX_FRAMES > 0:
            fps = min(fps, OCR_MAX_FRAMES / duration)
        fps=max(fps,0.001)
        pattern=str(Path(frames)/"frame_%06d.png")
        subprocess.run(["ffmpeg","-hide_banner","-loglevel","error","-i",str(source),"-vf",f"fps={fps:.6f}","-frames:v",str(OCR_MAX_FRAMES),pattern],check=True)
        result=[]
        from PIL import Image
        for index, frame in enumerate(sorted(Path(frames).glob("frame_*.png"))):
            start_ms=index*2000; end_ms=start_ms+2000
            data=pytesseract.image_to_data(str(frame), lang=language_hint or "eng", output_type=pytesseract.Output.DICT)
            width,height=Image.open(frame).size; tokens=[]
            for i, raw in enumerate(data.get("text",[])):
                text=str(raw).strip()
                try: confidence=float(data.get("conf",["-1"])[i])
                except (ValueError,TypeError,IndexError): confidence=-1
                if not text or confidence < 20: continue
                left=int(data.get("left",[0])[i]); top=int(data.get("top",[0])[i]); bw=max(1,int(data.get("width",[1])[i])); bh=max(1,int(data.get("height",[1])[i]))
                tokens.append((text,left,top,bw,bh))
            if tokens:
                min_left=min(x[1] for x in tokens); min_top=min(x[2] for x in tokens); max_right=max(x[1]+x[3] for x in tokens); max_bottom=max(x[2]+x[4] for x in tokens)
                result.append({"start_ms":start_ms,"end_ms":end_ms,"text":" ".join(x[0] for x in tokens).strip(),"x":round(((min_left+max_right)/2)/max(1,width)*100),"y":round(((min_top+max_bottom)/2)/max(1,height)*100),"width_percent":round((max_right-min_left)/max(1,width)*100),"height_percent":round((max_bottom-min_top)/max(1,height)*100)})
        return result


def _run_pipeline_job(job_id: str, upload_id: str, source_language: str, target_language: str, ocr_enabled: bool, alignment_enabled: bool, style: str, font_size: int, position: str, shape: str, outline_width: int, shadow_depth: int, horizontal_percent: int, vertical_percent: int, ocr_language: str) -> None:
    job_dir=ARTIFACT_ROOT/f"pipeline-{job_id}"; job_dir.mkdir(parents=True,exist_ok=True)
    try:
        source=_upload_file(upload_id)
        state=_load_pipeline_job(job_id) or {}
        completed=set(state.get("completed_stages", []))
        stages=["PREPARE","EXTRACT_AUDIO","STT","TRANSLATE"] + (["OCR"] if ocr_enabled else []) + (["ALIGN"] if alignment_enabled else []) + ["SRT","RENDER"]
        _save_pipeline_job(job_id,status="running",stage=stages[0],progress=1,completed_stages=list(completed),artifact_id=state.get("artifact_id"))
        if "EXTRACT_AUDIO" not in completed:
            _save_pipeline_job(job_id,stage="EXTRACT_AUDIO",progress=10)
            _extract_audio(source,job_dir/"audio.m4a"); completed.add("EXTRACT_AUDIO"); _save_pipeline_job(job_id,completed_stages=list(completed),progress=20)
        segments_path=job_dir/"transcript.json"
        if "STT" not in completed:
            _save_pipeline_job(job_id,stage="STT",progress=25)
            transcript=_run_stt_file(job_dir/"audio.m4a",source_language); segments_path.write_text(json.dumps(transcript,ensure_ascii=False,indent=2),encoding="utf-8"); completed.add("STT"); _save_pipeline_job(job_id,completed_stages=list(completed),progress=40)
        transcript=json.loads(segments_path.read_text(encoding="utf-8"))
        translated_path=job_dir/"translated.json"
        if "TRANSLATE" not in completed:
            _save_pipeline_job(job_id,stage="TRANSLATE",progress=45)
            translated=__import__('asyncio').run(_translate_segments_internal(transcript,source_language,target_language)); translated_path.write_text(json.dumps(translated,ensure_ascii=False,indent=2),encoding="utf-8"); completed.add("TRANSLATE"); _save_pipeline_job(job_id,completed_stages=list(completed),progress=55)
        translated=json.loads(translated_path.read_text(encoding="utf-8"))
        overlays=[]
        if ocr_enabled:
            ocr_path=job_dir/"ocr.json"
            if "OCR" not in completed:
                _save_pipeline_job(job_id,stage="OCR",progress=60); overlays=_run_ocr_file(source,ocr_language); overlays=_auto_track_ocr_overlays(source, overlays); ocr_path.write_text(json.dumps(overlays,ensure_ascii=False,indent=2),encoding="utf-8"); completed.add("OCR"); _save_pipeline_job(job_id,completed_stages=list(completed),progress=68)
            else: overlays=json.loads(ocr_path.read_text(encoding="utf-8"))
        alignment=None
        if alignment_enabled:
            if "ALIGN" not in completed:
                url=os.getenv("LISAN_ALIGNMENT_URL","").strip()
                if not url: raise RuntimeError("ALIGNMENT_PROVIDER_NOT_CONFIGURED")
                payload={"source_segments":transcript,"translated_segments":translated}
                async def call_align():
                    async with httpx.AsyncClient(timeout=180) as client:
                        r=await client.post(url,json=payload)
                        if r.status_code>=400: raise RuntimeError(f"ALIGNMENT_PROVIDER_HTTP_{r.status_code}")
                        return r.json().get("segments")
                alignment=__import__('asyncio').run(call_align())
                if not isinstance(alignment,list) or len(alignment)!=len(translated): raise RuntimeError("ALIGNMENT_PROVIDER_INVALID_RESPONSE")
                (job_dir/"alignment.json").write_text(json.dumps(alignment,ensure_ascii=False,indent=2),encoding="utf-8"); completed.add("ALIGN"); _save_pipeline_job(job_id,completed_stages=list(completed),progress=75)
            else: alignment=json.loads((job_dir/"alignment.json").read_text(encoding="utf-8"))
        srt=job_dir/"translated.srt"
        if "SRT" not in completed:
            _save_pipeline_job(job_id,stage="SRT",progress=80); _write_srt(translated,srt); completed.add("SRT"); _save_pipeline_job(job_id,completed_stages=list(completed),progress=85)
        else: srt=job_dir/"translated.srt"
        artifact_id=state.get("artifact_id") or uuid.uuid4().hex; artifact_dir=ARTIFACT_ROOT/artifact_id; artifact_dir.mkdir(parents=True,exist_ok=True); output=artifact_dir/"translated_video.mp4"
        if "RENDER" not in completed:
            _save_pipeline_job(job_id,stage="RENDER",progress=90)
            metadata=_render(source,srt,output,style,font_size,position,shape,outline_width,shadow_depth,horizontal_percent,vertical_percent,_validate_ocr_overlays(overlays),alignment)
            response={"status":"validated","artifact_id":artifact_id,"filename":output.name,"owner_id":state.get("owner_id"),**metadata}
            (artifact_dir/"metadata.json").write_text(json.dumps(response,ensure_ascii=False,indent=2),encoding="utf-8")
            (artifact_dir/"render_validation.json").write_text(json.dumps(metadata["validation"],ensure_ascii=False,indent=2),encoding="utf-8")
            if storage.BACKEND != "local":
                response["storage"] = _persist_artifact_object(artifact_dir, output)
                (artifact_dir/"metadata.json").write_text(json.dumps(response,ensure_ascii=False,indent=2),encoding="utf-8")
            completed.add("RENDER")
        else:
            response=json.loads((artifact_dir/"metadata.json").read_text(encoding="utf-8"))
        _save_pipeline_job(job_id,status="completed",stage="DONE",progress=100,completed_stages=list(completed),artifact_id=artifact_id,result=response)
        _finalize_translation(str(state.get("owner_id", "")), float(state.get("reserved_seconds", 0)), True)
    except Exception as exc:
        state=_load_pipeline_job(job_id) or {}
        _finalize_translation(str(state.get("owner_id", "")), float(state.get("reserved_seconds", 0)), False)
        _save_pipeline_job(job_id,status="failed",progress=100,error=str(exc))

def _set_job(job_id: str, **values) -> None:
    with JOB_LOCK:
        current = RENDER_JOBS.setdefault(job_id, {"job_id": job_id})
        current.update(values)


def _run_render_job(job_id: str, source: Path, srt: Path, output: Path, style: str, font_size: int,
                    position: str, shape: str, outline_width: int, shadow_depth: int,
                    horizontal_percent: int, vertical_percent: int, overlays: list[dict], alignment: list[dict] | None,
                    artifact_dir: Path) -> None:
    _set_job(job_id, status="running", progress=5)
    try:
        _set_job(job_id, progress=15)
        metadata = _render(source, srt, output, style, font_size, position, shape, outline_width,
                           shadow_depth, horizontal_percent, vertical_percent, overlays, alignment)
        response = {"status": "validated", "artifact_id": artifact_dir.name, "filename": output.name, "owner_id": RENDER_JOBS.get(job_id, {}).get("owner_id"), **metadata}
        (artifact_dir / "metadata.json").write_text(json.dumps(response, ensure_ascii=False, indent=2), encoding="utf-8")
        (artifact_dir / "render_validation.json").write_text(json.dumps(metadata["validation"], ensure_ascii=False, indent=2), encoding="utf-8")
        if storage.BACKEND != "local":
            try:
                response["storage"] = _persist_artifact_object(artifact_dir, output)
                (artifact_dir / "metadata.json").write_text(json.dumps(response, ensure_ascii=False, indent=2), encoding="utf-8")
            except Exception as exc:
                _set_job(job_id, status="failed", progress=100, error=f"OBJECT_STORAGE_UPLOAD_FAILED:{exc}", http_status=502)
                return
        _set_job(job_id, status="completed", progress=100, result=response)
    except HTTPException as exc:
        _set_job(job_id, status="failed", progress=100, error=str(exc.detail), http_status=exc.status_code)
    except Exception as exc:
        _set_job(job_id, status="failed", progress=100, error=str(exc), http_status=500)

@app.post("/v1/pipeline")
async def start_pipeline(request: Request, upload_id: str = Form(...), source_language: str = Form("auto"), target_language: str = Form(...), ocr_enabled: bool = Form(True), alignment_enabled: bool = Form(False), ocr_language: str = Form(""), style: str = Form("LISAN_CLASSIC"), font_size: int = Form(54), position: str = Form("BOTTOM"), shape: str = Form("OUTLINE"), outline_width: int = Form(4), shadow_depth: int = Form(1), horizontal_percent: int = Form(50), vertical_percent: int = Form(88)):
    _require_owner(request, _owner_for_upload(upload_id))
    source = _upload_file(upload_id)
    duration = _probe_duration_seconds(source)
    _reserve_translation(request.state.user["sub"], duration)
    job_id=uuid.uuid4().hex
    _save_pipeline_job(job_id,status="queued",stage="QUEUED",progress=0,completed_stages=[],upload_id=upload_id,source_language=source_language,target_language=target_language,ocr_enabled=ocr_enabled,alignment_enabled=alignment_enabled,ocr_language=ocr_language,style=style,font_size=font_size,position=position,shape=shape,outline_width=outline_width,shadow_depth=shadow_depth,horizontal_percent=horizontal_percent,vertical_percent=vertical_percent,owner_id=request.state.user["sub"],reserved_seconds=duration)
    pipeline_args=dict(job_id=job_id,upload_id=upload_id,source_language=source_language,target_language=target_language,ocr_enabled=ocr_enabled,alignment_enabled=alignment_enabled,style=style,font_size=font_size,position=position,shape=shape,outline_width=outline_width,shadow_depth=shadow_depth,horizontal_percent=horizontal_percent,vertical_percent=vertical_percent,ocr_language=ocr_language)
    _enqueue_job("pipeline", pipeline_args, _run_pipeline_job, **pipeline_args)
    return {"job_id":job_id,"status":"queued","progress":0,"completed_stages":[]}

@app.get("/v1/pipeline-jobs/{job_id}")
def pipeline_job_status(job_id: str, request: Request):
    job=_load_pipeline_job(job_id)
    if job is None: raise HTTPException(404,"PIPELINE_JOB_NOT_FOUND")
    _require_owner(request, str(job.get("owner_id", "")))
    return job

@app.post("/v1/pipeline-jobs/{job_id}/resume")
def resume_pipeline_job(job_id: str, request: Request):
    job=_load_pipeline_job(job_id)
    if job is None: raise HTTPException(404,"PIPELINE_JOB_NOT_FOUND")
    _require_owner(request, str(job.get("owner_id", "")))
    if job.get("status")=="completed": return job
    if job.get("status")=="running": return job
    upload_id=job.get("upload_id")
    if not upload_id: raise HTTPException(409,"PIPELINE_UPLOAD_ID_MISSING")
    _save_pipeline_job(job_id,status="queued",stage="RESUMING",progress=int(job.get("progress",0)),error=None)
    # Resume uses the persisted checkpoint and conservative defaults for render options;
    # clients should normally start with /v1/pipeline so all options are recorded.
    pipeline_args=dict(job_id=job_id,upload_id=upload_id,source_language=job.get("source_language","auto"),target_language=job.get("target_language",""),ocr_enabled=bool(job.get("ocr_enabled",True)),alignment_enabled=bool(job.get("alignment_enabled",False)),style=job.get("style","LISAN_CLASSIC"),font_size=int(job.get("font_size",54)),position=job.get("position","BOTTOM"),shape=job.get("shape","OUTLINE"),outline_width=int(job.get("outline_width",4)),shadow_depth=int(job.get("shadow_depth",1)),horizontal_percent=int(job.get("horizontal_percent",50)),vertical_percent=int(job.get("vertical_percent",88)),ocr_language=job.get("ocr_language",""))
    _enqueue_job("pipeline", pipeline_args, _run_pipeline_job, **pipeline_args)
    return _load_pipeline_job(job_id)

@app.post("/v1/render-upload")
async def render_upload(request: Request, upload_id: str = Form(...), subtitles: UploadFile = File(...), ocr_overlays: UploadFile | None = File(None), karaoke_alignment: UploadFile | None = File(None), style: str = Form("LISAN_CLASSIC"), font_size: int = Form(54), position: str = Form("BOTTOM"), shape: str = Form("OUTLINE"), outline_width: int = Form(4), shadow_depth: int = Form(1), horizontal_percent: int = Form(50), vertical_percent: int = Form(88)):
    _require_owner(request, _owner_for_upload(upload_id))
    source = _upload_file(upload_id)
    artifact_id = uuid.uuid4().hex
    artifact_dir = ARTIFACT_ROOT / artifact_id
    artifact_dir.mkdir(parents=True, exist_ok=False)
    srt = artifact_dir / "translated.srt"
    output = artifact_dir / "translated_video.mp4"
    _stream_to_file(subtitles, srt, max_bytes=64 * 1024 * 1024)
    overlays = []
    if ocr_overlays is not None:
        try:
            overlays = json.loads((await ocr_overlays.read()).decode("utf-8"))
            if not isinstance(overlays, list):
                raise ValueError("OCR_OVERLAYS_NOT_ARRAY")
            overlays = _validate_ocr_overlays(overlays)
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(400, f"INVALID_OCR_OVERLAYS: {exc}")
    alignment = None
    if karaoke_alignment is not None:
        try:
            alignment = json.loads((await karaoke_alignment.read()).decode("utf-8"))
            if not isinstance(alignment, list): raise ValueError("KARAOKE_ALIGNMENT_NOT_ARRAY")
        except Exception as exc:
            raise HTTPException(400, f"INVALID_KARAOKE_ALIGNMENT: {exc}")
    metadata = _render(source, srt, output, style, font_size, position, shape, outline_width, shadow_depth, horizontal_percent, vertical_percent, overlays, alignment)
    response = {"status": "validated", "artifact_id": artifact_id, "filename": output.name, "owner_id": request.state.user["sub"], **metadata}
    (artifact_dir / "metadata.json").write_text(json.dumps(response, ensure_ascii=False, indent=2), encoding="utf-8")
    (artifact_dir / "render_validation.json").write_text(json.dumps(metadata["validation"], ensure_ascii=False, indent=2), encoding="utf-8")
    return response


@app.post("/v1/render-upload/async")
async def render_upload_async(request: Request, upload_id: str = Form(...), subtitles: UploadFile = File(...), ocr_overlays: UploadFile | None = File(None), karaoke_alignment: UploadFile | None = File(None), style: str = Form("LISAN_CLASSIC"), font_size: int = Form(54), position: str = Form("BOTTOM"), shape: str = Form("OUTLINE"), outline_width: int = Form(4), shadow_depth: int = Form(1), horizontal_percent: int = Form(50), vertical_percent: int = Form(88)):
    _require_owner(request, _owner_for_upload(upload_id))
    source = _upload_file(upload_id)
    artifact_id = uuid.uuid4().hex
    job_id = uuid.uuid4().hex
    artifact_dir = ARTIFACT_ROOT / artifact_id
    artifact_dir.mkdir(parents=True, exist_ok=False)
    srt = artifact_dir / "translated.srt"
    output = artifact_dir / "translated_video.mp4"
    _stream_to_file(subtitles, srt, max_bytes=64 * 1024 * 1024)
    overlays = []
    if ocr_overlays is not None:
        try:
            overlays = json.loads((await ocr_overlays.read()).decode("utf-8"))
            if not isinstance(overlays, list): raise ValueError("OCR_OVERLAYS_NOT_ARRAY")
            overlays = _validate_ocr_overlays(overlays)
        except HTTPException: raise
        except Exception as exc: raise HTTPException(400, f"INVALID_OCR_OVERLAYS: {exc}")
    alignment = None
    if karaoke_alignment is not None:
        try:
            alignment = json.loads((await karaoke_alignment.read()).decode("utf-8"))
            if not isinstance(alignment, list): raise ValueError("KARAOKE_ALIGNMENT_NOT_ARRAY")
        except Exception as exc: raise HTTPException(400, f"INVALID_KARAOKE_ALIGNMENT: {exc}")
    _set_job(job_id, status="queued", progress=0, artifact_id=artifact_id, owner_id=request.state.user["sub"])
    JOB_EXECUTOR.submit(_run_render_job, job_id, source, srt, output, style, font_size, position, shape,
                        outline_width, shadow_depth, horizontal_percent, vertical_percent, overlays, alignment, artifact_dir)
    return {"job_id": job_id, "artifact_id": artifact_id, "status": "queued", "progress": 0}


@app.get("/v1/render-jobs/{job_id}")
def render_job_status(job_id: str, request: Request):
    with JOB_LOCK:
        job = RENDER_JOBS.get(job_id)
        if job is None:
            raise HTTPException(404, "RENDER_JOB_NOT_FOUND")
        _require_owner(request, str(job.get("owner_id", "")))
        return dict(job)

@app.get("/v1/artifacts/{artifact_id}")
def artifact_metadata(artifact_id: str, request: Request):
    metadata = ARTIFACT_ROOT / artifact_id / "metadata.json"
    if not metadata.exists():
        raise HTTPException(404, "ARTIFACT_NOT_FOUND")
    data = json.loads(metadata.read_text(encoding="utf-8"))
    _require_owner(request, str(data.get("owner_id", "")))
    return data

@app.get("/v1/artifacts/{artifact_id}/download")
def download_artifact(artifact_id: str, request: Request):
    output = ARTIFACT_ROOT / artifact_id / "translated_video.mp4"
    if not output.exists():
        raise HTTPException(404, "ARTIFACT_NOT_FOUND")
    metadata_path = ARTIFACT_ROOT / artifact_id / "metadata.json"
    if metadata_path.exists():
        _require_owner(request, str(json.loads(metadata_path.read_text(encoding="utf-8")).get("owner_id", "")))
    return FileResponse(output, media_type="video/mp4", filename="translated_video.mp4")

@app.post("/v1/maintenance/cleanup")
def maintenance_cleanup(dry_run: bool = True):
    """Retention sweep. Defaults to dry-run; production schedulers should call the module directly or pass false behind auth."""
    result = retention_cleanup.cleanup(DATA_ROOT, UPLOAD_ROOT, ARTIFACT_ROOT, RENDER_JOBS, PIPELINE_JOBS, storage=storage, dry_run=dry_run)
    return result


@app.get("/v1/storage/status")
def storage_status():
    return {"backend": storage.BACKEND, "ready": storage.enabled(), "bucket_configured": bool(storage.BUCKET), "signed_urls": storage.BACKEND in ("gcs", "s3")}


@app.get("/v1/artifacts/{artifact_id}/download-url")
def artifact_download_url(artifact_id: str, request: Request, expires_seconds: int = 900):
    if expires_seconds < 60 or expires_seconds > 3600:
        raise HTTPException(400, "INVALID_EXPIRATION")
    metadata_path = ARTIFACT_ROOT / artifact_id / "metadata.json"
    if not metadata_path.exists():
        raise HTTPException(404, "ARTIFACT_NOT_FOUND")
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    _require_owner(request, str(metadata.get("owner_id", "")))
    info = metadata.get("storage") or {}
    object_key = info.get("key")
    if not object_key:
        raise HTTPException(409, "ARTIFACT_NOT_IN_OBJECT_STORAGE")
    try:
        url = storage.signed_url(object_key, expires_seconds)
    except Exception as exc:
        raise HTTPException(502, f"SIGNED_URL_FAILED:{exc}")
    if not url:
        raise HTTPException(503, "SIGNED_URL_NOT_SUPPORTED")
    return {"artifact_id": artifact_id, "url": url, "expires_in": expires_seconds}


@app.post("/v1/render")
async def render_video(request: Request, video: UploadFile = File(...), subtitles: UploadFile = File(...), ocr_overlays: UploadFile | None = File(None), karaoke_alignment: UploadFile | None = File(None), style: str = Form("LISAN_CLASSIC"), font_size: int = Form(54), position: str = Form("BOTTOM"), shape: str = Form("OUTLINE"), outline_width: int = Form(4), shadow_depth: int = Form(1), horizontal_percent: int = Form(50), vertical_percent: int = Form(88)):
    """Backward-compatible render endpoint; persistent artifact storage is used."""
    with TemporaryDirectory() as work:
        root = Path(work)
        source = root / f"source{Path(video.filename or 'source.mp4').suffix or '.mp4'}"
        srt = root / "translated.srt"
        _stream_to_file(video, source)
        _stream_to_file(subtitles, srt, max_bytes=64 * 1024 * 1024)
        overlays = []
        if ocr_overlays is not None:
            try:
                overlays = json.loads((await ocr_overlays.read()).decode("utf-8"))
                if not isinstance(overlays, list): raise ValueError("OCR_OVERLAYS_NOT_ARRAY")
                overlays = _validate_ocr_overlays(overlays)
            except HTTPException:
                raise
            except Exception as exc:
                raise HTTPException(400, f"INVALID_OCR_OVERLAYS: {exc}")
        alignment = None
        if karaoke_alignment is not None:
            try:
                alignment = json.loads((await karaoke_alignment.read()).decode("utf-8"))
                if not isinstance(alignment, list): raise ValueError("KARAOKE_ALIGNMENT_NOT_ARRAY")
            except Exception as exc:
                raise HTTPException(400, f"INVALID_KARAOKE_ALIGNMENT: {exc}")
        artifact_id = uuid.uuid4().hex
        artifact_dir = ARTIFACT_ROOT / artifact_id
        artifact_dir.mkdir(parents=True, exist_ok=False)
        output = artifact_dir / "translated_video.mp4"
        metadata = _render(source, srt, output, style, font_size, position, shape, outline_width, shadow_depth, horizontal_percent, vertical_percent, overlays, alignment)
        response = {"status": "validated", "artifact_id": artifact_id, "filename": output.name, "owner_id": request.state.user["sub"], **metadata}
        (artifact_dir / "metadata.json").write_text(json.dumps(response), encoding="utf-8")
        return response
