"""Safe retention cleanup for Lisan local cache and object storage metadata."""
import os
import time
import json
import shutil
from pathlib import Path


def _age_days(name: str, default: int) -> int:
    try:
        return max(1, int(os.getenv(name, str(default))))
    except ValueError:
        return default


def _active_ids(render_jobs: dict, pipeline_jobs: dict):
    active = set()
    terminal = {"completed", "failed", "cancelled"}
    for jobs in (render_jobs, pipeline_jobs):
        for job_id, job in jobs.items():
            if str(job.get("status", "")).lower() not in terminal:
                upload_id = job.get("upload_id")
                artifact_id = job.get("artifact_id")
                if upload_id:
                    active.add(("upload", str(upload_id)))
                if artifact_id:
                    active.add(("artifact", str(artifact_id)))
    return active


def _old(path: Path, now: float, days: int) -> bool:
    try:
        return now - path.stat().st_mtime >= days * 86400
    except FileNotFoundError:
        return False


def cleanup(data_root: Path, upload_root: Path, artifact_root: Path,
            render_jobs: dict, pipeline_jobs: dict, storage=None, dry_run: bool = False):
    """Delete only stale, unreferenced local data.

    Completed cloud objects are deleted only when their local metadata is stale and
    contains an object key. Active jobs always protect their upload/artifact IDs.
    """
    now = time.time()
    upload_days = _age_days("LISAN_UPLOAD_RETENTION_DAYS", 2)
    artifact_days = _age_days("LISAN_ARTIFACT_RETENTION_DAYS", 30)
    incomplete_days = _age_days("LISAN_INCOMPLETE_UPLOAD_RETENTION_DAYS", 1)
    active = _active_ids(render_jobs, pipeline_jobs)
    removed = {"uploads": [], "artifacts": [], "bytes": 0, "dry_run": dry_run}

    for d in upload_root.iterdir() if upload_root.exists() else []:
        if not d.is_dir() or ("upload", d.name) in active:
            continue
        complete = d / "complete.json"
        stale_days = upload_days if complete.exists() else incomplete_days
        if not _old(d, now, stale_days):
            continue
        if not dry_run:
            shutil.rmtree(d, ignore_errors=True)
        removed["uploads"].append(d.name)

    for d in artifact_root.iterdir() if artifact_root.exists() else []:
        if not d.is_dir() or ("artifact", d.name) in active:
            continue
        metadata_path = d / "metadata.json"
        if not _old(d, now, artifact_days):
            continue
        cloud_info = None
        if metadata_path.exists():
            try:
                metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
                cloud_info = metadata.get("storage") or None
            except Exception:
                cloud_info = None
        if not dry_run and cloud_info and storage is not None and cloud_info.get("key"):
            try:
                if storage.BACKEND != "local":
                    storage.delete(cloud_info["key"])
            except Exception:
                # Keep local metadata if cloud deletion failed; retry next sweep.
                continue
        size = 0
        if d.exists():
            for p in d.rglob("*"):
                if p.is_file():
                    try: size += p.stat().st_size
                    except OSError: pass
        if not dry_run:
            shutil.rmtree(d, ignore_errors=True)
        removed["artifacts"].append(d.name)
        removed["bytes"] += size
    return removed
