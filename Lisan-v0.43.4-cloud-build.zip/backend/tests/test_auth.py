import os
os.environ.setdefault("LISAN_AUTH_REQUIRED", "true")
from fastapi.testclient import TestClient
from app.main import app, AUTH_DB, _make_token

def test_auth_rejects_protected_endpoint_without_token():
    client=TestClient(app)
    r=client.get("/v1/storage/status")
    assert r.status_code==401

def test_register_login_and_me(tmp_path, monkeypatch):
    monkeypatch.setattr("app.main.AUTH_DB", tmp_path / "users.json")
    client=TestClient(app)
    email="auth-test@example.com"
    r=client.post("/v1/auth/register", data={"email":email,"password":"strongpass123"})
    assert r.status_code==200
    token=r.json()["access_token"]
    r=client.get("/v1/auth/me", headers={"Authorization":f"Bearer {token}"})
    assert r.status_code==200 and r.json()["email"]==email
    r=client.post("/v1/auth/login", data={"email":email,"password":"strongpass123"})
    assert r.status_code==200
    assert r.json()["access_token"]

def test_expired_or_tampered_token_rejected():
    client=TestClient(app)
    token=_make_token("u","u@example.com")[:-1]+("A" if _make_token("u","u@example.com")[-1]!="A" else "B")
    r=client.get("/v1/storage/status", headers={"Authorization":f"Bearer {token}"})
    assert r.status_code==401
