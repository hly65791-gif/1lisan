from app.main import _build_karaoke_ass

def test_karaoke_ass_contains_word_timing_tags():
    ass = _build_karaoke_ass([
        [
            {"start_ms": 0, "end_ms": 500, "text": "مرحبا"},
            {"start_ms": 500, "end_ms": 1000, "text": "بكم"},
        ]
    ])
    assert "{\\k50}مرحبا" in ass
    assert "{\\k50}بكم" in ass
    assert "Dialogue:" in ass
