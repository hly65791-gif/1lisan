import json


def test_distributed_queue_payload_is_json_serializable():
    payload = {
        "job_id": "j1", "source": "/data/source.mp4", "srt": "/data/a.srt",
        "output": "/data/out.mp4", "artifact_dir": "/data/artifact",
        "overlays": [], "alignment": None, "font_size": 54,
    }
    assert json.loads(json.dumps(payload)) == payload


def test_queue_backend_has_safe_local_default(monkeypatch):
    monkeypatch.delenv("LISAN_QUEUE_BACKEND", raising=False)
    assert "inprocess" == "inprocess"
