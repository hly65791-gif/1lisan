from app import main as module

def test_ocr_overlay_custom_style_tags_are_bounded():
    ass = module._build_ocr_ass([{"start_ms":0,"end_ms":500,"text":"SALE","x_percent":50,"y_percent":50,"font_size_sp":120,"outline_width":99,"shadow_depth":99,"bold":False}])
    assert r"{\pos(960,540)\fs80\bord8\shad6\b0}" in ass
