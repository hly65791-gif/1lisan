from app.main import _build_ocr_ass, _build_ocr_replacement_filter, _validate_ocr_overlays


def sample():
    return [{
        "id": 1, "start_ms": 1000, "end_ms": 5000, "text": "متجر",
        "x_percent": 30, "y_percent": 40, "width_percent": 20, "height_percent": 10,
        "replace_original": True, "motion_tracking_enabled": True,
        "keyframes": [
            {"time_ms": 1000, "x_percent": 30, "y_percent": 40, "width_percent": 20, "height_percent": 10},
            {"time_ms": 3000, "x_percent": 50, "y_percent": 45, "width_percent": 22, "height_percent": 11},
            {"time_ms": 5000, "x_percent": 70, "y_percent": 50, "width_percent": 24, "height_percent": 12},
        ],
    }]


def test_tracking_splits_ass_events():
    ass = _build_ocr_ass(sample())
    assert ass.count("Dialogue: 1,") == 2
    assert "0:00:10.00" not in ass
    assert "{\\pos(960,486)" in ass


def test_tracking_splits_replacement_masks():
    f = _build_ocr_replacement_filter(sample(), 1280, 720)
    assert f.count("delogo=") == 2
    assert "between(t,1.000,3.000)" in f
    assert "between(t,3.000,5.000)" in f


def test_keyframes_are_validated_and_sorted():
    item = sample()[0]
    item["keyframes"] = [item["keyframes"][2], item["keyframes"][0]]
    out = _validate_ocr_overlays([item])[0]
    assert [k["time_ms"] for k in out["keyframes"]] == [1000, 5000]


def test_invalid_keyframe_is_rejected():
    item = sample()[0]
    item["keyframes"] = [{"time_ms": 7000, "x_percent": 50, "y_percent": 50}]
    try:
        _validate_ocr_overlays([item])
    except Exception as exc:
        assert "INVALID_OCR_KEYFRAME" in str(exc)
    else:
        raise AssertionError("invalid keyframe was accepted")
