from pathlib import Path
import importlib.util

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("lisan_backend", ROOT / "app" / "main.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def test_lisan_classic_ass_style():
    ass = module._build_lisan_classic_ass([
        {"start_ms": 0, "end_ms": 1500, "text": "أعطيت بوجا وثائق مزورة"}
    ])
    assert "Style: LisanClassic,Noto Sans Arabic,54" in ass
    assert "&H00FFFFFF" in ass
    assert ",1,4,1,5,70,70,55,1" in ass
    assert r"{\pos(960,950)}" in ass
    assert "أعطيت بوجا وثائق مزورة" in ass


def test_custom_size_position_shape():
    ass = module._build_lisan_classic_ass(
        [{"start_ms": 0, "end_ms": 1000, "text": "مرحبا"}],
        font_size=72, position="TOP", shape="BOX", outline_width=2, shadow_depth=3,
    )
    assert "Style: LisanClassic,Noto Sans Arabic,72" in ass
    assert ",3,0,0,5,70,70,55,1" in ass
    assert "&H90000000" in ass
    assert r"{\pos(960,151)}" in ass


def test_custom_drag_position_is_clamped():
    ass = module._build_lisan_classic_ass(
        [{"start_ms": 0, "end_ms": 1000, "text": "مخصص"}],
        position="CUSTOM", horizontal_percent=97, vertical_percent=2,
    )
    assert r"{\pos(1766,86)}" in ass


def test_ocr_overlay_ass_layer_and_position():
    ass = module._build_lisan_classic_ass(
        [{"start_ms": 0, "end_ms": 1200, "text": "الترجمة"}],
        ocr_overlays=[{"start_ms": 200, "end_ms": 1000, "text": "SALE", "x_percent": 25, "y_percent": 30, "enabled": True}],
    )
    assert "Style: LisanOCR,Noto Sans Arabic,42" in ass
    assert "Dialogue: 1" in ass
    assert r"{\pos(480,324)\fs42\bord3\shad1\b1}" in ass
    assert "SALE" in ass


def test_disabled_ocr_overlay_is_not_rendered():
    ass = module._build_lisan_classic_ass(
        [],
        ocr_overlays=[{"start_ms": 0, "end_ms": 1000, "text": "HIDE", "x_percent": 50, "y_percent": 50, "enabled": False}],
    )
    assert "HIDE" not in ass
