# Lisan v0.41 — Video Setup UX

The video setup screen was redesigned as a production-oriented RTL flow.

- Video thumbnail preview and metadata.
- Source/target language selectors.
- Four-hour per-video guard.
- Comprehensive translation toggle.
- Original-text replacement toggle, only available with comprehensive translation.
- Lisan Classic subtitle style selector.
- Persistent project fields continue to use Room through ProjectRepository.
- Start button is disabled until a valid video is selected.
