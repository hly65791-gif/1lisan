plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}
android { namespace = "com.lisan.domain"; compileSdk = 35 }
dependencies {
    implementation(project(":core-common"))
    testImplementation(kotlin("test"))
}
