package com.lisan.domain.model

import java.time.Instant

enum class ProjectStatus { DRAFT, QUEUED, PROCESSING, PAUSED, COMPLETED, FAILED, CANCELLED }

data class Project(
    val id: String,
    val name: String,
    val sourceUri: String,
    val sourceLanguage: String,
    val targetLanguage: String,
    val status: ProjectStatus = ProjectStatus.DRAFT,
    val progress: Int = 0,
    val createdAt: Instant = Instant.now(),
    val updatedAt: Instant = Instant.now(),
    val error: String? = null,
    val outputPath: String? = null,
    val artifactId: String? = null,
    val subtitleStyle: SubtitleStylePreset = SubtitleStylePreset.LISAN_CLASSIC,
    val subtitleAppearance: SubtitleAppearance = SubtitleAppearance(),
    val comprehensiveTranslation: Boolean = false,
    val replaceOcrText: Boolean = false
)
