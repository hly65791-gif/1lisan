package com.lisan.domain.model

data class OcrKeyframe(
    val timeMs: Long,
    val xPercent: Int,
    val yPercent: Int,
    val widthPercent: Int = 20,
    val heightPercent: Int = 10
)

/** Editable text detected inside the source video. Positions are percentages of the preview canvas. */
data class OcrOverlay(
    val id: Int,
    val startMs: Long,
    val endMs: Long,
    val text: String,
    val xPercent: Int = 50,
    val yPercent: Int = 50,
    val enabled: Boolean = true,
    val fontSizeSp: Int = 42,
    val outlineWidth: Int = 3,
    val shadowDepth: Int = 1,
    val bold: Boolean = true,
    val replaceOriginal: Boolean = false,
    val widthPercent: Int = 20,
    val heightPercent: Int = 10,
    val motionTrackingEnabled: Boolean = false,
    val keyframes: List<OcrKeyframe> = emptyList()
) {
    val safeX: Int get() = xPercent.coerceIn(5, 95)
    val safeY: Int get() = yPercent.coerceIn(5, 95)
}
