package com.lisan.domain.provider

data class TranscriptWord(
    val startMs: Long,
    val endMs: Long,
    val text: String,
    val confidence: Float? = null
)

data class TranslatedWordTiming(
    val startMs: Long,
    val endMs: Long,
    val text: String,
    val sourceWordIndex: Int? = null
)

data class TranscriptSegment(
    val startMs: Long,
    val endMs: Long,
    val text: String,
    val confidence: Float? = null,
    val words: List<TranscriptWord> = emptyList()
)

data class OcrSegment(
    val startMs: Long,
    val endMs: Long,
    val text: String,
    val x: Int? = null,
    val y: Int? = null
)

interface SpeechToTextProvider {
    suspend fun transcribe(audioUri: String, language: String): List<TranscriptSegment>
}

interface TranslationProvider {
    suspend fun translate(segments: List<TranscriptSegment>, source: String, target: String): List<TranscriptSegment>
}

interface OcrProvider {
    suspend fun detect(videoUri: String, languageHint: String? = null): List<OcrSegment>
}
