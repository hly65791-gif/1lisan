package com.lisan.domain.model

/** Small immutable undo/redo history for subtitle lists. */
class SubtitleEditorHistory(initial: List<Subtitle>) {
    private val undoStack = java.util.ArrayDeque<List<Subtitle>>()
    private val redoStack = java.util.ArrayDeque<List<Subtitle>>()
    var current: List<Subtitle> = normalize(initial)
        private set

    fun replace(next: List<Subtitle>) {
        val normalized = normalize(next)
        if (normalized == current) return
        undoStack.addLast(current)
        current = normalized
        redoStack.clear()
    }

    fun undo(): List<Subtitle>? {
        if (undoStack.isEmpty()) return null
        val previous = undoStack.removeLast()
        redoStack.addLast(current)
        current = previous
        return current
    }

    fun redo(): List<Subtitle>? {
        if (redoStack.isEmpty()) return null
        val next = redoStack.removeLast()
        undoStack.addLast(current)
        current = next
        return current
    }

    fun canUndo(): Boolean = undoStack.isNotEmpty()
    fun canRedo(): Boolean = redoStack.isNotEmpty()

    private fun normalize(items: List<Subtitle>): List<Subtitle> = items
        .sortedBy { it.startMs }
        .mapIndexed { index, item ->
            item.copy(index = index + 1, endMs = maxOf(item.startMs + 200, item.endMs))
        }
}
