package com.lisan.domain.usecase

import com.lisan.domain.model.Subtitle
import kotlin.test.Test
import kotlin.test.assertTrue

class SubtitleExportUseCaseTest {
    @Test
    fun exportsSrtWithMilliseconds() {
        val result = SubtitleExportUseCase().toSrt(
            listOf(Subtitle(1, 1_250, 3_500, "Hello Lisan"))
        )
        assertTrue(result.contains("00:00:01,250 --> 00:00:03,500"))
        assertTrue(result.contains("Hello Lisan"))
    }

    @Test
    fun exportsVttWithHeader() {
        val result = SubtitleExportUseCase().toVtt(
            listOf(Subtitle(1, 0, 1_000, "مرحبا"))
        )
        assertTrue(result.startsWith("WEBVTT"))
        assertTrue(result.contains("00:00:00,000 --> 00:00:01,000"))
    }
}
