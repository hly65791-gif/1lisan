package com.lisan.domain.model

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class SubtitleEditorHistoryTest {
    private val a = Subtitle(1, 0, 1000, "A")
    private val b = Subtitle(2, 1200, 2200, "B")

    @Test fun undoAndRedoRestoreSnapshots() {
        val history = SubtitleEditorHistory(listOf(a))
        history.replace(listOf(a, b))
        assertTrue(history.canUndo())
        assertEquals(1, history.undo()?.size)
        assertTrue(history.canRedo())
        assertEquals(2, history.redo()?.size)
    }

    @Test fun normalizationSortsAndRenumbers() {
        val history = SubtitleEditorHistory(listOf(b, a))
        assertEquals(listOf("A", "B"), history.current.map { it.text })
        assertEquals(listOf(1, 2), history.current.map { it.index })
        assertFalse(history.canUndo())
    }
}
