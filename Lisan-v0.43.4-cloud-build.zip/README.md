# Lisan

Professional Android video translation application foundation.

## Processing architecture

```text
Android
  ↓
Video selection
  ↓
WorkManager
  ↓
Audio extraction
  ↓
Lisan Backend
  ├── STT (Faster-Whisper)
  ├── Translation provider
  └── OCR (FFmpeg + Tesseract)
  ↓
Transcript / Translation
  ↓
SRT + VTT
  ↓
FFmpeg rendering with Lisan Classic subtitle burn-in
  ↓
Validation
  ↓
Export
```

Provider credentials stay on backend infrastructure and are never embedded in the APK.

## Backend

See `backend/README.md`.

## Android build

This snapshot does not include a verified Gradle Wrapper JAR and the current environment has no Gradle executable. Android compilation is therefore not claimed until a proper Android/Gradle environment is supplied.

## v0.12 editor QA
The subtitle editor now supports Split, Merge, STT-timing Auto-Sync, and editable OCR overlays. OCR overlays are saved to `ocr_overlays.json`, previewed on the 16:9 FIT canvas, and included as a second ASS/libass layer during final rendering.
